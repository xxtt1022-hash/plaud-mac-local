import AppKit
import Foundation

let output = CommandLine.arguments[1]
let size = NSSize(width: 1024, height: 1024)
let image = NSImage(size: size)
image.lockFocus()
NSColor(calibratedRed: 0.11, green: 0.39, blue: 0.34, alpha: 1).setFill()
NSBezierPath(roundedRect: NSRect(x: 54, y: 54, width: 916, height: 916), xRadius: 206, yRadius: 206).fill()
NSColor.white.setStroke()
let heights: [CGFloat] = [140, 240, 340, 450, 340, 240, 140]
for (index, height) in heights.enumerated() {
    let x = CGFloat(292 + index * 74)
    let path = NSBezierPath()
    path.move(to: NSPoint(x: x, y: 520 - height / 2))
    path.line(to: NSPoint(x: x, y: 520 + height / 2))
    path.lineWidth = 40
    path.lineCapStyle = .round
    path.stroke()
}
let text = "PLAUD" as NSString
text.draw(at: NSPoint(x: 305, y: 192), withAttributes: [.font: NSFont.systemFont(ofSize: 105, weight: .semibold), .foregroundColor: NSColor.white])
image.unlockFocus()
let bitmap = NSBitmapImageRep(data: image.tiffRepresentation!)!
try bitmap.representation(using: .png, properties: [:])!.write(to: URL(fileURLWithPath: output))
