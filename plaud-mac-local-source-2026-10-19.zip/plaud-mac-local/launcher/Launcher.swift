import AppKit
import Foundation
import Darwin

final class DirectSession: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }
}

enum Probe { case ready, unavailable, wrongService }

final class Launcher: NSObject, NSApplicationDelegate {
    var settings: [String: String] = [:]
    var library = ""
    var managerURL: URL!
    var session: URLSession!
    let direct = DirectSession()
    var backend: Process?
    var starting = false
    var finished = false
    var attempts = 0
    var startedBackend = false

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        do {
            guard let file = Bundle.main.url(forResource: "LauncherSettings", withExtension: "plist"),
                  let value = try PropertyListSerialization.propertyList(from: Data(contentsOf: file), format: nil) as? [String: String] else {
                throw NSError(domain: "Launcher", code: 1)
            }
            settings = value
            guard let configPath = settings["configPath"],
                  let config = try JSONSerialization.jsonObject(with: Data(contentsOf: URL(fileURLWithPath: configPath))) as? [String: Any],
                  let root = config["libraryRoot"] as? String,
                  let port = config["port"] as? Int, port == 8769,
                  root.hasPrefix("/") else { throw NSError(domain: "Launcher", code: 2) }
            library = URL(fileURLWithPath: root).standardizedFileURL.resolvingSymlinksInPath().path
            let token = try String(contentsOfFile: library + "/.access-token", encoding: .ascii)
            guard token.range(of: "^[A-Za-z0-9_-]{40,80}$", options: .regularExpression) != nil,
                  let url = URL(string: "http://127.0.0.1:8769/" + token + "/") else {
                throw NSError(domain: "Launcher", code: 3)
            }
            managerURL = url
            let configuration = URLSessionConfiguration.ephemeral
            configuration.connectionProxyDictionary = ["HTTPEnable": 0, "HTTPSEnable": 0,
                "SOCKSEnable": 0, "ExceptionsList": ["127.0.0.1", "localhost"], "ExcludeSimpleHostnames": 1]
            configuration.timeoutIntervalForRequest = 2
            configuration.timeoutIntervalForResource = 3
            configuration.urlCache = nil
            session = URLSession(configuration: configuration, delegate: direct, delegateQueue: nil)
            poll()
        } catch {
            fail("找不到现有录音管理配置或入口。请保留原来的 Codex 工作目录，再重新打开。")
        }
    }

    func probe(_ completion: @escaping (Probe) -> Void) {
        var request = URLRequest(url: managerURL.appendingPathComponent("api/state"))
        request.cachePolicy = .reloadIgnoringLocalCacheData
        session.dataTask(with: request) { data, response, error in
            var result = Probe.unavailable
            if let response = response as? HTTPURLResponse {
                result = .wrongService
                if error == nil, response.statusCode == 200, let data = data,
                   let value = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                   value["libraryRoot"] as? String == self.library {
                    result = .ready
                }
            }
            DispatchQueue.main.async { completion(result) }
        }.resume()
    }

    func poll() {
        if finished { return }
        probe { result in
            if self.finished { return }
            switch result {
            case .ready: self.openChrome()
            case .wrongService:
                self.fail("本机 8769 端口上的页面与这份录音库不匹配，已停止打开。没有修改或关闭其他程序。")
            case .unavailable:
                if !self.starting {
                    self.starting = true
                    self.startServer()
                } else if self.attempts >= 30 {
                    self.fail("录音管理服务尚未就绪。请稍后重试，或查看管理文件夹中的启动日志。")
                } else {
                    self.attempts += 1
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { self.poll() }
                }
            }
        }
    }

    func startServer() {
        guard let python = settings["pythonPath"], let script = settings["scriptPath"],
              let config = settings["configPath"], let directory = settings["workspacePath"],
              let logPath = settings["logPath"],
              FileManager.default.isExecutableFile(atPath: python),
              FileManager.default.fileExists(atPath: script) else {
            fail("启动所需的 Python 或管理程序已被移动。请保留原工作目录。")
            return
        }
        do {
            let fd = Darwin.open(logPath, O_WRONLY | O_CREAT | O_APPEND | O_NOFOLLOW, mode_t(0o600))
            guard fd >= 0 else { throw NSError(domain: "Launcher", code: 4) }
            let output = FileHandle(fileDescriptor: fd, closeOnDealloc: true)
            let process = Process()
            process.executableURL = URL(fileURLWithPath: python)
            process.arguments = [script, "--config", config]
            process.currentDirectoryURL = URL(fileURLWithPath: directory)
            process.standardInput = FileHandle.nullDevice
            process.standardOutput = output
            process.standardError = output
            try process.run()
            backend = process
            startedBackend = true
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { self.poll() }
        } catch {
            fail("无法启动本机录音管理服务。现有录音和文字均保留。")
        }
    }

    func openChrome() {
        guard !finished else { return }
        finished = true
        guard let chrome = NSWorkspace.shared.urlForApplication(withBundleIdentifier: "com.google.Chrome") else {
            fail("没有找到 Google Chrome。管理服务已就绪，请安装或恢复 Chrome 后再打开入口。")
            return
        }
        let configuration = NSWorkspace.OpenConfiguration()
        configuration.activates = true
        NSWorkspace.shared.open([managerURL], withApplicationAt: chrome, configuration: configuration) { _, error in
            DispatchQueue.main.async {
                if error != nil {
                    self.fail("Chrome 未能打开管理页，请稍后再次点击桌面入口。")
                } else {
                    self.receipt()
                    NSApp.terminate(nil)
                }
            }
        }
    }

    func receipt() {
        guard let path = settings["receiptPath"] else { return }
        let value: [String: Any] = ["openedAt": ISO8601DateFormatter().string(from: Date()),
            "serviceIdentityVerified": true, "startedBackend": startedBackend,
            "browser": "Google Chrome", "terminalOpened": false]
        if let data = try? JSONSerialization.data(withJSONObject: value, options: [.prettyPrinted, .sortedKeys]) {
            try? data.write(to: URL(fileURLWithPath: path), options: .atomic)
            try? FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: path)
        }
    }

    func fail(_ message: String) {
        finished = true
        NSApp.activate(ignoringOtherApps: true)
        let alert = NSAlert()
        alert.messageText = "PLAUD 录音管理"
        alert.informativeText = message
        alert.alertStyle = .warning
        alert.addButton(withTitle: "知道了")
        alert.runModal()
        NSApp.terminate(nil)
    }
}

let application = NSApplication.shared
let launcher = Launcher()
application.delegate = launcher
application.run()
