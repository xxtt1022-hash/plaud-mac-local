# 公开源码复现前提

本目录提供源码和合成测试，不携带任何设备身份、录音、转写正文、开发者密钥、Keychain 数据、模型、SDK 二进制或预构建 App。公开副本使用通用 Keychain account `plaud-local-owner`；它不会自动接管原作者的 Keychain 项目或接收器状态。

## Mac 依赖与测试

实测环境为 Apple Silicon Mac、Python 3.12.14。Python 包按 `requirements-macos.lock.txt` 固定，但此文件不是包含 wheel 哈希的跨平台锁。新机器仍需验证对应版本能否从官方包源取得。

1. 安装 Python 3.12、Git 和 Apple Xcode Command Line Tools。
2. 明确执行 `sh scripts/setup-mac.sh`。该脚本会联网克隆固定 commit、下载 Python 包；它不会操作设备、Keychain 或官方账号。也可设置 `PYTHON_BIN` 选用兼容的 Python 3.11+。
3. 上游研究源码位于项目根的 `plaud-direct-pc-research/`，固定 commit 为 `4f52d432b2f4d838ef10c7674d6b49f9bafc7005`。若已有目录版本不同，脚本拒绝重置。部分测试直接引用这个同级源码路径，单独 pip 安装不能替代该 checkout。
4. 执行 `sh scripts/test-synthetic.sh`。这些测试使用临时合成数据和 mock；HTTP 边界测试需要允许本机 loopback 监听。沙箱 EPERM 不能当作应用连接失败或测试通过。

## 私密运行配置

复制 `config.example.json` 到自己选择的私密目录，逐项替换路径和设备 SN，并限制为 `0600`。路径字段不会自动展开占位符，必须填写实际绝对路径。推荐把 runtime、接收器状态、下载文件、数据库、日志、模型全部放在 Git 仓库之外。自动处理默认关闭；确认模型、CLI、数据发送范围后再开启。

`app-credentials.example.json` 仅包含客户端 ID、自己的 stable application user ID 和已核实的 `platform-us` 官方 API origin。应用 secret 通过已有 Keychain 工具人工配置；不要写入 JSON、命令行或公开仓库。这里不会推断其他区域域名。自己 Android App 的 user ID、Mac 配置的 stableUserId、JWT 的绑定身份必须一致。

获得官方 Embedded 资格和对应用户授权，以及建立这台设备的受支持身份，是单独的人工步骤。首次配对、候选导出、confirmed 保存和云绑定均应按 `mac-adapter/README.md` 明确确认，不由安装脚本执行。已有 consumer App 绑定不能假定为可直接导入；不要以清空设备或删除录音作为安装捷径。当前协议只针对已验收的 Note Pro 路径，其他型号/固件没有自动兼容承诺。

接收器初始化会新建随机 RSA 接收器与 Keychain 项，属于单独的用户动作；不要向已有接收器目录重复初始化，也不要把候选材料当作已确认 owner。Android 的 recipient 公钥必须由自己的接收器生成或在 App 中导入，本仓库不带作者的公钥或散列。

## 转写与纪要

whisper.cpp CLI、模型、Codex CLI 和 Google Chrome 需另行安装。确认实际可执行文件路径并填写配置；不能仅凭 Finder 或 shell 的 PATH 推断。ASR 当前明确支持 Ogg/WAV，使用本地 ffmpeg 转为 PCM16 后按原语言转写。`imageio-ffmpeg` 的分发会另带 ffmpeg 二进制，相关许可仍需遵循其实际分发内容。

模型来源及固定修订/hash 见 `mac-adapter/README.md`。模型文件不在仓库；手工下载后计算 SHA256，必须与配置和来源一致。Homebrew 安装别名的当前实现专门支持 `/opt/homebrew/bin/whisper-cli`；其他安装方式应配置真实的普通可执行文件路径，并重新验证。

纪要通过官方 Codex CLI 使用当前 ChatGPT 登录，仅发送标题和转写文本；它不是全离线流程。CLI 的受限参数与事件解析针对本次验证的 `0.163alpha` 构建，未来版本须重跑测试及文本合成 probe。已有登录由用户自己完成，安装脚本不读账号文件、不自动登录、不选择另一模型。转写和纪要始终为待复核草稿。

## 管理页面与桌面入口

先人工运行 `.venv/bin/python mac-adapter/recording_manager.py --config /ABS/PATH/TO/PRIVATE/config.json`，确认本机管理服务和能力令牌文件已初始化。这个动作不等于设备绑定成功。

原生入口可用以下命令构建到新位置；构建脚本不启动服务、不打开浏览器：

```sh
.venv/bin/python scripts/build-launcher.py \
  --config /ABS/PATH/TO/PRIVATE/config.json \
  --python /ABS/PATH/TO/plaud-mac-local/.venv/bin/python \
  --output /ABS/PATH/TO/PRIVATE/PLAUD录音管理.app
```

需要 macOS 的 `xcrun swiftc` 和系统 `codesign`。写完 Info.plist 与资源后，脚本执行本机 ad-hoc 签名及 `--verify --strict` 校验；Info.plist 含 Finder 启动链路所需的蓝牙用途说明。这是本机自签构建，不是 Apple 公证发行版，也不包含 Developer ID 分发凭证。

入口固定使用端口 8769，显式打开 Google Chrome，复用已通过 libraryRoot 身份检查的服务；缺配置、端口身份不符或 Chrome 不可用会提示错误，不会杀掉其他进程。生成 App 内含自己的本机路径，不能作为通用二进制上传。`launcher/MakeIcon.swift` 仅提供本次自绘图标源码，图标生成/装配不是运行前提。没有安装登录启动项、launch agent 或定时任务。

## 尚未复现的边界

公开副本的依赖安装、Android 重新编译和原生 launcher 构建需要在新环境实际执行后才能称为复现。源码静态检查与合成测试不证明新用户已经完成授权、蓝牙权限、配对、长录音传输或播放验收；当前真实录音验收范围由根目录验收文档单独记录。
