# Build your own optional Android bootstrap

This directory contains source and Gradle wrapper scripts only. The public copy does
not carry a ready-to-install APK, the official SDK, a Gradle wrapper JAR, a recipient
key, account credentials or a signing keystore. It is not an authentication bypass.

## 1. Obtain the SDK under its own terms

Obtain the Android SDK binary from the [official PLAUD SDK repository](https://github.com/Plaud-AI/plaud-sdk-public)
using access and license terms that apply to you. The local reference repository's
LICENSE explicitly says that SDK binaries are proprietary and have a separate license;
the template's Apache-2.0 source license does not establish general SDK redistribution
permission. Obtaining a public copy of the SDK is not a reason to bundle it in a fork.

Place the required binary at `app/libs/plaud-sdk.aar`. This source is coupled to the
following exact AAR SHA-256, checked by the `verifyPlaudSdk` task before `preBuild`:

```text
041a6f8814d350dbc8bcd4a515487136529bb8bb4368fc88c9b36c9a386aedce
```

You can compare your downloaded file locally with `shasum -a 256 app/libs/plaud-sdk.aar`.
The digest identifies the required bytes; this source package does not assert that an
upstream branch's current binary still has those bytes. If it differs, obtain the
appropriate authorized version or separately review the new SDK. Do not remove the
check to make an unknown binary build. `SdkOwnerMaterial.kt` reads this application's
active SDK key storage by type and will fail if that internal layout changes.

## 2. Install the build prerequisites yourself

Use JDK 17, Android SDK Platform 34, and Gradle 8.2. The Android Gradle Plugin is
8.1.1 and Kotlin plugin is 1.8.22; Maven dependency versions are declared in the
Gradle files. Configure `ANDROID_HOME`, or create an untracked `local.properties`
containing only your Android SDK path (`sdk.dir=...`). Do not put tokens or secrets
in that file. This minimal project does not read credentials from it.

The standard Gradle wrapper JAR is excluded from this source-only distribution.
With your own Gradle 8.2 installation, generate it locally from this directory:

```sh
gradle wrapper --gradle-version 8.2 --distribution-type bin
```

Gradle and Android dependencies may require downloads. You are responsible for
obtaining them from the relevant official repositories and accepting their terms.
No installation, download or acceptance is performed by this source package.
Do not include generated caches or build outputs in a source publication.

## 3. Configure your application identity

Choose a stable application ID in `app/build.gradle`; the shipped value is an example.
Provide your own application-user identifier with the Gradle property
`bootstrapAppUser`. It must match the user for whom your authorized PLAUD application
issues the short-lived User JWT. Accepted identifiers contain 1–128 ASCII letters,
digits, or `_.:@+-`. The property defaults to empty; SDK initialization stops until
you configure it. The same value appears in the UI and checks the JWT's `user_id`
claim when present. The runtime JWT still supplies the original `sub` used by the
SDK to resolve the handshake identity. Cloud registration retains the original
Bearer JWT plus `type`/`sn` request; no unverified application-user API field is added.

For example, replace `YOUR_APP_USER` with your own configured application user:

```sh
sh gradlew --no-daemon -PbootstrapAppUser=YOUR_APP_USER :app:assembleDebug
```

Enter a current short-lived User JWT in the Android UI at runtime. Do not add the
JWT, client secret, account export or owner material to source, assets, BuildConfig
or a release archive. Local JWT parsing checks structure, expiry and the configured
application-user claim when supplied; the official service authenticates the token.
The service region is explicitly US in this source. A different regional deployment
requires its own documented review and configuration.

The debug APK is created locally at `app/build/outputs/apk/debug/app-debug.apk`.
For ongoing use, choose and retain your own signing identity outside the repository.
The same application ID plus the same signing key are needed to update an installed
app while retaining its encrypted cache. A fresh checkout's debug signing identity
cannot update another person's installation. Do not uninstall an app or clear its
data when it is the only holder of owner material.

## 4. Use your own Mac recipient public key

Initialize a new recipient key pair through the Mac tool's documented setup on your
own Mac. Keep its private key or encrypted private-key store on that Mac. Transfer
only your recipient's RSA public PEM to the phone and use the Android app's public-key
import button (`ACTION_OPEN_DOCUMENT`). Check the fingerprint displayed on the phone
against your own Mac's fingerprint before exporting an encrypted envelope.

No prefilled public-key asset or machine-specific fingerprint is included here.
The source can optionally load `app/src/main/assets/pc-bootstrap-public.pem`, but
creating such an asset is your own local build step. Prefer the import UI, and never
commit that local asset, any private PEM, encrypted owner envelope, or signing key.

## 5. Keep the two export meanings separate

Opening the app, importing a recipient public key, and exporting an already stored
candidate do not initialize the SDK or connect to the device. Candidate export uses
the SAF filename `pc-bootstrap-candidate-v1.json` and authenticated inner
`verification="candidate"`; it is diagnostic and does not establish a binding.

The separate confirmed export is enabled only after the normal accepted binding
material has been saved; its inner verification is `confirmed`. The encrypted outer
format remains version 1 with RSA-OAEP-SHA256/MGF1-SHA256, AES-256-GCM and AAD
`plaud-pc-bootstrap-v1`. There is no automatic candidate promotion, unbind, recovery,
reset, recording download, deletion or firmware operation in this app.

Using the explicit SDK initialization and connection controls is an online workflow
and can bind the selected device to your configured application user. Review the
device's current ownership and the official migration instructions before doing so.
