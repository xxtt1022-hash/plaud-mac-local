# Optional Android owner bootstrap source

This is the small Android bootstrap source, based on the official PLAUD template's
Gradle configuration. It is for an owner who explicitly chooses the normal official
SDK initialization, BLE binding and cloud-registration workflow. It does not download
or delete recordings.

The source version is `0.1.2` (`versionCode 3`). This public copy uses an example
application package and requires the builder's own application-user configuration.
An existing encrypted candidate can be exported independently, but remains unconfirmed.

Start with [SETUP.md](SETUP.md). SDK binaries, signing keys, credentials, recipient
public keys and build outputs are deliberately not included. The source license is
in [LICENSE](LICENSE); the official SDK binary has a separate proprietary license.
