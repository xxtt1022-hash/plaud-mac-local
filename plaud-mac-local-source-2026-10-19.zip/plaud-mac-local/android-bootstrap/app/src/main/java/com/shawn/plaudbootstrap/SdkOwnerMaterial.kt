package com.shawn.plaudbootstrap

import sdk.NiceBuildSdk
import sdk.PlaudDeviceAgent
import sdk.ble.util.SecureKeyStorage
import java.lang.reflect.Modifier

/**
 * Version-coupled adapter for this application's own, officially issued active SDK key pair.
 * No second gen-key call is made. The build verifies the exact audited AAR hash.
 * The facade exposes the SN signature, but has no public cached-RSA getter in Kotlin.
 */
internal object SdkOwnerMaterial {
    fun capture(sn: String, bindToken: String): OwnerMaterial {
        check(NiceBuildSdk.isPartnerDataReady()) { "SDK key material is not ready" }
        val candidates = NiceBuildSdk::class.java.declaredFields.filter {
            SecureKeyStorage::class.java.isAssignableFrom(it.type)
        }
        check(candidates.size == 1) { "Unsupported SDK key-storage layout" }
        val field = candidates.single().apply { isAccessible = true }
        val owner = if (Modifier.isStatic(field.modifiers)) null else NiceBuildSdk
        val storage = field.get(owner) as? SecureKeyStorage
            ?: error("SDK key storage is unavailable")
        val material = OwnerMaterial(
            sn = sn,
            signature = PlaudDeviceAgent.getSnSignature()?.takeIf { it.isNotBlank() }
                ?: error("SDK device signature is unavailable"),
            bindToken = bindToken,
            rsaPublicKey = storage.retrievePublicKey()?.takeIf { it.isNotBlank() }
                ?: error("SDK public key is unavailable"),
            rsaPrivateKey = storage.retrievePrivateKey()?.takeIf { it.isNotBlank() }
                ?: error("SDK private key is unavailable")
        )
        OwnerMaterialStore.validate(material)
        return material
    }
}
