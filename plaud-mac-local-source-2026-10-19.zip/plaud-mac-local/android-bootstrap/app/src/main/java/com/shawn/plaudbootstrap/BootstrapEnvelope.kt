package com.shawn.plaudbootstrap

import android.util.Base64
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.spec.MGF1ParameterSpec
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.OAEPParameterSpec
import javax.crypto.spec.PSource
import javax.crypto.spec.SecretKeySpec

/**
 * Produces the exact PcBootstrapExporter version-1 wire envelope, in memory only.
 * The recipient is the owner's Mac RSA public PEM; this class never generates or loads assets.
 * String/JCA internal copies cannot be reliably erased on Android; no plaintext is persisted.
 */
object BootstrapEnvelope {
    private val aad = "plaud-pc-bootstrap-v1".toByteArray(Charsets.US_ASCII)
    enum class Verification(val wireValue: String) { CANDIDATE("candidate"), CONFIRMED("confirmed") }

    /** Lowercase, unseparated SHA-256 hex of canonical X.509 SubjectPublicKeyInfo DER. */
    fun fingerprint(pem: String): String {
        val publicKey = OwnerMaterialEncoding.parsePublicKey(pem)
        return MessageDigest.getInstance("SHA-256").digest(publicKey.encoded)
            .joinToString("") { byte -> "%02x".format(byte.toInt() and 0xff) }
    }

    /** Returns UTF-8 encrypted JSON only; neither the material nor a content key is written. */
    fun build(material: OwnerMaterial, pem: String, verification: Verification = Verification.CONFIRMED): ByteArray {
        OwnerMaterialStore.validate(material)
        val recipient = OwnerMaterialEncoding.parsePublicKey(pem)
        // This marker is authenticated inside the existing encrypted payload; the wire envelope is unchanged.
        val plaintext = OwnerMaterialEncoding.toJson(material).put("verification", verification.wireValue)
            .toString().toByteArray(Charsets.UTF_8)
        val aesKey = ByteArray(32)
        val nonce = ByteArray(12)
        try {
            SecureRandom().apply {
                nextBytes(aesKey)
                nextBytes(nonce)
            }
            val content = Cipher.getInstance("AES/GCM/NoPadding")
            content.init(Cipher.ENCRYPT_MODE, SecretKeySpec(aesKey, "AES"), GCMParameterSpec(128, nonce))
            content.updateAAD(aad)
            // doFinal appends the 128-bit authentication tag, as expected by Python AESGCM.
            val ciphertext = content.doFinal(plaintext)
            val wrapping = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding")
            wrapping.init(
                Cipher.ENCRYPT_MODE,
                recipient,
                OAEPParameterSpec("SHA-256", "MGF1", MGF1ParameterSpec.SHA256, PSource.PSpecified.DEFAULT)
            )
            val wrappedKey = wrapping.doFinal(aesKey)
            return JSONObject()
                .put("version", 1)
                .put("keyWrap", "RSA-OAEP-SHA256-MGF1-SHA256")
                .put("contentCipher", "AES-256-GCM")
                .put("wrappedKey", b64(wrappedKey))
                .put("nonce", b64(nonce))
                .put("ciphertext", b64(ciphertext))
                .toString().toByteArray(Charsets.UTF_8)
        } catch (_: Exception) {
            throw IllegalStateException("Unable to build encrypted bootstrap envelope")
        } finally {
            plaintext.fill(0)
            aesKey.fill(0)
        }
    }

    private fun b64(value: ByteArray): String = Base64.encodeToString(value, Base64.NO_WRAP)
}
