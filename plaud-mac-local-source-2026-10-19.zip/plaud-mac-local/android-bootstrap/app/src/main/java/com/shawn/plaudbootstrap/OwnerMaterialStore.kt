package com.shawn.plaudbootstrap

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.AtomicFile
import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyStore
import java.security.Signature
import java.security.interfaces.RSAPrivateKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.RSAPrivateCrtKeySpec
import java.security.spec.RSAPublicKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Secret values must never be interpolated into UI messages or logs. */
data class OwnerMaterial(
    val sn: String,
    val signature: String,
    val bindToken: String,
    val rsaPublicKey: String,
    val rsaPrivateKey: String
) {
    override fun toString(): String = "OwnerMaterial(redacted)"
}

/**
 * Confirmed owner material and a separate candidate, encrypted by a non-exportable
 * Android Keystore AES-256 key with distinct authenticated domains.
 * Both the AtomicFile base and its recovery copy contain ciphertext only. noBackupFilesDir
 * additionally excludes the encrypted record from Android Auto Backup and device transfer.
 * Missing files return null; damaged data and unavailable keys fail closed with safe messages.
 */
object OwnerMaterialStore {
    private const val FILE_NAME = "owner-material-v1.enc"
    private const val CANDIDATE_FILE_NAME = "owner-material-candidate-v1.enc"
    private const val KEY_ALIAS = "plaud_owner_material_aes256_v1"
    private const val VERSION = 1
    private const val NONCE_BYTES = 12
    private const val TAG_BITS = 128
    private const val MAX_FILE_BYTES = 65_536
    private val aad = "plaud-owner-material-store-v1".toByteArray(Charsets.US_ASCII)
    private val candidateAad = "plaud-owner-material-candidate-store-v1".toByteArray(Charsets.US_ASCII)

    /** Overwrites the same device only. No plaintext file is ever created. */
    @Synchronized
    fun save(context: Context, material: OwnerMaterial) {
        validate(material)
        val current = load(context)
        require(current == null || current.sn == material.sn) {
            "A different device is already provisioned"
        }
        writeRecord(context, material, FILE_NAME, aad)
    }

    /** Preserves the first candidate exactly; never replaces different material automatically. */
    @Synchronized
    fun saveCandidate(context: Context, material: OwnerMaterial) {
        validate(material)
        val current = loadCandidate(context)
        require(current == null || current == material) {
            "Different owner material is already pending verification"
        }
        if (current != null) return
        writeRecord(context, material, CANDIDATE_FILE_NAME, candidateAad)
    }

    private fun writeRecord(context: Context, material: OwnerMaterial, fileName: String, associatedData: ByteArray) {
        val plaintext = OwnerMaterialEncoding.toJson(material).toString().toByteArray(Charsets.UTF_8)
        try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            // Android Keystore chooses a fresh IV; callers must not supply an encryption IV.
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
            cipher.updateAAD(associatedData)
            val nonce = cipher.iv
            check(nonce.size == NONCE_BYTES) { "Unexpected storage nonce size" }
            val ciphertext = cipher.doFinal(plaintext)
            val packed = ByteArray(2 + nonce.size + ciphertext.size)
            packed[0] = VERSION.toByte()
            packed[1] = nonce.size.toByte()
            nonce.copyInto(packed, 2)
            ciphertext.copyInto(packed, 2 + nonce.size)
            check(packed.size <= MAX_FILE_BYTES) { "Encrypted record is too large" }

            val file = recordFile(context, fileName)
            val output = file.startWrite()
            try {
                output.write(packed)
                file.finishWrite(output)
            } catch (error: Exception) {
                file.failWrite(output)
                throw error
            }
        } catch (_: Exception) {
            // Do not retain a provider/JSON exception that might include secret input.
            throw IOException("Unable to save encrypted owner material")
        } finally {
            plaintext.fill(0)
        }
    }

    @Synchronized
    fun load(context: Context): OwnerMaterial? = readRecord(context, FILE_NAME, aad)

    @Synchronized
    fun loadCandidate(context: Context): OwnerMaterial? =
        readRecord(context, CANDIDATE_FILE_NAME, candidateAad)

    private fun readRecord(context: Context, fileName: String, associatedData: ByteArray): OwnerMaterial? {
        val file = recordFile(context, fileName)
        if (!file.baseFile.exists() && !File(file.baseFile.path + ".bak").exists()) return null
        var plaintext: ByteArray? = null
        try {
            val packed = file.openRead().use { input ->
                // Read one extra byte to detect oversized records without an unbounded allocation.
                val buffer = ByteArray(MAX_FILE_BYTES + 1)
                var count = 0
                while (count < buffer.size) {
                    val read = input.read(buffer, count, buffer.size - count)
                    if (read < 0) break
                    if (read == 0) throw IOException("Unable to read encrypted record")
                    count += read
                }
                require(count <= MAX_FILE_BYTES) { "Encrypted record is too large" }
                buffer.copyOf(count)
            }
            require(packed.size >= 2 + NONCE_BYTES + TAG_BITS / 8) { "Invalid encrypted record" }
            require((packed[0].toInt() and 0xff) == VERSION) { "Unsupported encrypted record" }
            require((packed[1].toInt() and 0xff) == NONCE_BYTES) { "Invalid encrypted record nonce" }
            val key = existingKey() ?: throw IOException("Owner material key is unavailable")
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(
                Cipher.DECRYPT_MODE,
                key,
                GCMParameterSpec(TAG_BITS, packed.copyOfRange(2, 2 + NONCE_BYTES))
            )
            cipher.updateAAD(associatedData)
            plaintext = cipher.doFinal(packed.copyOfRange(2 + NONCE_BYTES, packed.size))
            val material = OwnerMaterialEncoding.fromJson(JSONObject(String(plaintext, Charsets.UTF_8)))
            validate(material)
            return material
        } catch (_: Exception) {
            throw IOException("Unable to load encrypted owner material")
        } finally {
            plaintext?.fill(0)
        }
    }

    @Synchronized
    fun load(context: Context, expectedSn: String): OwnerMaterial? =
        load(context)?.takeIf { it.sn == expectedSn }

    /** Includes decoded 256-byte SN signature and a cryptographic RSA pair check. */
    fun validate(material: OwnerMaterial) = OwnerMaterialEncoding.validate(material)

    private fun recordFile(context: Context, fileName: String): AtomicFile =
        AtomicFile(File(context.applicationContext.noBackupFilesDir, fileName))

    private fun existingKey(): SecretKey? {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        return store.getKey(KEY_ALIAS, null) as? SecretKey
    }

    private fun getOrCreateKey(): SecretKey {
        existingKey()?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setKeySize(256)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }
}

/** Shared, in-memory encoding; intentionally has no file or logging entry point. */
internal object OwnerMaterialEncoding {
    private val serialPattern = Regex("881[A-Za-z0-9_-]{1,125}")
    private val bindTokenPattern = Regex("[A-Za-z0-9]{32}")
    private val base64Pattern = Regex("[A-Za-z0-9+/]+={0,2}")

    fun toJson(material: OwnerMaterial): JSONObject = JSONObject()
        .put("version", 1)
        .put("sn", material.sn)
        .put("signature", material.signature)
        .put("bindToken", material.bindToken)
        .put("rsaPublicKey", material.rsaPublicKey)
        .put("rsaPrivateKey", material.rsaPrivateKey)

    fun fromJson(value: JSONObject): OwnerMaterial {
        require(value.getInt("version") == 1) { "Unsupported material version" }
        return OwnerMaterial(
            sn = value.getString("sn"),
            signature = value.getString("signature"),
            bindToken = value.getString("bindToken"),
            rsaPublicKey = value.getString("rsaPublicKey"),
            rsaPrivateKey = value.getString("rsaPrivateKey")
        )
    }

    fun validate(material: OwnerMaterial) {
        require(serialPattern.matches(material.sn)) { "A Note Pro serial number is required" }
        require(bindTokenPattern.matches(material.bindToken)) { "A normalized 32-byte bind token is required" }
        val signatureBytes = decodeBase64(material.signature)
        try {
            require(signatureBytes.size == 256) { "SN signature must decode to 256 bytes" }
        } finally {
            signatureBytes.fill(0)
        }
        val publicKey = parsePublicKey(material.rsaPublicKey)
        val privateKey = parsePrivateKey(material.rsaPrivateKey)
        require(publicKey.modulus == privateKey.modulus) { "RSA keys do not match" }
        val challenge = "plaud-owner-key-pair-check-v1".toByteArray(Charsets.US_ASCII)
        val proof = try {
            Signature.getInstance("SHA256withRSA").run {
                initSign(privateKey)
                update(challenge)
                sign()
            }
        } catch (_: Exception) {
            throw IllegalArgumentException("Invalid owner RSA private key")
        }
        try {
            val matches = Signature.getInstance("SHA256withRSA").run {
                initVerify(publicKey)
                update(challenge)
                verify(proof)
            }
            require(matches) { "RSA keys do not match" }
        } catch (_: Exception) {
            throw IllegalArgumentException("RSA keys do not match")
        } finally {
            proof.fill(0)
            challenge.fill(0)
        }
    }

    fun parsePublicKey(pem: String): RSAPublicKey {
        try {
            val factory = KeyFactory.getInstance("RSA")
            val key = when {
                pem.trim().startsWith("-----BEGIN PUBLIC KEY-----") -> {
                    val der = pemBytes(pem, "PUBLIC KEY")
                    try { factory.generatePublic(X509EncodedKeySpec(der)) } finally { der.fill(0) }
                }
                pem.trim().startsWith("-----BEGIN RSA PUBLIC KEY-----") -> {
                    val der = pemBytes(pem, "RSA PUBLIC KEY")
                    try {
                        val reader = DerReader(der).sequence()
                        val modulus = reader.integer()
                        val exponent = reader.integer()
                        reader.requireEnd()
                        factory.generatePublic(RSAPublicKeySpec(modulus, exponent))
                    } finally { der.fill(0) }
                }
                else -> throw IllegalArgumentException("Unsupported public key encoding")
            } as? RSAPublicKey ?: throw IllegalArgumentException("RSA public key is required")
            require(key.modulus.bitLength() >= 2048 && key.publicExponent >= BigInteger.valueOf(3))
            return key
        } catch (_: Exception) {
            throw IllegalArgumentException("Invalid RSA public key; use an RSA PEM of at least 2048 bits")
        }
    }

    private fun parsePrivateKey(pem: String): RSAPrivateKey {
        try {
            val factory = KeyFactory.getInstance("RSA")
            return when {
                pem.trim().startsWith("-----BEGIN PRIVATE KEY-----") -> {
                    val der = pemBytes(pem, "PRIVATE KEY")
                    try { factory.generatePrivate(PKCS8EncodedKeySpec(der)) } finally { der.fill(0) }
                }
                pem.trim().startsWith("-----BEGIN RSA PRIVATE KEY-----") -> {
                    val der = pemBytes(pem, "RSA PRIVATE KEY")
                    try {
                        val reader = DerReader(der).sequence()
                        require(reader.integer() == BigInteger.ZERO) { "Unsupported RSA private key" }
                        val spec = RSAPrivateCrtKeySpec(
                            reader.integer(), reader.integer(), reader.integer(),
                            reader.integer(), reader.integer(), reader.integer(),
                            reader.integer(), reader.integer()
                        )
                        reader.requireEnd()
                        factory.generatePrivate(spec)
                    } finally { der.fill(0) }
                }
                else -> throw IllegalArgumentException("Unsupported private key encoding")
            } as? RSAPrivateKey ?: throw IllegalArgumentException("RSA private key is required")
        } catch (_: Exception) {
            throw IllegalArgumentException("Invalid owner RSA private key")
        }
    }

    private fun pemBytes(pem: String, label: String): ByteArray {
        require(pem.length <= 16_384) { "RSA PEM is too large" }
        val value = pem.trim()
        val begin = "-----BEGIN $label-----"
        val end = "-----END $label-----"
        require(value.startsWith(begin) && value.endsWith(end)) { "Invalid RSA PEM" }
        val body = value.substring(begin.length, value.length - end.length).replace(Regex("\\s+"), "")
        return decodeBase64(body)
    }

    private fun decodeBase64(value: String): ByteArray {
        require(value.length <= 16_384 && base64Pattern.matches(value) && value.length % 4 == 0) {
            "Invalid Base64 encoding"
        }
        val decoded = try { Base64.decode(value, Base64.NO_WRAP) } catch (_: Exception) {
            throw IllegalArgumentException("Invalid Base64 encoding")
        }
        if (Base64.encodeToString(decoded, Base64.NO_WRAP) != value) {
            decoded.fill(0)
            throw IllegalArgumentException("Invalid Base64 encoding")
        }
        return decoded
    }

    /** Small bounded DER reader, used only for two-prime PKCS#1 PEM compatibility. */
    private class DerReader(private val bytes: ByteArray, private var cursor: Int = 0, private val end: Int = bytes.size) {
        fun sequence(): DerReader {
            val contentEnd = elementEnd(0x30)
            val nested = DerReader(bytes, cursor, contentEnd)
            cursor = contentEnd
            requireEnd()
            return nested
        }

        fun integer(): BigInteger {
            val contentEnd = elementEnd(0x02)
            require(contentEnd > cursor && (bytes[cursor].toInt() and 0x80) == 0) { "Invalid DER integer" }
            val encoded = bytes.copyOfRange(cursor, contentEnd)
            cursor = contentEnd
            return try { BigInteger(encoded) } finally { encoded.fill(0) }
        }

        fun requireEnd() { require(cursor == end) { "Unexpected DER data" } }

        private fun elementEnd(tag: Int): Int {
            require(cursor < end && (bytes[cursor++].toInt() and 0xff) == tag) { "Invalid DER tag" }
            require(cursor < end) { "Invalid DER length" }
            val first = bytes[cursor++].toInt() and 0xff
            val length = if (first < 0x80) first else {
                val count = first and 0x7f
                require(count in 1..3 && count <= end - cursor) { "Invalid DER length" }
                var value = 0
                repeat(count) { value = (value shl 8) or (bytes[cursor++].toInt() and 0xff) }
                value
            }
            require(length <= end - cursor) { "Truncated DER data" }
            return cursor + length
        }
    }
}
