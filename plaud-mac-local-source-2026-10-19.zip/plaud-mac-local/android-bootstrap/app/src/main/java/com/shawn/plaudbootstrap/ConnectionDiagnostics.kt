package com.shawn.plaudbootstrap

import java.util.ArrayDeque

/** Bounded, in-memory observations only. Unknown SDK text is never stored or rendered. */
internal class ConnectionDiagnostics(private val startedAtMs: Long) {
    enum class LocalEvent {
        SIGN_REQUESTED, SIGN_CONFIRMED, CANDIDATE_SAVED, CONNECT_REQUESTED, APP_DISCONNECT_CLEANUP
    }

    enum class Outcome {
        IN_PROGRESS, BIND_ACCEPTED, SDK_CONNECT_FAIL, BIND_REJECTED,
        TARGET_MISMATCH, APP_TIMEOUT, PREPARATION_OR_CONNECT_EXCEPTION, SESSION_UNAVAILABLE,
        CANDIDATE_CONFLICT, CANDIDATE_SAVE_FAILED
    }

    private val records = ArrayDeque<String>()
    private var omitted = 0
    private var outcome = Outcome.IN_PROGRESS

    fun local(event: LocalEvent, atMs: Long) = append(event.name, atMs)

    fun state(value: Int, localCleanup: Boolean, atMs: Long) {
        val code = when (value) {
            0 -> if (localCleanup) "STATE_0_LOCAL_CLEANUP" else "STATE_0_DISCONNECTED"
            1 -> "STATE_1_CONNECTED_WAIT_BIND"
            2 -> "STATE_2_SDK_FAILURE"
            else -> "STATE_UNKNOWN"
        }
        append(code, atMs)
    }

    fun stage(stage: String, detail: String?, atMs: Long) {
        // Exact constants from the SHA-pinned AAR; never copy an unrecognized source value.
        val stageCode = stages[stage] ?: "UNKNOWN"
        append("STAGE_$stageCode / ${safeDetail(detail)}", atMs)
    }

    fun bind(status: Int, protocol: Int, atMs: Long) {
        val statusCode = if (status in 0..255) status.toString() else "UNKNOWN"
        val protocolCode = if (protocol in 0..65535) protocol.toString() else "UNKNOWN"
        append("BIND_STATUS_$statusCode / PROTOCOL_$protocolCode", atMs)
    }

    fun finish(result: Outcome) {
        // Cleanup/disconnect callbacks cannot overwrite the first terminal reason.
        if (outcome == Outcome.IN_PROGRESS) outcome = result
    }

    fun render(): String = buildString {
        append("本次连接诊断（仅安全枚举／数值）：\n结果码：")
        append(outcome.name)
        if (omitted > 0) append("\n较早记录已省略：$omitted")
        records.forEach { append('\n'); append(it) }
    }

    private fun append(code: String, atMs: Long) {
        if (records.size == MAX_RECORDS) { records.removeFirst(); omitted++ }
        val elapsed = (atMs - startedAtMs).coerceIn(0, 600000)
        records.addLast("+${elapsed}ms $code")
    }

    companion object {
        private const val MAX_RECORDS = 24
        private val stages = mapOf(
            "start" to "START", "gatt_connect" to "GATT_CONNECT",
            "set_notify" to "SET_NOTIFY", "set_data_notify" to "SET_DATA_NOTIFY",
            "set_battery_notify" to "SET_BATTERY_NOTIFY", "pre_handshake" to "PRE_HANDSHAKE",
            "send_rsa_public" to "SEND_RSA_PUBLIC", "first_handshake" to "FIRST_HANDSHAKE",
            "two_handshake" to "TWO_HANDSHAKE", "handshake_get_ssn" to "HANDSHAKE_GET_SSN",
            "change_handshake_timeout" to "CHANGE_HANDSHAKE_TIMEOUT",
            "sync_time" to "SYNC_TIME", "read_battery" to "READ_BATTERY"
        )
        private val details = mapOf(
            "start" to "START", "send_fail" to "SEND_FAIL",
            "sn_signature_empty" to "SN_SIGNATURE_EMPTY",
            "user_rsa_public_key_empty" to "USER_RSA_PUBLIC_KEY_EMPTY",
            "bind_token_empty" to "BIND_TOKEN_EMPTY", "ok" to "OK",
            "old_protocol_ok" to "OLD_PROTOCOL_OK", "null" to "NULL"
        )
        private val numericDetails = listOf(
            Triple("status_", "STATUS", 0..255),
            Triple("rsp_error_", "RSP_ERROR", -65535..65535),
            Triple("callback_type_error_", "CALLBACK_TYPE_ERROR", -65535..65535),
            Triple("error_", "ERROR", -65535..65535),
            Triple("timeout_", "TIMEOUT", 0..600000),
            Triple("attempt_", "ATTEMPT", 0..100),
            Triple("new_battery_service_port_", "NEW_BATTERY_SERVICE_PORT", 0..65535),
            Triple("old_battery_service_port_", "OLD_BATTERY_SERVICE_PORT", 0..65535)
        )

        private fun safeDetail(raw: String?): String {
            if (raw == null) return "NONE"
            details[raw]?.let { return it }
            // Bound length and numeric syntax before parsing; arbitrary response/error text is UNKNOWN.
            if (raw.length > 64) return "UNKNOWN"
            numericDetails.forEach { (prefix, code, allowed) ->
                if (raw.startsWith(prefix)) {
                    val suffix = raw.substring(prefix.length)
                    if (!suffix.matches(Regex("-?[0-9]{1,6}"))) return "UNKNOWN"
                    val number = suffix.toIntOrNull() ?: return "UNKNOWN"
                    return if (number in allowed) "${code}_$number" else "UNKNOWN"
                }
            }
            return "UNKNOWN"
        }
    }
}
