// Public-source adaptation: application user comes from builder configuration, never a bundled owner identity.
package com.shawn.plaudbootstrap

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.text.InputType
import android.util.Base64
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import sdk.NiceBuildSdk
import sdk.PlaudDeviceAgent
import sdk.PlaudDeviceAgentListener
import com.tinnotech.penblesdk.entity.BleDevice
import timber.log.Timber
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/** Single-device, owner-controlled online bootstrap. No recording, deletion or recovery API. */
class MainActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var operation: Job? = null
    private var timeout: Job? = null
    private var scanTimeout: Job? = null
    private var session = 0
    private var sdkUsed = false
    private var initialized = false
    private var busy = true
    private var scanning = false
    private var processingBind = false
    private var storageBroken = false
    private var currentJwt: String? = null
    private var currentOwner: String? = null
    private var pendingMaterial: OwnerMaterial? = null
    private var cachedMaterial: OwnerMaterial? = null
    private var candidateMaterial: OwnerMaterial? = null
    private var selectedSn: String? = null
    private var recipientPem: String? = null
    private var pendingEnvelope: ByteArray? = null
    private var pendingEnvelopeVerification: BootstrapEnvelope.Verification? = null
    private var permissionAction = 0
    private var connectionDiagnostics: ConnectionDiagnostics? = null
    private var diagnosticTargetSn: String? = null
    private var localDisconnectCleanup = false
    private val discovered = linkedMapOf<String, BleDevice>()
    private lateinit var tokenInput: EditText
    private lateinit var status: TextView
    private lateinit var diagnosticStatus: TextView
    private lateinit var fingerprint: TextView
    private lateinit var cachedStatus: TextView
    private lateinit var targets: RadioGroup
    private lateinit var initializeButton: Button
    private lateinit var scanButton: Button
    private lateinit var connectButton: Button
    private lateinit var stopButton: Button
    private lateinit var importButton: Button
    private lateinit var exportButton: Button
    private lateinit var candidateExportButton: Button

    private val listener = object : PlaudDeviceAgentListener {
        override fun bleScanResult(devices: List<BleDevice>) = runOnUiThread {
            if (!scanning) return@runOnUiThread
            devices.forEach { device ->
                val sn = device.getSerialNumber() ?: return@forEach
                if (!sn.matches(Regex("881[A-Za-z0-9_-]+"))) return@forEach
                if (cachedMaterial != null && cachedMaterial?.sn != sn) return@forEach
                if (discovered.put(sn, device) == null) {
                    val choice = RadioButton(this@MainActivity).apply {
                        id = View.generateViewId()
                        text = "Note Pro · $sn"
                        setOnClickListener { selectedSn = sn; updateButtons() }
                    }
                    targets.addView(choice)
                }
            }
        }

        override fun bleConnectState(state: Int) = runOnUiThread {
            connectionDiagnostics?.state(state, localDisconnectCleanup, SystemClock.elapsedRealtime())
            renderConnectionDiagnostics()
            if (pendingMaterial == null || processingBind) return@runOnUiThread
            if (state == 1) setStatus("BLE 链路已连接，正在等待设备确认绑定。")
            if (state == 0 && !localDisconnectCleanup) setStatus("SDK 报告连接断开（状态 0），尚未确认绑定。下方保留本次阶段记录。")
            if (state == 2) failConnection("SDK 报告连接失败（状态 2）；具体原因以阶段记录为准，不能据此认定设备锁定。未执行恢复或解绑。", ConnectionDiagnostics.Outcome.SDK_CONNECT_FAIL)
        }

        override fun bleConnectStage(sn: String?, stage: String, detail: String?) = runOnUiThread {
            val expected = diagnosticTargetSn ?: return@runOnUiThread
            // SN is used solely for callback correlation and never enters diagnostic records.
            if (sn != null && sn != expected) return@runOnUiThread
            connectionDiagnostics?.stage(stage, detail, SystemClock.elapsedRealtime())
            renderConnectionDiagnostics()
        }

        override fun bleBind(sn: String?, result: Int, protVersion: Int, timezone: Int) = runOnUiThread {
            val expected = pendingMaterial ?: return@runOnUiThread
            if (processingBind) return@runOnUiThread
            connectionDiagnostics?.bind(result, protVersion, SystemClock.elapsedRealtime())
            if (sn != expected.sn || result != 0) {
                val outcome = if (sn != expected.sn) ConnectionDiagnostics.Outcome.TARGET_MISMATCH else ConnectionDiagnostics.Outcome.BIND_REJECTED
                failConnection("未获得所选设备的绑定成功确认；安全状态码见下方记录。未执行恢复或解绑。", outcome)
                return@runOnUiThread
            }
            connectionDiagnostics?.finish(ConnectionDiagnostics.Outcome.BIND_ACCEPTED)
            renderConnectionDiagnostics()
            processingBind = true
            timeout?.cancel()
            persistVerifiedBinding(expected)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        buildUi()
        scope.launch {
            try {
                try {
                    cachedMaterial = withContext(Dispatchers.IO) { OwnerMaterialStore.load(this@MainActivity) }
                    candidateMaterial = withContext(Dispatchers.IO) { OwnerMaterialStore.loadCandidate(this@MainActivity) }
                } catch (cancelled: CancellationException) { throw cancelled
                } catch (_: Exception) {
                    storageBroken = true
                    setStatus("本机保存的凭据无法读取，已停止初始化以避免覆盖。请保留当前安装并检查原因。")
                    return@launch
                }
                updateCachedStatus()
                try {
                    loadRecipient()
                    setStatus(if (candidateMaterial != null && cachedMaterial == null) "已发现待验证候选材料。可直接使用“另存待验证候选 JSON”，无需输入 JWT、初始化或连接。候选未代表绑定成功，不启用第 5 项成功凭据导出；不会自动恢复 SDK 缓存。" else "准备完成。已有加密缓存可直接另存；首次绑定请输入短期 User JWT 初始化，再扫描并手动选择你的 Note Pro。")
                } catch (_: Exception) {
                    recipientPem = null
                    fingerprint.text = "Mac 公钥无法载入，请通过下方按钮重新导入公开 PEM；本机身份缓存未改动。"
                    setStatus("可继续初始化与绑定。导出前需要重新导入并核对 Mac 公钥。")
                }
            } finally {
                busy = false
                updateButtons()
            }
        }
    }

    private fun buildUi() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val padding = (20 * resources.displayMetrics.density).toInt()
            setPadding(padding, padding, padding, padding)
        }
        setContentView(ScrollView(this).apply { addView(content) })
        fun label(text: String, size: Float = 16f): TextView = TextView(this).also {
            it.text = text; it.textSize = size; it.setPadding(0, 12, 0, 12); content.addView(it)
        }
        fun button(text: String, action: () -> Unit): Button = Button(this).also {
            it.text = text; it.isAllCaps = false; it.setOnClickListener { action() }; content.addView(it)
        }
        label("Note Pro → Mac 首次引导 ${BuildConfig.VERSION_NAME}", 24f)
        label("此 App 仅申请并迁移你自己设备的连接身份。连接按钮会执行官方 BLE 绑定及云端登记。已有身份不匹配时会停止，不自动解绑、恢复或覆盖设备绑定。\n\n不会下载或删除录音，不查询或安装固件，不主动同步设备时间。服务区域：PLAUD US。应用用户：${BuildConfig.BOOTSTRAP_APP_USER.ifBlank { "未配置" }}。")
        tokenInput = EditText(this).apply {
            hint = "粘贴短期 User Access Token（JWT）"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            isSingleLine = true
            isSaveEnabled = false
            if (Build.VERSION.SDK_INT >= 26) importantForAutofill = View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
        }
        content.addView(tokenInput)
        initializeButton = button("1. 使用此 JWT 初始化官方 SDK") { initializeSdk() }
        scanButton = button("2. 扫描 Note Pro（仅 881 开头）") { beginScan() }
        label("核对设备完整序列号后，手动选择；不会自动选择附近设备。", 14f)
        targets = RadioGroup(this).also { content.addView(it) }
        connectButton = button("3. 连接并绑定所选设备") { confirmConnection() }
        stopButton = button("停止扫描并断开连接（保留设备绑定）") { stopSession() }
        cachedStatus = label("本机凭据：正在检查。", 14f)
        fingerprint = label("Mac 公钥：未载入。可预置公钥 asset，或手动导入 PEM。", 14f)
        importButton = button("4. 导入 Mac recipient 公钥 PEM") { chooseRecipient() }
        exportButton = button("5. 另存已确认的加密电脑凭据 JSON") { exportEnvelope(BootstrapEnvelope.Verification.CONFIRMED) }
        candidateExportButton = button("另存待验证候选 JSON（仅诊断，未确认绑定）") { exportEnvelope(BootstrapEnvelope.Verification.CANDIDATE) }
        status = label("正在读取本机状态。", 16f)
        diagnosticStatus = label("连接诊断：尚未开始。", 13f)
        label("导出的 JSON 已使用 Mac 公钥加密。只迁移这个加密文件，不分享 JWT、私钥或 App 内部存储。另存文件不会删除本机加密缓存。", 14f)
        updateButtons()
    }

    private fun updateButtons() {
        if (!::initializeButton.isInitialized) return
        initializeButton.isEnabled = !busy && !storageBroken
        tokenInput.isEnabled = !busy
        scanButton.isEnabled = initialized && !busy
        connectButton.isEnabled = initialized && !busy && selectedSn != null
        stopButton.isEnabled = initialized || scanning || pendingMaterial != null
        importButton.isEnabled = !busy
        exportButton.isEnabled = !busy && cachedMaterial != null && recipientPem != null
        candidateExportButton.isEnabled = !busy && candidateMaterial != null && recipientPem != null
    }

    private fun setStatus(message: String) { status.text = message }
    private fun renderConnectionDiagnostics() {
        diagnosticStatus.text = connectionDiagnostics?.render() ?: "连接诊断：尚未开始。"
    }
    private fun updateCachedStatus() {
        val confirmed = if (cachedMaterial == null) "已确认凭据：尚未完成真实绑定。"
        else "已确认凭据：已加密保存一台 Note Pro。"
        val candidate = when {
            candidateMaterial == null -> "连接前候选：尚未保存。"
            cachedMaterial == candidateMaterial -> "连接前候选：已保留，且与已确认材料一致。"
            else -> "连接前候选：已加密保留，仍待验证；仅可另存诊断候选，不代表绑定成功。"
        }
        cachedStatus.text = "$confirmed\n$candidate\n重装或清除 App 数据会失去这些缓存。"
    }

    private fun requiredPermissions(): Array<String> = if (Build.VERSION.SDK_INT >= 31) {
        arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    } else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun permissionsReady(action: Int): Boolean {
        val missing = requiredPermissions().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) return true
        permissionAction = action
        requestPermissions(missing.toTypedArray(), PERMISSIONS)
        return false
    }

    override fun onRequestPermissionsResult(code: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, permissions, results)
        if (code != PERMISSIONS) return
        val action = permissionAction.also { permissionAction = 0 }
        if (results.isEmpty() || results.any { it != PackageManager.PERMISSION_GRANTED }) {
            setStatus("附近设备／蓝牙权限未获准，无法继续扫描或连接。")
        } else if (action == 1) initializeSdk() else if (action == 2) beginScan()
    }

    private data class Claims(val subject: String, val expiry: Long)
    private fun parseClaims(jwt: String): Claims {
        require(jwt.length in 20..16384)
        val parts = jwt.split('.')
        require(parts.size == 3)
        val payload = JSONObject(String(Base64.decode(parts[1], Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING), Charsets.UTF_8))
        val subject = payload.getString("sub")
        val expiry = payload.getLong("exp")
        require(subject.isNotBlank() && expiry > System.currentTimeMillis() / 1000 + 30)
        val appUser = payload.optString("user_id")
        val expectedAppUser = BuildConfig.BOOTSTRAP_APP_USER
        require(expectedAppUser.isNotBlank())
        require(appUser.isBlank() || appUser == expectedAppUser)
        return Claims(subject, expiry)
    }

    private fun initializeSdk() {
        if (busy || storageBroken) return
        if (BuildConfig.BOOTSTRAP_APP_USER.isBlank()) {
            setStatus("尚未配置应用用户。请使用你自己的 bootstrapAppUser 构建此应用后再初始化。")
            return
        }
        if (!permissionsReady(1)) return
        val jwt = tokenInput.text.toString().trim()
        val claims = try { parseClaims(jwt) } catch (_: Exception) {
            setStatus("JWT 格式、有效期或应用用户不符合要求；请使用为当前配置应用用户签发的短期 User JWT。")
            return
        }
        sdkUsed = true
        stopSession(updateText = false)
        busy = true
        updateButtons()
        val request = session
        operation = scope.launch {
            try {
                quietSdkLogs()
                NiceBuildSdk.getPartnerApiManager().updateBaseUrl(PLATFORM_URL)
                PlaudDeviceAgent.listener = listener
                PlaudDeviceAgent.initSDK(applicationContext, jwt, "platform-us.plaud.ai")
                quietSdkLogs()
                setStatus("官方 SDK 正在取得 RSA 身份材料；尚未连接设备。")
                val deadline = System.currentTimeMillis() + 20000
                while (!NiceBuildSdk.isPartnerDataReady() && System.currentTimeMillis() < deadline) delay(200)
                check(NiceBuildSdk.isPartnerDataReady())
                val owner = NiceBuildSdk.resolveHandshakeToken(claims.subject)
                require(owner.matches(Regex("[A-Za-z0-9]{32}")))
                require(cachedMaterial == null || cachedMaterial?.bindToken == owner)
                if (request != session) return@launch
                currentJwt = jwt
                currentOwner = owner
                initialized = true
                tokenInput.text.clear()
                setStatus("官方 SDK 已准备好。现在可扫描并手动选择设备。JWT 只留在当前进程，不写入本 App 配置。")
            } catch (cancelled: CancellationException) { throw cancelled
            } catch (_: Exception) {
                initialized = false
                currentJwt = null
                currentOwner = null
                setStatus("SDK 初始化未完成，或当前 JWT 与已保存的身份不同。请核对区域、用户与有效期后重试。未连接或解绑设备。")
            } finally {
                if (request == session) { busy = false; updateButtons() }
            }
        }
    }

    private fun quietSdkLogs() {
        runCatching { PlaudDeviceAgent.setBleLogLevel(Log.ASSERT) }
        Timber.uprootAll()
    }

    private fun beginScan() {
        if (!initialized || busy || !permissionsReady(2)) return
        stopScanning()
        discovered.clear(); targets.removeAllViews(); selectedSn = null
        scanning = true
        try {
            quietSdkLogs()
            PlaudDeviceAgent.startScan()
            setStatus("正在扫描。让 Note Pro 进入可发现状态，并停止官方 App 占用蓝牙连接。")
            scanTimeout = scope.launch {
                delay(30000)
                stopScanning()
                setStatus(if (discovered.isEmpty()) "没有发现符合条件的 Note Pro；检查蓝牙、定位开关及设备是否被其他 App 占用。" else "扫描结束，请核对并选择设备。")
            }
        } catch (_: Exception) {
            stopScanning()
            setStatus("扫描无法启动。请检查蓝牙开关和权限。")
        }
        updateButtons()
    }

    private fun stopScanning() {
        scanning = false
        scanTimeout?.cancel(); scanTimeout = null
        runCatching { PlaudDeviceAgent.stopScan() }
    }

    private fun confirmConnection() {
        val sn = selectedSn ?: return
        if (busy || !initialized) return
        AlertDialog.Builder(this)
            .setTitle("确认连接并绑定这台 Note Pro")
            .setMessage("设备序列号：$sn\n\n将执行官方 BLE 连接／绑定，成功后向当前开发者应用登记云端绑定，并加密保存实际使用的身份材料。已有身份不匹配时停止；不自动解绑、恢复出厂或删除录音。请确认这是你的设备且已准备迁移。")
            .setPositiveButton("确认连接并绑定") { _, _ -> connectSelected(sn) }
            .setNegativeButton("取消", null).show()
    }

    private fun connectSelected(sn: String) {
        val device = discovered[sn] ?: return
        val owner = currentOwner ?: return
        val jwt = currentJwt ?: return
        if (busy || !initialized) return
        try { parseClaims(jwt) } catch (_: Exception) {
            setStatus("User JWT 已过期或不符合要求。请重新初始化。")
            return
        }
        stopScanning()
        busy = true; processingBind = false; updateButtons()
        connectionDiagnostics = ConnectionDiagnostics(SystemClock.elapsedRealtime())
        diagnosticTargetSn = sn
        localDisconnectCleanup = false
        connectionDiagnostics?.local(ConnectionDiagnostics.LocalEvent.SIGN_REQUESTED, SystemClock.elapsedRealtime())
        renderConnectionDiagnostics()
        val request = ++session
        operation = scope.launch {
            try {
                setStatus("正在为所选设备申请官方 SN 签名。")
                val material = withContext(Dispatchers.IO) {
                    check(NiceBuildSdk.signAndStoreDeviceSn("notepro", sn))
                    val captured = SdkOwnerMaterial.capture(sn, owner)
                    val existing = OwnerMaterialStore.loadCandidate(this@MainActivity)
                    if (existing != null && existing != captured) throw CandidateConflict()
                    try {
                        OwnerMaterialStore.saveCandidate(this@MainActivity, captured)
                    } catch (_: Exception) { throw CandidateSaveFailure() }
                    captured
                }
                if (request != session) return@launch
                pendingMaterial = material
                candidateMaterial = material
                updateCachedStatus()
                connectionDiagnostics?.local(ConnectionDiagnostics.LocalEvent.SIGN_CONFIRMED, SystemClock.elapsedRealtime())
                connectionDiagnostics?.local(ConnectionDiagnostics.LocalEvent.CANDIDATE_SAVED, SystemClock.elapsedRealtime())
                setStatus("正在连接设备，等待绑定状态 0；不会自动恢复已有绑定。")
                quietSdkLogs()
                connectionDiagnostics?.local(ConnectionDiagnostics.LocalEvent.CONNECT_REQUESTED, SystemClock.elapsedRealtime())
                renderConnectionDiagnostics()
                PlaudDeviceAgent.connectBleDevice(device)
                timeout = scope.launch {
                    delay(40000)
                    if (request == session && !processingBind) failConnection("等待设备绑定超时；本次阶段与断开记录保留在下方。已清理普通连接，未执行恢复或解绑。", ConnectionDiagnostics.Outcome.APP_TIMEOUT)
                }
            } catch (cancelled: CancellationException) { throw cancelled
            } catch (_: CandidateConflict) {
                if (request == session) failConnection("本次 SDK 实际材料与已保留候选不同，已停止发起连接。旧候选未覆盖；不会自动恢复或替换 SDK 缓存。", ConnectionDiagnostics.Outcome.CANDIDATE_CONFLICT, cleanup = false)
            } catch (_: CandidateSaveFailure) {
                if (request == session) failConnection("连接前候选未能加密保存，已停止发起连接。保留已有记录，不导出明文。", ConnectionDiagnostics.Outcome.CANDIDATE_SAVE_FAILED, cleanup = false)
            } catch (_: Exception) {
                if (request == session) failConnection("签名、SDK 实际缓存校验或连接未完成；已保存的候选材料继续保留，尚未确认绑定。请保留 App 数据。", ConnectionDiagnostics.Outcome.PREPARATION_OR_CONNECT_EXCEPTION)
            }
        }
    }

    private fun persistVerifiedBinding(expected: OwnerMaterial) {
        val jwt = currentJwt ?: return failConnection("会话身份不可用，本次诊断已保留。", ConnectionDiagnostics.Outcome.SESSION_UNAVAILABLE)
        val request = session
        operation = scope.launch {
            var saved = false
            try {
                setStatus("设备已确认绑定；先加密保存设备实际接受的身份材料。")
                val actual = withContext(Dispatchers.IO) {
                    val actual = SdkOwnerMaterial.capture(expected.sn, expected.bindToken)
                    check(actual == expected)
                    OwnerMaterialStore.save(this@MainActivity, actual)
                    actual
                }
                if (request != session) return@launch
                saved = true
                cachedMaterial = actual
                pendingMaterial = null
                updateCachedStatus()
                setStatus("实际身份已由 Android Keystore 加密保存；正在登记云端绑定。")
                val code = withContext(Dispatchers.IO) { registerCloudBinding(jwt, expected.sn) }
                check(code in 200..299) { "Cloud registration declined" }
                if (request != session) return@launch
                setStatus("设备绑定和云端登记已完成，实际 RSA／SN 签名已由 Android Keystore 加密保存。可导入 Mac 公钥并另存加密凭据。")
            } catch (cancelled: CancellationException) { throw cancelled
            } catch (_: Exception) {
                if (request == session) {
                    if (saved) setStatus("设备已接受 BLE 绑定，本机身份已加密保存，可导出保管；云端登记未确认成功。请检查开发者后台状态，不会自动撤销任何绑定。")
                    else setStatus("设备已接受 BLE 绑定，但本机加密保存未完成。请保持 App 打开并检查原因；不会自动撤销或覆盖绑定。")
                }
            } finally {
                if (request == session) { busy = false; updateButtons() }
            }
        }
    }

    private fun registerCloudBinding(jwt: String, sn: String): Int {
        val connection = URL("$PLATFORM_URL/developer/api/open/partner/sdk/bind").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.instanceFollowRedirects = false
            connection.connectTimeout = 10000; connection.readTimeout = 10000
            connection.doOutput = true
            connection.setRequestProperty("Authorization", "Bearer $jwt")
            connection.setRequestProperty("Content-Type", "application/json")
            val body = JSONObject().put("type", "notepro").put("sn", sn).toString().toByteArray(Charsets.UTF_8)
            connection.setFixedLengthStreamingMode(body.size)
            connection.outputStream.use { it.write(body) }
            val code = connection.responseCode
            if (code in 200..299) {
                val response = connection.inputStream.use { readBounded(it, 65536) }
                require(response.isNotEmpty())
                val objectBody = JSONObject(String(response, Charsets.UTF_8))
                require(objectBody.has("is_bind") && objectBody.getBoolean("is_bind"))
                if (objectBody.has("sn")) require(objectBody.getString("sn") == sn)
            } else connection.errorStream?.close()
            return code
        } finally { connection.disconnect() }
    }

    private fun failConnection(message: String, outcome: ConnectionDiagnostics.Outcome, cleanup: Boolean = true) {
        timeout?.cancel(); timeout = null
        pendingMaterial = null; processingBind = false; busy = false
        connectionDiagnostics?.finish(outcome)
        if (cleanup) {
            localDisconnectCleanup = true
            connectionDiagnostics?.local(ConnectionDiagnostics.LocalEvent.APP_DISCONNECT_CLEANUP, SystemClock.elapsedRealtime())
            runCatching { PlaudDeviceAgent.disconnect() }
        }
        setStatus(message); renderConnectionDiagnostics(); updateButtons()
    }

    private fun stopSession(updateText: Boolean = true) {
        ++session
        operation?.cancel(); timeout?.cancel()
        stopScanning()
        if (connectionDiagnostics != null) {
            localDisconnectCleanup = true
            connectionDiagnostics?.local(ConnectionDiagnostics.LocalEvent.APP_DISCONNECT_CLEANUP, SystemClock.elapsedRealtime())
            renderConnectionDiagnostics()
        }
        runCatching { PlaudDeviceAgent.disconnect() }
        pendingMaterial = null; currentJwt = null; currentOwner = null
        initialized = false; processingBind = false; busy = false
        if (updateText) setStatus("已停止并断开；设备绑定与本机加密缓存保留。重新连接需要再次输入 User JWT。")
        updateButtons()
    }

    private fun loadRecipient() {
        val imported = File(filesDir, RECIPIENT_FILE)
        val pem = if (imported.isFile) imported.inputStream().use { String(readBounded(it, 16384), Charsets.US_ASCII) }
        else try { assets.open(RECIPIENT_FILE).use { String(readBounded(it, 16384), Charsets.US_ASCII) } } catch (_: java.io.FileNotFoundException) { null }
        if (pem != null) {
            BootstrapEnvelope.fingerprint(pem)
            if (!imported.exists()) imported.writeText(pem, Charsets.US_ASCII)
            acceptRecipient(pem)
        }
    }

    private fun acceptRecipient(pem: String) {
        val value = BootstrapEnvelope.fingerprint(pem)
        recipientPem = pem
        fingerprint.text = "Mac recipient 公钥 SHA-256（请与 Mac 核对）：\n$value"
        updateButtons()
    }

    private fun chooseRecipient() {
        if (busy) return
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE)
        }, IMPORT_RECIPIENT)
    }

    private fun exportEnvelope(verification: BootstrapEnvelope.Verification) {
        val pem = recipientPem ?: return
        val candidate = verification == BootstrapEnvelope.Verification.CANDIDATE
        if (busy || (if (candidate) candidateMaterial else cachedMaterial) == null) return
        busy = true; updateButtons()
        scope.launch {
            try {
                pendingEnvelope?.fill(0)
                pendingEnvelope = null
                pendingEnvelopeVerification = null
                pendingEnvelope = withContext(Dispatchers.IO) {
                    val material = (if (candidate) OwnerMaterialStore.loadCandidate(this@MainActivity)
                        else OwnerMaterialStore.load(this@MainActivity)) ?: error("No saved material")
                    BootstrapEnvelope.build(material, pem, verification)
                }
                pendingEnvelopeVerification = verification
                startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    type = "application/json"; addCategory(Intent.CATEGORY_OPENABLE)
                    putExtra(Intent.EXTRA_TITLE, if (candidate) "pc-bootstrap-candidate-v1.json" else "pc-bootstrap-v1.json")
                }, EXPORT_ENVELOPE)
            } catch (cancelled: CancellationException) { throw cancelled
            } catch (_: Exception) {
                pendingEnvelope?.fill(0); pendingEnvelope = null
                pendingEnvelopeVerification = null
                setStatus("无法生成加密凭据包；未导出任何明文。")
            } finally { busy = false; updateButtons() }
        }
    }

    @Deprecated("Platform document picker callback")
    override fun onActivityResult(code: Int, result: Int, data: Intent?) {
        super.onActivityResult(code, result, data)
        if (code != IMPORT_RECIPIENT && code != EXPORT_ENVELOPE) return
        val uri = data?.data
        if (result != RESULT_OK || uri == null) {
            if (code == EXPORT_ENVELOPE) {
                pendingEnvelope?.fill(0); pendingEnvelope = null; pendingEnvelopeVerification = null
            }
            setStatus("文件操作已取消。")
            return
        }
        busy = true; updateButtons()
        scope.launch {
            try {
                if (code == IMPORT_RECIPIENT) {
                    val pem = withContext(Dispatchers.IO) {
                        val value = contentResolver.openInputStream(uri)?.use { String(readBounded(it, 16384), Charsets.US_ASCII) }
                            ?: error("Public key file unavailable")
                        BootstrapEnvelope.fingerprint(value)
                        File(filesDir, RECIPIENT_FILE).writeText(value, Charsets.US_ASCII)
                        value
                    }
                    acceptRecipient(pem)
                    setStatus("已载入 Mac 公钥。请先与 Mac 核对上方指纹，再导出加密凭据。")
                } else {
                    val bytes = pendingEnvelope ?: error("Export session expired")
                    val verification = pendingEnvelopeVerification ?: error("Export type unavailable")
                    withContext(Dispatchers.IO) {
                        val output = contentResolver.openOutputStream(uri, "wt") ?: error("Destination unavailable")
                        output.use { it.write(bytes); it.flush() }
                    }
                    setStatus(if (verification == BootstrapEnvelope.Verification.CANDIDATE)
                        "已另存加密 pc-bootstrap-candidate-v1.json，仅供 Mac 诊断验证。候选未确认绑定，不是成功凭据；此次另存未发起 SDK 初始化或设备连接，本机候选保持原样。"
                    else "已另存加密 pc-bootstrap-v1.json。将该已确认凭据交给配套 Mac 导入；本机缓存与设备录音均保留。")
                }
            } catch (cancelled: CancellationException) { throw cancelled
            } catch (_: Exception) {
                setStatus("文件读取或写入失败；未导出明文身份。请重新选择文件或保存位置。")
            } finally {
                if (code == EXPORT_ENVELOPE) {
                    pendingEnvelope?.fill(0); pendingEnvelope = null; pendingEnvelopeVerification = null
                }
                busy = false; updateButtons()
            }
        }
    }

    override fun onDestroy() {
        // Opening, exporting cached material and closing must not touch SDK/device state.
        if (sdkUsed) {
            stopSession(updateText = false)
            PlaudDeviceAgent.listener = null
        }
        pendingEnvelope?.fill(0); pendingEnvelope = null
        pendingEnvelopeVerification = null
        scope.cancel()
        super.onDestroy()
    }

    private fun readBounded(input: InputStream, maximum: Int): ByteArray {
        val output = ByteArrayOutputStream()
        val buffer = ByteArray(4096)
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            require(output.size() + count <= maximum)
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }

    companion object {
        private const val PLATFORM_URL = "https://platform-us.plaud.ai"
        private const val RECIPIENT_FILE = "pc-bootstrap-public.pem"
        private const val PERMISSIONS = 20
        private const val IMPORT_RECIPIENT = 21
        private const val EXPORT_ENVELOPE = 22
    }

    private class CandidateConflict : Exception()
    private class CandidateSaveFailure : Exception()
}
