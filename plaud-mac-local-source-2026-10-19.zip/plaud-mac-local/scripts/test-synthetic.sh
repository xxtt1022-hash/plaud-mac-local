#!/bin/sh
# Tests use temporary synthetic fixtures/mocks; HTTP tests bind loopback only.
set -eu
PROJECT_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
exec "$PROJECT_ROOT/.venv/bin/python" -m unittest discover -s "$PROJECT_ROOT/mac-adapter/tests" -v
