#!/usr/bin/env python3
"""Build a fresh local .app using explicit private paths; never start the backend."""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import plistlib
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--python", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True, help="New destination ending in .app")
    args = parser.parse_args()
    os.umask(0o077)
    project = Path(__file__).resolve().parents[1]
    config = args.config.expanduser().resolve(strict=True)
    python = args.python.expanduser().absolute()
    if not python.is_file() or not os.access(python, os.X_OK):
        raise ValueError("An executable configured Python path is required")
    settings = json.loads(config.read_text())
    library = Path(settings["libraryRoot"]).expanduser()
    if not library.is_absolute() or settings.get("port") != 8769:
        raise ValueError("An absolute libraryRoot and port 8769 are required")
    library = library.resolve(strict=True)
    if not (library / ".access-token").is_file():
        raise ValueError("Initialize the manager once before building its desktop entry")
    destination = args.output.expanduser().absolute()
    if destination.suffix != ".app" or destination.exists() or destination.is_symlink():
        raise ValueError("Use a new .app destination; existing bundles are never replaced")
    contents = destination / "Contents"
    resources, binaries = contents / "Resources", contents / "MacOS"
    resources.mkdir(parents=True, mode=0o700)
    binaries.mkdir(mode=0o700)
    executable = binaries / "PLAUDLocalLauncher"
    subprocess.run(["xcrun", "swiftc", str(project / "launcher" / "Launcher.swift"),
                    "-framework", "AppKit", "-o", str(executable)], check=True)
    info = {"CFBundleIdentifier": "local.plaudmac.launcher", "CFBundleName": "PLAUD 录音管理",
            "CFBundleDisplayName": "PLAUD 录音管理", "CFBundleExecutable": executable.name,
            "CFBundlePackageType": "APPL", "CFBundleVersion": "1", "CFBundleShortVersionString": "1.0",
            "LSUIElement": True, "NSHighResolutionCapable": True,
            "NSBluetoothAlwaysUsageDescription": "用于在你明确操作时连接所选 PLAUD 设备并接收录音。"}
    runtime = {"configPath": str(config), "pythonPath": str(python),
               "scriptPath": str(project / "mac-adapter" / "recording_manager.py"),
               "workspacePath": str(project), "logPath": str(library / "launcher.log"),
               "receiptPath": str(library / "launcher-receipt.json")}
    for path, value in ((contents / "Info.plist", info), (resources / "LauncherSettings.plist", runtime)):
        with path.open("xb") as stream:
            plistlib.dump(value, stream)
    subprocess.run(["/usr/bin/codesign", "--force", "--sign", "-", "--timestamp=none",
                    str(destination)], check=True)
    subprocess.run(["/usr/bin/codesign", "--verify", "--strict", str(destination)], check=True)
    print("Local ad-hoc launcher built and signature verified; it is not a notarized distribution.")
    print("Its configuration contains local paths: do not publish the generated bundle.")


if __name__ == "__main__":
    if sys.platform != "darwin":
        raise SystemExit("The native launcher requires macOS and Xcode Command Line Tools")
    main()
