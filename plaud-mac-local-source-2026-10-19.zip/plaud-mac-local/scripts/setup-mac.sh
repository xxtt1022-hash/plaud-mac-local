#!/bin/sh
# Explicit dependency setup only. No device/API/Keychain/model/CLI-login operation.
set -eu
umask 077
PROJECT_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
UPSTREAM_COMMIT=4f52d432b2f4d838ef10c7674d6b49f9bafc7005
UPSTREAM_DIR="$PROJECT_ROOT/plaud-direct-pc-research"
PYTHON_BIN=${PYTHON_BIN:-python3.12}
if [ "$(uname -s)" != Darwin ]; then
  echo 'This setup targets macOS; device acceptance was on Apple Silicon.' >&2
  exit 1
fi
"$PYTHON_BIN" -c 'import sys; assert sys.version_info >= (3, 11), "Python 3.11+ required"'
if [ ! -e "$UPSTREAM_DIR" ]; then
  git clone --no-checkout https://github.com/Shawn-TKD/plaud-direct-pc-research.git "$UPSTREAM_DIR"
  git -C "$UPSTREAM_DIR" fetch origin "$UPSTREAM_COMMIT"
  git -C "$UPSTREAM_DIR" checkout --detach "$UPSTREAM_COMMIT"
fi
if [ "$(git -C "$UPSTREAM_DIR" rev-parse HEAD)" != "$UPSTREAM_COMMIT" ]; then
  echo 'Existing upstream checkout differs; refusing to reset your checkout.' >&2
  exit 1
fi
git -C "$UPSTREAM_DIR" diff --quiet
git -C "$UPSTREAM_DIR" diff --cached --quiet
if [ ! -d "$PROJECT_ROOT/.venv" ]; then
  "$PYTHON_BIN" -m venv "$PROJECT_ROOT/.venv"
fi
"$PROJECT_ROOT/.venv/bin/python" -m pip install -r "$PROJECT_ROOT/requirements-macos.lock.txt"
"$PROJECT_ROOT/.venv/bin/python" -m pip install --no-deps -e "$UPSTREAM_DIR/pc-bridge"
echo 'Dependencies prepared. No receiver identity, Keychain item or device connection was created.'
echo 'Next: read docs/SETUP.md; configure private paths; run synthetic tests separately.'
