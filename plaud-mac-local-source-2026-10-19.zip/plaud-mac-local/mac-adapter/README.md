> 公开副本说明：本文保留本次研究与验收记录；新安装入口以 [复现说明](../docs/SETUP.md) 为准。下列私密路径均为占位示例，不代表新机器已存在接收器、账号、绑定或录音。公开副本不会自动导入原作者状态。

# Local Mac adapter — implementation and acceptance status

The BLE core has no cloud API, device deletion, depair, reset, OTA or provisioning command.
The separate `cloud_auth.py` and `token_bridge.py` helpers use only the documented official
authentication flow. The BLE core is designed for the same owner's **already paired** identity produced by the research
Android app's `PcBootstrapExporter.kt`, not for extracting credentials from the official
PLAUD Android app. It does not make a China-region device compatible with the US developer
platform and does not override an existing binding.

Files are encrypted at rest with scrypt and AES-256-GCM under a passphrase of 20 or more
characters. The active receiver uses a high-entropy random passphrase held in Mac Keychain;
the lower-level manual tools can instead prompt with `getpass`. A passphrase is never an
argument or environment variable. The recipient RSA private key and owner identity use separate authenticated
purposes. State directory permissions are `0700`; files are `0600`. Python cannot promise
secure erasure of immutable secret objects in memory.

## Current real-device acceptance — 2026-10-19

The user accepted the scope of one **23.4-second real Note Pro recording**. A 1–3 minute
sample, long-duration recording and stability tests were not performed. This local run
completed normal Mac enrollment, independent reconnect, exact recording download,
decryption, complete audio decoding, audible playback and source retention verification.

After the user reconnected the original consumer app, confirmed zero pending recordings
and playable important recordings, and performed an **online unbind**, the device changed
from an existing-key RSA response to the supported new-public-key request. The same
preserved Android candidate then authenticated PLAUD.AI and received CMD 1 status zero.
The Mac sealed that accepted identity before cloud registration, which returned HTTP 200
and strict `is_bind=true`. The developer portal visibly lists the target device.

The independent reconnect used the saved confirmed identity with no new public-key
registration. It reported 59% battery and one recording. Exactly 100,864 encrypted bytes
were downloaded; after download the same session and size remained in the device list.
No Mac key-clear, recovery, depair or recording-deletion command was sent.

The encrypted header has version 1, size 512, channels 1, counter 0 and segment 0.
Its duration is zero and user-id semantics are not established; neither is used as an
acceptance assertion. Decryption yielded an Ogg multiplex containing two logical streams.
All 133 page CRCs and per-stream sequences/EOS checked. `ogg_demux.py` selects the unique
Opus stream by its headers and preserves every selected page byte for byte. It produces
the same 96,708-byte stream as the initial independently inspected extraction.

Local FFmpeg strict full-file decoding produced mono, 48 kHz, 16-bit WAV with 1,123,200
frames (23.4 seconds). The Ogg container timeline is 23.42 seconds; it is deliberately
reported separately. macOS afplay completed with exit zero and the user confirmed clear
speech and normal speed. No audio was sent to cloud transcription. Native afinfo could
read the resulting WAV but could not open this Opus/Ogg file; FFmpeg was used locally.

This is an accepted research prototype, not a new one-click or background-sync application.
The lower-level commands below retain their documented manual-passphrase behavior; the
active receiver is Keychain-backed. No new precise-target download CLI is claimed.

## Added local recording manager — 2026-10-19

`recording_manager.py --config LOCAL_CONFIG.json --open` adds a loopback-only browser UI
on this Mac. The user chose original-language transcription and manual confirmation
before any device cleanup. No deletion operation is implemented or exposed by the UI.
The Mac installation lives in `/ABS/PATH/TO/PRIVATE/plaud-runtime` in the active task,
with an executable `.command` launcher. It depends on the task venv, pinned upstream
checkout and existing confirmed encrypted receiver state; it is not a portable package.

`recording_library.py` keeps a SQLite catalog and private per-record directories. The
catalog associates original encrypted PLAUD files, selected Opus audio, optional WAV,
titles, projects, tags, notes and versioned imported transcript/minutes text. Audio is
copied and SHA-256 checked; changed/missing audio revokes integrity, decode and playback
claims. A same-disk duplicate is not recorded as an independent backup. Device snapshots
carry observation times and must not be mistaken for a continuously connected device.

`device_library.py` / `recording_tasks.py` expose explicit exact-SN refresh and selected
session+size reception with the confirmed owner identity. There is no latest-file
selection, automatic sync, cloud upload, enrollment or deletion in this path. The UI
runs BLE in a main-thread subprocess so CoreBluetooth is not driven from an HTTP worker.
New downloads retain the source, validate the already accepted profile, select validated
Ogg pages and strictly decode the full file before claiming success. Only the existing
23.4-second audio profile has real-device acceptance. Unknown profiles stop safely while
retaining local artifacts. The current transfer limit is 128 MiB; transfer and decoding
each have a 120-second limit. Long recordings remain untested.

The UI offers playback, metadata editing, hash revalidation, text version saving, search
and export of a local Markdown index/task. Automatic processing is now connected:
`auto_pipeline.py` serializes jobs in a private SQLite queue. New verified imports are
queued for local original-language ASR, then Codex-generated minutes. The existing
23.4-second sample completed this full automatic path with transcript version 1 and
minutes version 1. No audio was uploaded; the transcript text was sent to OpenAI through
the already authenticated official Codex CLI. This is not a fully offline minutes path.

`asr_transcribe.py` validates the pinned model hash, snapshots the selected audio, strictly
decodes to mono 16 kHz PCM16, then invokes the existing Homebrew whisper-cli without a
translation flag. It retains TXT/SRT/JSON, normalized timestamp segments and Markdown.
The model is `ggml-large-v3-turbo-q5_0.bin`, 574,041,195 bytes, SHA-256
`394221709cd5ad1f40c46e6031ca61bce88931e6e088c188294c6d5a55ffa7e2`, from
`ggerganov/whisper.cpp` revision `5359861c739e955e79d9a303bcbc70fb988958b1` on Hugging Face.
The real sample produced four Chinese segments. Transcript accuracy is not certified;
proper names and unclear phrases require review against the original audio.

`codex_minutes.py` sends only title/transcript JSON on stdin to official Codex CLI
0.163alpha using the existing ChatGPT login. It ignores user config/rules, disables
shell/web/MCP/apps/skills/hooks and other tool channels, uses a new empty work directory,
ephemeral mode and a read-only sandbox. Known text events and one exact pre-turn
fail-closed startup warning are accepted; unknown errors or any real tool event fail.
No model name is guessed when the CLI event stream does not provide one. The response
must match a JSON schema. Action evidence, explicit owners and deadlines must occur
verbatim in the input. Missing decisions/actions remain empty/unspecified. All output
is a reviewable draft, not an automatically accepted meeting record.

The library migrates old text records without replacing them and records generation
source, model where known, input hashes and versions. Generated writes compare their
input and target versions in the same transaction, so a user's concurrent edit is not
overwritten. A failed minutes job keeps the completed transcript; retry reuses it.
Manual transcript updates schedule at most one successor minutes job. Previously
generated minutes bound to an older transcript are identified as outdated and refreshed
by the queued update or an explicit minutes action. Interrupted jobs retain their artifacts and can be
retried. Existing complete pairs are not regenerated merely by restarting the server.

The server binds only `127.0.0.1`, checks exact Host and capability path for all routes,
requires same-origin JSON POSTs, serves only allowlisted record artifacts, and does not
log capability URLs or user content. Playable audio/text are private local files, not
additionally encrypted at rest. FileVault was not inspected. Keys stay in the separate
existing encrypted receiver state and Keychain. Do not move/delete those dependencies.

The initial failures remain useful boundaries: ASCII-only advertisement parsing missed
the device's packed binary serial, and an offline consumer-app removal did not lead to
a new-key request. These were resolved by the local exact-SN parser and the user's online
migration. A read-only US binding GET returned HTTP 403; it was not bypassed or treated
as unbound. The later normal binding POST succeeded.

`candidate_rsa_structure.py` is a one-time local RAM diagnostic, not a constant-time
cryptographic implementation or a replacement for authenticated challenge verification.
It must not be exposed as a network service or padding oracle. Candidate material is not
an owner identity until the verified BLE proof permits the explicit confirmed transition.

## Explicit normal first pairing after a verified user migration

`first_pair.py` is a separate opt-in normal enrollment helper. By default it only
observes. The explicit `--enroll-if-requested` flag permits the existing candidate
public key only after a supported `65041 00` request, followed by CMD 1 only after
the candidate private key authenticates the complete PLAUD.AI challenge. Byte zero
is this implementation's restrictive compatibility gate, not a documented SDK
success-code claim. An existing-key challenge that fails validation is terminal.
No key-clear, recovery, depair, new-key generation or recording command exists.

`pairing_acceptance.py --execute-normal-pairing` first authenticates the configured
stable application user and matches JWT.sub to the candidate bind token. Only a
verified challenge plus an authenticated CMD 1 integer status zero permits a new
O_EXCL/0600 encrypted confirmed owner store. It verifies the saved identity by
read-back before `binding_registration.py` attempts the one official cloud bind
POST. Cloud failure preserves the accepted identity and never performs a rollback.
The current candidate envelope remains unchanged throughout.

The sanitized release copy passed an independent run of all 174 adapter tests,
including the recording manager, in 18.512 seconds. First-pair, orchestration and
Ogg-selection code received independent read-only review. Synthetic tests are separate
from the real 23.4-second device acceptance above. During that acceptance, the Android
candidate file remained encrypted and unchanged; the Mac separately saved an encrypted
confirmed owner identity. No such identity is included in this release.

## Prerequisites and verification

Use an existing Python 3.11+ runtime with `cryptography` and, for actual BLE only, `bleak`.
The primary operator installed the upstream package and its dependencies into the task's
isolated `.venv` (Python 3.12.14). The sibling upstream source checkout is pinned to
`4f52d432b2f4d838ef10c7674d6b49f9bafc7005`; the adapter does not modify it.

On 2026-10-19 the original debugging checkout first passed 173 tests, followed by
one added pipeline test and eight targeted regressions, for 174 distinct adapter
tests. The sanitized release directory then independently passed **174 tests in
18.512 seconds**, using the existing acceptance Python environment and a temporary
sibling link to the pinned upstream source, removed afterwards. This did not install
dependencies on a clean machine, contact a device, or call official authentication.
The unchanged upstream suite's **13 tests** passed earlier in the session. A further
**7 Java boundary-check programs** passed against the compiled `ConnectionDiagnostics`
Kotlin class; those checks do not establish Android runtime behavior or a successful
Android connection. See [acceptance boundaries](../docs/验收边界.md).
Reproduce the adapter tests with:

```sh
.venv/bin/python -m unittest discover -s mac-adapter/tests -v
```

The tests create synthetic credentials, reproduce Android RSA-OAEP-SHA256 with explicit
MGF1-SHA256 and AES-256-GCM/AAD, check wrong passwords/tampering/SN mismatch/RSA mismatch,
and ensure the BLE client refuses the new-key enrollment branch. Keychain and cloud-helper
unit tests use fake storage and synthetic tokens. Token-view tests cover Host/path/TTL and
in-memory QR output; local-transfer tests cover public-file selection, upload validation,
overwrite rejection and service expiry. Unit tests do not establish a Note Pro connection.

## Lower-level manual commands

These examples document the manual-passphrase variant, not the active Keychain-backed
receiver. **Do not run `init-recipient` or `receiver_state.py init` for this task again.**
The existing receiver is `/ABS/PATH/TO/PRIVATE/receiver-state`; use the receiver functions described below.

```sh
python3 mac-adapter/mac_adapter.py init-recipient --state-dir /ABS/PATH/TO/PRIVATE/owner-state
```

Only `/ABS/PATH/TO/PRIVATE/owner-state/pc-bootstrap-public.pem` may be copied into the authorized
research Android app's private files directory as `pc-bootstrap-public.pem`. The official
PLAUD app does not implement this exporter. After the research app has valid cached owner
credentials, it emits `pc-bootstrap-v1.json`. Retrieve only that encrypted envelope.

```sh
python3 mac-adapter/mac_adapter.py import-android \
  --state-dir /ABS/PATH/TO/PRIVATE/owner-state --package /ABS/PATH/TO/PRIVATE/pc-bootstrap-v1.json --sn YOUR_EXACT_SN
python3 mac-adapter/mac_adapter.py scan \
  --upstream plaud-direct-pc-research --sn YOUR_EXACT_SN
python3 mac-adapter/mac_adapter.py status \
  --upstream plaud-direct-pc-research --state-dir /ABS/PATH/TO/PRIVATE/owner-state --sn YOUR_EXACT_SN
python3 mac-adapter/mac_adapter.py download-latest \
  --upstream plaud-direct-pc-research --state-dir /ABS/PATH/TO/PRIVATE/owner-state \
  --sn YOUR_EXACT_SN --output-dir /ABS/PATH/TO/PRIVATE/selected-download
```

Scanning matches the full decoded advertised serial number, including the real device's
8-byte packed-hex representation; it never selects an arbitrary PLAUD device by name. The
packed-hex fix lives in the local helper, not the pinned upstream checkout. The authentication
path reuses cached material and stops if the device
asks to register a client RSA key. CMD 1 remains necessary for the normal owner session.
The adapter does not expose a method to clear an existing identity or change owner.

`download-latest` requires a new destination directory and downloads only the newest
advertised recording, using the upstream CMD 28 path. No file-deletion command is sent.
The returned SHA-256 is a local artifact fingerprint, not an independent transfer CRC check;
upstream captures the firmware tail CRC but does not validate its algorithm. Confirm the
same session still appears in a subsequent device file-list read as the retention check.

This command stops at the encrypted `.plaud` recording. This local Note Pro sample decrypted
to a multiplexed Ogg, not fixed 80-byte raw Opus frames. After local decryption, the reviewed
`ogg_demux.py --input DECRYPTED.ogg --output NEW_AUDIO.ogg` validates every logical stream
and copies the unique Opus stream's original pages. Its OpusTags check validates structural
lengths and packet placement, not full tag-text semantics. Use local FFmpeg for complete
WAV decoding; `containerTimelineSeconds` is not decoded duration. Other recording profiles
and nonzero ChaCha counters remain outside the real-file evidence here.

For an existing downloaded file, the `decrypt` command calls only the upstream local audio
decryption function and reports non-identity header fields. Its output is not automatically
wrapped or described as playable:

```sh
python3 mac-adapter/mac_adapter.py decrypt \
  --upstream plaud-direct-pc-research --state-dir /ABS/PATH/TO/PRIVATE/owner-state \
  --sn YOUR_EXACT_SN --input /ABS/PATH/TO/PRIVATE/selected-download/SESSION.plaud \
  --output /ABS/PATH/TO/PRIVATE/selected-download/decrypted-audio.bin
```

## Compatibility and storage boundaries

- The real acceptance applies to this owned Note Pro, current device state and this Mac.
  It does not establish support for all firmware versions, regions or devices.
- A signed-in consumer account does not supply Embedded developer credentials. Official
  app and Embedded bindings are separate; the normal migration above was completed by
  the user after checking their recordings. Do not repeat unbind or first enrollment as
  a routine download operation.
- The Mac workflow intentionally retained its source recording, verified by a post-download
  file list. It has no automatic source cleanup. Device storage will accumulate without an
  explicit later retention/deletion policy. This acceptance did not establish the consumer
  app's general retention/deletion policy.
- Firmware transfer CRC was received, not independently recomputed. Actual downloaded
  length, all Ogg page CRCs, complete strict decoding and user playback confirmation passed.
- Keep the existing receiver, confirmed owner file and local Keychain items. Do not rerun
  initialization or regenerate keys as a maintenance step. Private state is excluded from
  the source bundle.

## SDK application credentials in Mac Keychain

`keychain_credentials.py` adds exactly one macOS GenericPassword item using PyObjC Security:

- Fixed service: `codex.plaud.notepro.mac-local`.
- Account: the SDK application's Client ID.
- Value: Client ID and Client Secret JSON, stored only by Keychain.
- Uses the local legacy login Keychain, with no synchronization opt-in or Data Protection
  attributes; an existing item causes an error instead of an update. Data uses explicit NSData.
- CLI accepts only `clientId` and `clientSecret` in stdin JSON. Never put that JSON in a
  shell command, argument, log or intermediate plaintext file. The parent operator must
  supply it directly through process stdin without displaying it.
- Python `read_credentials(client_id)` returns a redacted-repr `AppCredentials` object
  for in-memory use. There is no CLI that prints or exports its contents.

The primary operator has successfully added and read back the actual application credential
item using the Mac Keychain API, without plaintext credential files. Fake-Security tests also
verify service/account, duplicate rejection, retrieval and safe repr independently. Do not
repeat credential entry or replace the existing item as a routine setup step.

## In-memory official authentication helper

`cloud_auth.py` has no CLI and makes no request at import. The parent operator can call
`authenticate_from_keychain(client_id, stable_user_id)` only when the application's backend
region has been confirmed. It uses the documented sequence:

1. Basic Client ID/Secret → `POST /developer/api/oauth/partner/access-token`.
2. Partner bearer token plus the stable User ID →
   `POST /developer/api/open/partner/users/access-token`.

Only `https://platform-us.plaud.ai` is currently allowed; alternate hosts, HTTP, ports,
query strings, unexpected endpoint paths and redirects are rejected. HTTP 403 stops the
sequence; there is no fallback, retry or access-control workaround. TLS certificate checking
uses the standard system verification. API bodies and credentials are never logged. The
returned `AuthTokens` object has redacted repr and remains in memory; no token is persisted.
Returned JWT identity/expiry parsing is a sanity check, not standalone signature verification.

Both authentication steps have succeeded under the primary operator's verification. This
confirms application authentication, not device-region compatibility, BLE binding or recording
transfer. The resulting tokens were kept in memory and were not saved to source or token files.

These helpers do not call `gen-key`, `sn-sign`, bind/unbind, device recovery, transcription,
or BLE. They do not extract an official consumer-app account or reuse its cookies.

The authentication endpoint sequence and credential roles follow the
[official implementation guide](https://docs.plaud.ai/plaud-embedded/how-plaud-embedded-works)
and [official quickstart](https://docs.plaud.ai/plaud-embedded/quickstart).

## Receiver state with a Keychain-held random passphrase

`receiver_state.py` adds a separate local GenericPassword under service
`codex.plaud.notepro.local-store`, fixed account `plaud-local-owner`. It stores only a
384-bit random receiver passphrase. The RSA-3072 recipient private key and any imported
owner identity remain scrypt/AES-256-GCM encrypted in the state directory. No plaintext
private key, owner identity or passphrase file is written.

A new installation must explicitly initialize its own receiver once, using a new
private state directory and an unused Keychain slot. No receiver state or recipient
PEM is included in the public repository or Android source. Supply your own public
PEM as an asset at build time or import it through the Android UI; see
[setup](../docs/SETUP.md) and [Android setup](../android-bootstrap/SETUP.md).
**If a receiver already exists, do not rerun `init`, generate a replacement key,
or replace its state.** The normal import below accepts only a confirmed envelope
from the Android app; a candidate envelope requires the separate bounded verification
flow and must not be treated as a confirmed identity:

```sh
.venv/bin/python mac-adapter/receiver_state.py import --state-dir /ABS/PATH/TO/PRIVATE/receiver-state \
  --package /ABS/PATH/TO/PRIVATE/pc-bootstrap-v1.json --sn YOUR_EXACT_SN
```

`init` requires a nonexistent state directory and an unused fixed Keychain slot. It does
not overwrite, update or delete an existing key. Only the public PEM's path/hash are
printed. That public file may be put into the approved research APK asset or imported
through its UI; never send the encrypted private key file to Android.

For actual BLE orchestration, `load_store_passphrase()` and
`load_device_identity(state_dir, expected_sn)` return values in memory only. These are
Python functions, with no CLI that exports a passphrase or identity. Import performs no
network request, no BLE pairing, and no binding change. The tests use a fake Keychain;
real receiver initialization was verified separately by the primary operator.

## Isolated candidate diagnostics

A **candidate** is an identity generated before proven bind success; its presence does not
mean the device accepted its RSA key. `candidate_diagnostic.py` decrypts an explicitly marked
candidate envelope with the existing Mac recipient key, verifies the expected serial and RSA
key-pair structure, and returns the candidate only in process memory. Its diagnostic summary
contains allowlisted metadata and no serial, private key or bind token. The module does not
generate keys, start BLE, contact a network or write the confirmed owner store. Importing the
module does not itself read Keychain. The normal owner-store import and load paths continue
to reject candidate identities. Never log or serialize the candidate returned by its loader.

`prehandshake_probe.py` has a separate candidate mode using `--candidate-package` and the
existing `--state-dir`. It obtains the cached signature from the candidate envelope, sends
only the three non-clear `65040` signature frames, and can try to verify the returned `65042`
RSA challenge using the candidate private key in memory. It never sends a client public key,
CMD 1, key-clear or recording commands, and it does not write the confirmed owner store.
This mode can test whether a candidate key matches the current challenge; even a successful
challenge check does not independently prove a completed bind or a complete owner session.

The acceptance run completed Android 0.1.2 candidate export and the bounded candidate
verification. An initial existing-key challenge did not validate against that candidate,
so it was not promoted. Later, after the user completed the separate official App
binding procedure, Mac normal enrollment observed the supported request, sent the
candidate public key only when requested, authenticated the full challenge, and
received CMD 1 status zero. It then saved a separately encrypted confirmed identity,
completed official cloud registration, and passed an independent owner reconnection.
Those later checks establish the Mac result; the candidate export itself and the
earlier Android SDK failure never establish bind success. This public source contains
none of those private envelopes or confirmed stores; another installation needs its
own authorized verification and acceptance.

## Temporary local APK/public-key transfer and encrypted return envelope

`local_transfer.py` serves only the explicitly selected APK, recipient public PEM and its
single session page; it does not expose a directory tree. It accepts one JSON envelope of
at most 256 KiB, checks exact fields/algorithm declarations/base64 sizes, and writes only to
a new `0600` output file. A successful upload is structural validation only; use the separate
receiver import to authenticate/decrypt it and verify the expected device.

The default bind address is loopback. To let the phone browser reach it, the primary operator
must explicitly select the Mac's numeric LAN IP on the trusted local network. It uses HTTP;
only the APK/public key and an already recipient-encrypted envelope belong on this service.
Do not send an SDK Client Secret or User Token through it. Example with placeholders:

```sh
.venv/bin/python mac-adapter/local_transfer.py \
  --apk android-bootstrap/app/build/outputs/apk/debug/app-debug.apk \
  --recipient-public-key /ABS/PATH/TO/PRIVATE/receiver-state/pc-bootstrap-public.pem \
  --output /ABS/PATH/TO/PRIVATE/received-envelope.json \
  --session-url-file /ABS/PATH/TO/PRIVATE/local-transfer-url.txt \
  --bind YOUR_MAC_LAN_IP --port 8765 --ttl-seconds 1800
```

Every output/session file must be new. The capability URL is written only to the selected
local file; no live session URL is included in this README. Requests require the precise
Host and capability path; uploads check the Origin, content type and length. The default
lifetime is 30 minutes. At expiry, the service closes both its listener and any active
connection, including a stalled upload. Ctrl-C also stops it. A completed upload closes the
upload slot while public downloads remain available until service expiry.

The public-key page displays SHA-256 of canonical SPKI DER, matching the Android UI. This is
a different representation from SHA-256 of PEM file bytes; compare like with like.

## Temporary token QR on Mac loopback

`token_bridge.py` reads a non-secret app configuration (`clientId`, `stableUserId`, `baseUrl`),
reads the application's secret from Keychain, performs official authentication and builds
the User Token QR only in memory. It binds exclusively to `127.0.0.1`, checks the exact Host,
and serves only the random session page and its PNG for ten minutes. The QR/token is not
written to disk or stdout. The URL file contains only a temporary loopback capability.

```sh
.venv/bin/python mac-adapter/token_bridge.py \
  --config /ABS/PATH/TO/PRIVATE/app-credentials.json --url-file /ABS/PATH/TO/PRIVATE/token-view-url.txt
```

The primary operator opens the generated local URL on the Mac. The phone scans the QR shown
on the Mac display; the phone does not browse a Mac `127.0.0.1` URL. No token value, Client
Secret, real configuration identifier or live session URL is included here. The server has
2-second per-connection timeouts and clears its PNG reference when closed. Python cannot
guarantee secure erasure of all immutable objects or copies held by a browser process.

The final verification ran the full 133-test suite, then six HTTP/launcher tests after
a proxy-handling correction, adding one regression for 134 distinct passing tests.
The loopback reuse request explicitly bypasses system/shell proxies.

Automatic-processing validation: the full 173-test suite passed in 18.491 seconds,
followed by eight pipeline regression tests after the stale-generated-minutes fix,
for 174 distinct passing tests. The real automatic sample has valid transcript/minutes
files and a completed job; no device deletion was sent. Longer ASR/meeting recordings,
speaker diarization and transcription accuracy remain unaccepted.
