"""Explicit, local original-language ASR for an existing library audio artifact.

Importing this module performs no I/O. Every invocation owns a new private run
directory; it keeps its input snapshot, decoder/ASR outputs and private logs.
No cloud service, model download, library mutation or device operation is used.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import wave
from typing import Any


MAX_INPUT_BYTES = 4 * 1024**3
MAX_JSON_BYTES = 64 * 1024**2
_LANGUAGE = re.compile(r"(?:auto|[a-z]{2,3}(?:-[A-Za-z]{2,4})?)\Z")
_SHA256 = re.compile(r"[0-9a-fA-F]{64}\Z")
_STAMP = re.compile(r"(\d{2,}):([0-5]\d):([0-5]\d)[,.](\d{3})\Z")
# Set a child-only umask. preexec_fn would be unsafe in the threaded UI server.
_PRIVATE_EXEC = "import os,sys; os.umask(0o077); os.execv(sys.argv[1],sys.argv[1:])"
_SYSTEM_ALIASES = {Path("/var"): Path("/private/var"), Path("/tmp"): Path("/private/tmp"),
                   Path("/etc"): Path("/private/etc")}


class TranscriptionError(RuntimeError):
    """A safe stage/code; raw subprocess output remains in the private logs."""

    def __init__(self, stage: str, code: str):
        self.stage, self.code = stage, code
        super().__init__(f"Local transcription failed ({stage}: {code})")


def _fail(stage: str, code: str) -> None:
    raise TranscriptionError(stage, code)


def _absolute(path: Path) -> Path:
    return Path(os.path.abspath(os.fspath(path)))


def _check_path(path: Path, *, missing_leaf: bool = False) -> Path:
    """Reject custom symlinks before resolving trusted macOS system aliases."""
    path = _absolute(path)
    for item in (*reversed(path.parents), path):
        try:
            info = item.lstat()
        except FileNotFoundError:
            if missing_leaf and item == path:
                continue
            raise
        if stat.S_ISLNK(info.st_mode):
            if item not in _SYSTEM_ALIASES or item.resolve(strict=True) != _SYSTEM_ALIASES[item]:
                _fail("preflight", "symlink_not_allowed")
    return path.resolve(strict=not missing_leaf)


def _regular(path: Path, *, nonempty: bool = True) -> tuple[Path, os.stat_result]:
    path = _check_path(path)
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or (nonempty and info.st_size <= 0):
        _fail("preflight", "regular_file_required")
    return path, info


def _executable(path: Path) -> Path:
    path = _absolute(path)
    # The explicitly configured Homebrew entry point is an installation alias.
    # No arbitrary source/model/run path receives this exception.
    if path == Path("/opt/homebrew/bin/whisper-cli") and path.is_symlink():
        resolved = path.resolve(strict=True)
        if Path("/opt/homebrew/Cellar/whisper.cpp") not in resolved.parents:
            _fail("preflight", "untrusted_executable_alias")
        _check_path(path.parent)
        path = resolved
    path, _ = _regular(path)
    if not os.access(path, os.X_OK):
        _fail("preflight", "executable_required")
    return path


def _signature(info: os.stat_result) -> tuple[int, int, int, int]:
    return info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns


def _open_read(path: Path):
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    info = os.fstat(fd)
    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        os.close(fd)
        _fail("preflight", "regular_file_required")
    return os.fdopen(fd, "rb")


def _new_file(path: Path):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
    os.fchmod(fd, 0o600)
    return os.fdopen(fd, "wb")


def _write(path: Path, data: bytes) -> None:
    with _new_file(path) as output:
        output.write(data)
        output.flush()
        os.fsync(output.fileno())


def _write_json(path: Path, value: Any) -> None:
    _write(path, (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode("utf-8"))


def _hash_model(path: Path, expected: str) -> tuple[int, int, int, int]:
    digest = hashlib.sha256()
    with _open_read(path) as source:
        before = _signature(os.fstat(source.fileno()))
        while chunk := source.read(1024 * 1024):
            digest.update(chunk)
        if before != _signature(os.fstat(source.fileno())) or before != _signature(path.stat()):
            _fail("model", "model_changed")
    if digest.hexdigest() != expected:
        _fail("model", "model_hash_mismatch")
    return before


def _snapshot(source: Path, target: Path) -> str:
    digest = hashlib.sha256()
    with _open_read(source) as incoming, _new_file(target) as output:
        before = _signature(os.fstat(incoming.fileno()))
        if before[2] <= 0 or before[2] > MAX_INPUT_BYTES:
            _fail("input", "input_size_not_supported")
        count = 0
        while chunk := incoming.read(1024 * 1024):
            count += len(chunk)
            if count > MAX_INPUT_BYTES:
                _fail("input", "input_size_not_supported")
            digest.update(chunk)
            output.write(chunk)
        output.flush()
        os.fsync(output.fileno())
        if (count != before[2] or before != _signature(os.fstat(incoming.fileno()))
                or before != _signature(source.stat())):
            _fail("input", "input_changed")
    return digest.hexdigest()


def _kill_group(process: subprocess.Popen) -> None:
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        pass


def _run(arguments: list[str], log: Path, timeout: int, stage: str) -> None:
    with _new_file(log) as output:
        try:
            process = subprocess.Popen([sys.executable, "-c", _PRIVATE_EXEC, *arguments],
                stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT,
                shell=False, close_fds=True, start_new_session=True)
        except Exception:
            _fail(stage, "process_start_failed")
        try:
            returncode = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            _kill_group(process)
            _fail(stage, "process_timeout")
        except BaseException:
            _kill_group(process)
            raise
    if returncode != 0:
        _fail(stage, "process_failed")


def _private_outputs(directory: Path) -> None:
    _check_path(directory)
    for path in directory.iterdir():
        _, info = _regular(path, nonempty=False)
        os.chmod(path, 0o600, follow_symlinks=False)
        if info.st_nlink != 1:
            _fail("output", "unsafe_output")


def _measure_wav(path: Path) -> tuple[float, int]:
    _regular(path)
    with _open_read(path) as incoming, wave.open(incoming, "rb") as audio:
        frames = audio.getnframes()
        if (audio.getnchannels() != 1 or audio.getsampwidth() != 2 or audio.getframerate() != 16000
                or audio.getcomptype() != "NONE" or frames <= 0):
            _fail("decode", "invalid_pcm_wav")
        actual = 0
        while block := audio.readframes(65536):
            actual += len(block)
        if actual != frames * 2:
            _fail("decode", "incomplete_pcm_wav")
    return frames / 16000, frames


def _timestamp(value: Any) -> int:
    if not isinstance(value, str) or (match := _STAMP.fullmatch(value)) is None:
        _fail("parse", "invalid_timestamp")
    hours, minutes, seconds, milliseconds = (int(part) for part in match.groups())
    return ((hours * 60 + minutes) * 60 + seconds) * 1000 + milliseconds


def _offsets(segment: dict[str, Any]) -> tuple[int, int]:
    offsets, timestamps = segment.get("offsets"), segment.get("timestamps")
    if offsets is not None:
        if (not isinstance(offsets, dict) or type(offsets.get("from")) is not int
                or type(offsets.get("to")) is not int):
            _fail("parse", "invalid_offsets")
        result = offsets["from"], offsets["to"]
        if timestamps is not None:
            if not isinstance(timestamps, dict):
                _fail("parse", "invalid_timestamp")
            timed = _timestamp(timestamps.get("from")), _timestamp(timestamps.get("to"))
            if result != timed:
                _fail("parse", "conflicting_timestamps")
        return result
    if not isinstance(timestamps, dict):
        _fail("parse", "missing_timestamps")
    return _timestamp(timestamps.get("from")), _timestamp(timestamps.get("to"))


def _parse_segments(payload: Any, duration: float) -> list[dict[str, Any]]:
    if not isinstance(payload, dict) or not isinstance(payload.get("transcription"), list):
        _fail("parse", "invalid_transcription_json")
    if isinstance(payload.get("params"), dict) and payload["params"].get("translate") is True:
        _fail("parse", "translated_output_not_allowed")
    segments: list[dict[str, Any]] = []
    previous_end = 0
    for item in payload["transcription"]:
        if not isinstance(item, dict) or not isinstance(item.get("text"), str):
            _fail("parse", "invalid_segment")
        text = item["text"].strip()
        if not text or "\x00" in text:
            _fail("parse", "empty_segment")
        start, end = _offsets(item)
        if start < previous_end or end <= start or end > math.ceil(duration * 1000) + 1000:
            _fail("parse", "segment_out_of_bounds")
        segments.append({"startMilliseconds": start, "endMilliseconds": end, "text": text})
        previous_end = end
    if not segments:
        _fail("parse", "empty_transcription")
    return segments


def _read_text(path: Path) -> str:
    _, info = _regular(path)
    if info.st_size > MAX_JSON_BYTES:
        _fail("parse", "output_too_large")
    with _open_read(path) as incoming:
        value = incoming.read(MAX_JSON_BYTES + 1)
    if len(value) > MAX_JSON_BYTES:
        _fail("parse", "output_too_large")
    text = value.decode("utf-8")
    if not text.strip():
        _fail("parse", "empty_output")
    return text


def _display_stamp(milliseconds: int) -> str:
    seconds, milliseconds = divmod(milliseconds, 1000)
    minutes, seconds = divmod(seconds, 60)
    hours, minutes = divmod(minutes, 60)
    return f"{hours:02}:{minutes:02}:{seconds:02}.{milliseconds:03}"


def transcribe_audio(source: Path, run_dir: Path, whisper_binary: Path, model_path: Path,
                     *, model_sha256: str, language: str = "auto", timeout_seconds: int = 7200) -> dict[str, Any]:
    """Transcribe a local Ogg/WAV snapshot, preserving the original language.

    Returned duration is measured from the fully decoded PCM, not inferred from
    text timestamps. The caller must separately guard library version/input races
    when saving the result. A successful inference still requires human review.
    """
    stage = "preflight"
    directory: Path | None = None
    try:
        if not isinstance(model_sha256, str) or not _SHA256.fullmatch(model_sha256):
            _fail(stage, "invalid_model_hash")
        if not isinstance(language, str) or not _LANGUAGE.fullmatch(language):
            _fail(stage, "invalid_language")
        if type(timeout_seconds) is not int or not 1 <= timeout_seconds <= 86400:
            _fail(stage, "invalid_timeout")
        source, _ = _regular(Path(source))
        model_path, _ = _regular(Path(model_path))
        whisper_binary = _executable(Path(whisper_binary))
        destination = _check_path(Path(run_dir), missing_leaf=True)
        if not destination.parent.is_dir():
            _fail(stage, "run_parent_required")
        os.mkdir(destination, 0o700)  # Exclusive ownership, never reuse a run.
        directory = destination
        os.chmod(directory, 0o700)

        stage = "model"
        model_sha256 = model_sha256.lower()
        model_signature = _hash_model(model_path, model_sha256)
        stage = "input"
        snapshot = directory / "source.audio"
        input_sha256 = _snapshot(source, snapshot)

        stage = "decode"
        import imageio_ffmpeg
        ffmpeg = _executable(Path(imageio_ffmpeg.get_ffmpeg_exe()))
        pcm = directory / "input-16k.wav"
        _run([str(ffmpeg), "-nostdin", "-n", "-v", "error", "-xerror", "-err_detect", "explode",
              "-protocol_whitelist", "file,pipe", "-format_whitelist", "ogg,wav", "-i", str(snapshot),
              "-map", "0:a:0", "-vn", "-sn", "-dn", "-map_metadata", "-1", "-map_chapters", "-1",
              "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", "-f", "wav", str(pcm)],
             directory / "ffmpeg.log", timeout_seconds, stage)
        _private_outputs(directory)
        duration, frames = _measure_wav(pcm)

        stage = "asr"
        if _signature(model_path.stat()) != model_signature:
            _fail(stage, "model_changed")
        prefix = directory / "whisper"
        for suffix in (".txt", ".srt", ".json"):
            if os.path.lexists(str(prefix) + suffix):
                _fail(stage, "output_already_exists")
        _run([str(whisper_binary), "-m", str(model_path), "-f", str(pcm), "-l", language,
              "-otxt", "-osrt", "-oj", "-of", str(prefix)], directory / "whisper.log", timeout_seconds, stage)
        _private_outputs(directory)
        if _signature(model_path.stat()) != model_signature:
            _fail(stage, "model_changed")

        stage = "parse"
        _read_text(prefix.with_suffix(".txt"))
        _read_text(prefix.with_suffix(".srt"))
        payload = json.loads(_read_text(prefix.with_suffix(".json")))
        segments = _parse_segments(payload, duration)
        detected = payload.get("result", {}).get("language") if isinstance(payload.get("result"), dict) else None
        actual_language = detected if isinstance(detected, str) and _LANGUAGE.fullmatch(detected) else language
        warnings = ["automatic_transcription_requires_review"]
        markdown = "\n\n".join(
            f"[{_display_stamp(item['startMilliseconds'])} --> {_display_stamp(item['endMilliseconds'])}]\n\n{item['text']}"
            for item in segments) + "\n"
        normalized = {"schemaVersion": 1, "language": actual_language, "durationSeconds": duration,
                      "sampleRate": 16000, "decodedFrames": frames, "segmentCount": len(segments),
                      "needsReview": True, "warnings": warnings, "segments": segments}
        segments_path = directory / "segments.json"
        _write_json(segments_path, normalized)
        _write(directory / "transcript.md", markdown.encode("utf-8"))
        metadata = {"engine": "whisper_cpp", "model": model_path.name, "modelSha256": model_sha256,
                    "language": actual_language, "inputSha256": input_sha256, "needsReview": True}
        _write_json(directory / "result.json", {"ok": True, "metadata": metadata,
                    "durationSeconds": duration, "segmentCount": len(segments), "warnings": warnings,
                    "createdAt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")})
        _private_outputs(directory)
        return {"markdown": markdown, "segmentsPath": str(segments_path), "metadata": metadata,
                "durationSeconds": duration, "segmentCount": len(segments), "warnings": warnings}
    except Exception as error:
        safe = error if isinstance(error, TranscriptionError) else TranscriptionError(stage, "operation_failed")
        if directory is not None:
            try:
                _private_outputs(directory)
                _write_json(directory / "failure.json", {"ok": False, "stage": safe.stage,
                            "code": safe.code, "errorType": type(error).__name__})
            except Exception:
                pass
        raise safe from None
