#!/usr/bin/env python3
"""Manage one encrypted Mac receiver state; its random passphrase stays in Keychain.

No network requests or real Keychain operations occur at import. The command line
prints public key path/hash or success state, never a passphrase or device identity.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import secrets
import sys
from typing import Any

import keychain_credentials as keychain
import mac_adapter

STORE_SERVICE = "codex.plaud.notepro.local-store"
STORE_ACCOUNT = "plaud-local-owner"


class ReceiverStateError(RuntimeError):
    """Controlled errors contain no secret material."""


def _base_query(security) -> dict[Any, Any]:
    return {security.kSecClass: security.kSecClassGenericPassword,
            security.kSecAttrService: STORE_SERVICE,
            security.kSecAttrAccount: STORE_ACCOUNT}


def _check_keychain_slot_empty() -> None:
    security = keychain._security()
    query = {**_base_query(security), security.kSecMatchLimit: security.kSecMatchLimitOne}
    try:
        status, _ = keychain._result(security.SecItemCopyMatching(query, None))
    except Exception:
        raise ReceiverStateError("Unable to inspect the local store Keychain slot") from None
    if status == security.errSecSuccess:
        raise ReceiverStateError("Local store Keychain item exists; refusing replacement")
    if status != security.errSecItemNotFound:
        raise ReceiverStateError(f"Keychain slot check failed with OSStatus {status}")


def _add_store_passphrase(passphrase: str) -> None:
    security = keychain._security()
    payload = json.dumps({"version": 1, "passphrase": passphrase}, separators=(",", ":")).encode()
    attributes = {**_base_query(security),
                  security.kSecAttrLabel: "Codex PLAUD encrypted receiver store",
                  security.kSecValueData: keychain._nsdata(payload)}
    try:
        status, _ = keychain._result(security.SecItemAdd(attributes, None))
    except Exception:
        raise ReceiverStateError("Unable to add local store Keychain item") from None
    if status == security.errSecDuplicateItem:
        raise ReceiverStateError("Local store Keychain item exists; refusing replacement")
    if status != security.errSecSuccess:
        raise ReceiverStateError(f"Local store Keychain add failed with OSStatus {status}")


def load_store_passphrase() -> str:
    """Return the fixed receiver's passphrase for in-memory use; never log this return."""
    security = keychain._security()
    query = {**_base_query(security), security.kSecMatchLimit: security.kSecMatchLimitOne,
             security.kSecReturnData: True}
    try:
        status, data = keychain._result(security.SecItemCopyMatching(query, None))
    except Exception:
        raise ReceiverStateError("Unable to read local store Keychain item") from None
    if status == security.errSecItemNotFound:
        raise ReceiverStateError("Local store passphrase is not present in Keychain")
    if status != security.errSecSuccess:
        raise ReceiverStateError(f"Local store Keychain read failed with OSStatus {status}")
    try:
        raw = bytes(data)
        if len(raw) > 4096:
            raise ValueError()
        payload = json.loads(raw)
        value = payload.get("passphrase")
        if payload.get("version") != 1 or not isinstance(value, str) or len(value) < 64:
            raise ValueError()
    except Exception:
        raise ReceiverStateError("Invalid local store Keychain payload") from None
    return value


def initialize_receiver(state_dir: Path) -> dict[str, str]:
    """Create RSA receiver files and add its random passphrase once, never overwrite."""
    if state_dir.exists() or state_dir.is_symlink():
        raise ReceiverStateError("State directory already exists; refusing replacement")
    _check_keychain_slot_empty()
    state_dir.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive mkdir avoids silently replacing an existing state, even after a race.
    try:
        state_dir.mkdir(mode=0o700)
    except FileExistsError:
        raise ReceiverStateError("State directory already exists; refusing replacement") from None
    passphrase = secrets.token_urlsafe(48)  # 384 random bits; exactly 64 URL-safe characters.
    try:
        public = mac_adapter.initialize_recipient(state_dir, passphrase)
        _add_store_passphrase(passphrase)
    except Exception:
        # Remove only this call's newly generated files if Keychain add failed. Never delete
        # or update a Keychain entry; leave unexpected files untouched for inspection.
        for name in (mac_adapter.RECIPIENT_FILE, mac_adapter.PUBLIC_FILE):
            try:
                (state_dir / name).unlink(missing_ok=True)
            except OSError:
                pass
        try:
            state_dir.rmdir()
        except OSError:
            pass
        raise ReceiverStateError("Receiver initialization stopped; no existing state overwritten") from None
    return {"publicKeyPath": str(public.resolve()),
            "publicKeySha256": hashlib.sha256(public.read_bytes()).hexdigest()}


def import_android_envelope(package: Path, state_dir: Path, expected_sn: str) -> None:
    """Import only the encrypted research Android envelope into the encrypted Mac store."""
    mac_adapter.import_android(package, state_dir, load_store_passphrase(), expected_sn)


def load_device_identity(state_dir: Path, expected_sn: str) -> dict[str, Any]:
    """Load the owner identity only into memory; no logging or plaintext file output."""
    return mac_adapter.load_identity(state_dir, load_store_passphrase(), expected_sn)


def main() -> None:
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init")
    init.add_argument("--state-dir", type=Path, required=True)
    imp = sub.add_parser("import")
    imp.add_argument("--state-dir", type=Path, required=True)
    imp.add_argument("--package", type=Path, required=True)
    imp.add_argument("--sn", required=True)
    args = parser.parse_args()
    try:
        if args.command == "init":
            print(json.dumps(initialize_receiver(args.state_dir)))
        else:
            import_android_envelope(args.package, args.state_dir, args.sn)
            print("Encrypted Android identity imported into Mac receiver state")
    except Exception as error:
        print(f"Receiver state stopped ({type(error).__name__}); no credentials printed", file=sys.stderr)
        raise SystemExit(1) from None


if __name__ == "__main__":
    main()
