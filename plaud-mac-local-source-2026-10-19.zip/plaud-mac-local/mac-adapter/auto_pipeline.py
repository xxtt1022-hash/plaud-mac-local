"""Persistent, serial audio -> transcript -> minutes processing for the local UI.

No device operations or credential access. ASR stays local; only transcript text
is given to the separately bounded, already-authenticated Codex CLI adapter.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import queue
import secrets
import sqlite3
import threading


def now():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


class ProcessingEngine:
    def __init__(self, library, config: dict):
        self.library, self.config = library, dict(config)
        self.root = library.root
        self.database = self.root / "processing.sqlite3"
        if self.database.is_symlink():
            raise ValueError("Unexpected processing database link")
        fd = os.open(self.database, os.O_WRONLY | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o600)
        os.close(fd)
        os.chmod(self.database, 0o600)
        self.lock = threading.Lock()
        self.wake = threading.Event()
        self.stop_event = threading.Event()
        self.thread = None
        with self.db() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS jobs (
                id TEXT PRIMARY KEY, record_id TEXT NOT NULL, action TEXT NOT NULL,
                state TEXT NOT NULL, stage TEXT NOT NULL, message TEXT NOT NULL,
                created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
                run_directory TEXT, error_type TEXT, result TEXT NOT NULL DEFAULT '{}')""")

    @contextmanager
    def db(self):
        if self.database.is_symlink():
            raise ValueError("Unexpected processing database link")
        connection = sqlite3.connect(self.database, timeout=5)
        connection.row_factory = sqlite3.Row
        try:
            connection.execute("PRAGMA synchronous=FULL")
            connection.execute("BEGIN IMMEDIATE")
            yield connection
            connection.commit()
        except BaseException:
            connection.rollback()
            raise
        finally:
            connection.close()

    def ready(self):
        required = ("whisperBinary", "modelPath", "codexBinary")
        return self.config.get("enabled") is True and all(
            isinstance(self.config.get(name), str) and Path(self.config[name]).is_file()
            for name in required) and len(self.config.get("modelSha256", "")) == 64

    @staticmethod
    def public(row):
        if row is None:
            return None
        return {"id": row["id"], "recordId": row["record_id"], "action": row["action"],
            "state": row["state"], "stage": row["stage"], "message": row["message"],
            "createdAt": row["created_at"], "updatedAt": row["updated_at"],
            "runDirectory": row["run_directory"], "errorType": row["error_type"],
            "result": json.loads(row["result"])}

    def status(self):
        with self.db() as db:
            rows = db.execute("SELECT * FROM jobs ORDER BY rowid DESC").fetchall()
        latest, active = {}, []
        for row in rows:
            job = self.public(row)
            latest.setdefault(job["recordId"], job)
            if job["state"] in ("queued", "running"):
                active.append(job)
        return {"enabled": self.config.get("enabled") is True, "ready": self.ready(),
            "autoProcessNew": self.config.get("autoProcessNew") is True,
            "active": active, "latest": latest, "asrEngine": "whisper.cpp",
            "asrModel": Path(self.config.get("modelPath", "未配置")).name,
            "minutesProvider": "Codex · 当前 ChatGPT 登录",
            "languagePolicy": "original_language", "audioUploaded": False,
            "transcriptSentToOpenAI": True}

    def enqueue(self, record_id, action="pipeline", *, followup=False):
        if action not in ("pipeline", "transcribe", "minutes") or not self.ready():
            raise ValueError("Automatic processing is not configured")
        record = self.library.get_recording(record_id)
        if not record["integrityVerified"] or not record["decodeVerified"]:
            raise ValueError("Verified decoded audio is required")
        if action == "minutes" and not record.get("transcript"):
            raise ValueError("A transcript is required before minutes")
        with self.db() as db:
            old = db.execute("SELECT * FROM jobs WHERE record_id=? AND state IN ('queued','running') ORDER BY CASE WHEN state='queued' THEN 0 ELSE 1 END,rowid DESC LIMIT 1", (record_id,)).fetchone()
            if old is not None:
                if not followup:
                    return self.public(old)
                if action != "minutes":
                    raise ValueError("Only updated transcripts can request a follow-up")
                if old["state"] == "queued":
                    db.execute("UPDATE jobs SET action='minutes',message=?,updated_at=? WHERE id=?",
                               ("转写已更新，已排队生成对应版本的纪要。", now(), old["id"]))
                    return self.public(db.execute("SELECT * FROM jobs WHERE id=?", (old["id"],)).fetchone())
                # At most one queued successor per recording. Repeated edits
                # update that queued request instead of launching more models.
            job_id = "run_" + secrets.token_hex(16)
            instant = now()
            db.execute("INSERT INTO jobs(id,record_id,action,state,stage,message,created_at,updated_at) VALUES(?,?,?,'queued','queued',?,?,?)",
                       (job_id, record_id, action, "已排队，等待本机处理。", instant, instant))
            result = self.public(db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone())
        self.wake.set()
        return result

    def update(self, job_id, state, stage, message, **values):
        fields = {"state": state, "stage": stage, "message": message, "updated_at": now(), **values}
        if set(fields) - {"state", "stage", "message", "updated_at", "run_directory", "error_type", "result"}:
            raise ValueError("Invalid processing state")
        if "result" in fields:
            fields["result"] = json.dumps(fields["result"], ensure_ascii=False)
        with self.db() as db:
            db.execute("UPDATE jobs SET " + ",".join(name + "=?" for name in fields) + " WHERE id=?", (*fields.values(), job_id))

    def start(self):
        if self.thread is not None or not self.ready():
            return
        # Only call start AFTER owning the HTTP listening socket; a duplicate
        # launcher must never mark the active server's job as interrupted.
        with self.db() as db:
            db.execute("UPDATE jobs SET state='interrupted',stage='interrupted',message=?,updated_at=? WHERE state='running'",
                       ("上次处理被中断。已保存的文字保留，可点击重试。", now()))
        self.thread = threading.Thread(target=self.worker, name="recording-processor", daemon=True)
        self.thread.start()
        if self.config.get("autoProcessNew") is True:
            with self.db() as db:
                seen = {r[0] for r in db.execute("SELECT DISTINCT record_id FROM jobs")}
            for record in self.library.list_recordings():
                if record["id"] not in seen and not record.get("minutes"):
                    try:
                        self.enqueue(record["id"])
                    except ValueError:
                        pass
        self.wake.set()

    def close(self):
        self.stop_event.set()
        self.wake.set()

    def worker(self):
        while not self.stop_event.is_set():
            with self.db() as db:
                row = db.execute("SELECT * FROM jobs WHERE state='queued' ORDER BY rowid LIMIT 1").fetchone()
                if row is not None:
                    db.execute("UPDATE jobs SET state='running',stage='starting',message=?,updated_at=? WHERE id=?",
                               ("正在准备本机处理。", now(), row["id"]))
            if row is None:
                self.wake.wait(2)
                self.wake.clear()
                continue
            self.execute(self.public(row))

    def execute(self, job):
        job_id, record_id, stage = job["id"], job["recordId"], "starting"
        try:
            record = self.library.get_recording(record_id)
            runs = self.root / "processing-runs"
            if runs.is_symlink():
                raise ValueError("Unexpected run directory link")
            runs.mkdir(mode=0o700, exist_ok=True)
            run_dir = runs / job_id
            run_dir.mkdir(mode=0o700)
            self.update(job_id, "running", stage, "正在准备本机处理。", run_directory=str(run_dir.relative_to(self.root)))
            need_asr = job["action"] == "transcribe" or not record.get("transcript")
            if need_asr:
                stage = "transcribing"
                self.update(job_id, "running", stage, "正在 Mac 本地转写原语言文字…")
                role = next((name for name in ("audio", "wav") if record["artifacts"].get(name, {}).get("valid")), None)
                if role is None:
                    raise ValueError("Valid audio is required")
                artifact = record["artifacts"][role]
                previous = record["textStatus"]["transcript"].get("version") or 0
                from asr_transcribe import transcribe_audio
                result = transcribe_audio(self.root / artifact["relativePath"], run_dir / "asr",
                    Path(self.config["whisperBinary"]), Path(self.config["modelPath"]),
                    model_sha256=self.config["modelSha256"], language=self.config.get("language", "auto"),
                    timeout_seconds=int(self.config.get("asrTimeoutSeconds", 7200)))
                if result.get("ok") is False or not result.get("markdown", "").strip():
                    raise RuntimeError("TranscriptionFailed")
                metadata = {**result["metadata"], "inputSha256": artifact["sha256"],
                    "runId": job_id, "createdAt": now(), "needsReview": True,
                    "segmentsRelativePath": str(Path(result["segmentsPath"]).relative_to(self.root))}
                record = self.library.save_generated_text(record_id, "transcript", result["markdown"],
                    source="whisper_cpp", metadata=metadata, input_ref={"audioRole": role,
                    "audioSha256": artifact["sha256"], "previousTextVersion": previous})
            if self.stop_event.is_set():
                self.update(job_id, "interrupted", "interrupted", "处理已暂停，已保存的转写保留，可重试生成纪要。")
                return
            if job["action"] != "transcribe":
                record = self.library.get_recording(record_id)
                # An ordinary pipeline preserves existing user/previous minutes;
                # regeneration is a separate explicit `minutes` action.
                minutes_status = record["textStatus"]["minutes"]
                stale_generated_minutes = (minutes_status.get("source") == "codex_cli"
                    and minutes_status.get("metadata", {}).get("transcriptSha256")
                        != record["textStatus"]["transcript"].get("sha256"))
                if not record.get("minutes") or job["action"] == "minutes" or stale_generated_minutes:
                    stage = "generating_minutes"
                    self.update(job_id, "running", stage, "转写已保存，正在由 Codex 生成会议纪要草稿…")
                    transcript = record["textStatus"]["transcript"]
                    if not record.get("transcript") or not transcript.get("valid"):
                        raise ValueError("A valid transcript is required")
                    from codex_minutes import generate_minutes
                    result = generate_minutes(record["transcript"], run_dir / "minutes",
                        Path(self.config["codexBinary"]), title=record["title"],
                        timeout_seconds=int(self.config.get("summaryTimeoutSeconds", 300)))
                    if result.get("ok") is False or not result.get("markdown", "").strip():
                        raise RuntimeError("MinutesGenerationFailed")
                    safe_metadata = {name: value for name, value in result["metadata"].items()
                                     if name in {"provider", "model", "needsReview"}}
                    metadata = {**safe_metadata, "runId": job_id, "createdAt": now(),
                        "needsReview": True, "transcriptVersion": transcript["version"],
                        "transcriptSha256": transcript["sha256"]}
                    record = self.library.save_generated_text(record_id, "minutes", result["markdown"],
                        source="codex_cli", metadata=metadata,
                        input_ref={"transcriptVersion": transcript["version"], "transcriptSha256": transcript["sha256"],
                                   "previousTextVersion": record["textStatus"]["minutes"].get("version") or 0})
            message = ("本地转写完成，原语言文字为待复核草稿。原始音频保留。" if job["action"] == "transcribe"
                       else "转写与纪要处理完成，结果为待复核草稿。原始音频保留。")
            self.update(job_id, "completed", "complete", message,
                result={"transcriptVersion": record["textStatus"]["transcript"].get("version"),
                        "minutesVersion": record["textStatus"]["minutes"].get("version"), "needsReview": True})
        except Exception as error:
            messages = {"transcribing": "本地转写未完成。音频及中间结果保留，可重试。",
                "generating_minutes": "纪要未完成。已保存的转写保留，可单独重试纪要；也请检查 Codex 登录、网络与额度。"}
            self.update(job_id, "failed", stage, messages.get(stage, "处理未完成，已有资料保留，可重试。"), error_type=type(error).__name__)
