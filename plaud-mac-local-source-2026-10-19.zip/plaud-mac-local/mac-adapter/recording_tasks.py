"""Run explicitly selected device operations in a main-thread BLE subprocess.

The web server never receives private identity material. No delete or enrollment
operation is available. Configuration is a local, owner-created file.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
from pathlib import Path
import sys


def main() -> int:
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("operation", choices=("refresh", "download"))
    parser.add_argument("--session", type=int)
    parser.add_argument("--size", type=int)
    args = parser.parse_args()
    try:
        from device_library import DeviceLibrary
        config = json.loads(args.config.read_text())
        adapter = DeviceLibrary(Path(config["upstream"]), Path(config["stateDir"]),
                                config["sn"], Path(config["downloadRoot"]))
        if args.operation == "refresh":
            result = asyncio.run(adapter.refresh())
        else:
            if args.session is None or args.size is None:
                raise ValueError("Explicit file selection required")
            result = asyncio.run(adapter.download(args.session, args.size))
        if result.get("ok") is False:
            print(json.dumps({"ok": False, "errorType": result.get("errorType", "DeviceError"),
                              "stage": result.get("stage", "unknown")}, ensure_ascii=False))
            return 1
        print(json.dumps({"ok": True, "result": result}, ensure_ascii=False))
        return 0
    except Exception as error:
        # No traceback or raw BLE / cryptography exception is returned to the UI.
        print(json.dumps({"ok": False, "errorType": type(error).__name__}))
        return 1


if __name__ == "__main__":
    sys.exit(main())
