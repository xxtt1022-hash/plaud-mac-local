"""Private local recording catalogue; no device, network, ASR execution or deletion API.

Manual and generated text retain explicit provenance and are data, never
instructions. Audio acceptance flags are explicit assertions, latched off after
integrity failure. A local copy is never treated as an independent backup.
"""
from __future__ import annotations

from contextlib import ExitStack, contextmanager
from datetime import datetime, timezone
from functools import wraps
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sqlite3
import stat
from typing import Any

ROLES = {"raw": "original.plaud", "audio": "audio.ogg", "wav": "playback.wav"}
TEXT_KINDS = ("transcript", "minutes")
MAX_FILE_BYTES = 4 * 1024 * 1024 * 1024
MAX_TEXT_BYTES = 4 * 1024 * 1024
TEXT_SOURCE = "user_or_external_import"
GENERATED_SOURCES = {"whisper_cpp": "transcript", "codex_cli": "minutes"}
METADATA_KEYS = {"engine", "model", "modelSha256", "language", "inputSha256", "transcriptVersion",
                 "transcriptSha256", "runId", "createdAt", "provider", "needsReview", "segmentsRelativePath"}


class _SafeError(ValueError):
    pass


def _fail(message: str = "Invalid local library request") -> None:
    raise _SafeError(message)


def _public(function):
    @wraps(function)
    def guarded(*args, **kwargs):
        try:
            return function(*args, **kwargs)
        except _SafeError as error:
            raise ValueError(str(error)) from None
        except Exception:
            raise ValueError("Local recording library operation failed") from None
    return guarded


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _string(value, limit: int, *, empty: bool = True) -> str:
    if not isinstance(value, str) or len(value) > limit or "\0" in value:
        _fail()
    if not empty and not value.strip():
        _fail()
    return value


def _integer(value, maximum: int = (1 << 63) - 1) -> int:
    if type(value) is not int or not 0 <= value <= maximum:
        _fail()
    return value


def _serial(value: str) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_-]{3,128}", value):
        _fail()
    return value.upper() if re.fullmatch(r"[0-9A-Fa-f]{16}", value) else value


def _duration(value):
    if value is None:
        return None
    if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 10 * 365 * 86400:
        _fail()
    return float(value)


def _sha256(value) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", value):
        _fail("Invalid generated-text input reference")
    return value.lower()


def _metadata(value: dict) -> dict:
    if not isinstance(value, dict) or set(value) - METADATA_KEYS:
        _fail("Unsupported generated-text metadata")
    result = {}
    for key, item in value.items():
        if key in ("modelSha256", "inputSha256", "transcriptSha256"):
            result[key] = _sha256(item)
        elif key == "transcriptVersion":
            result[key] = _integer(item, 999999)
            if result[key] == 0:
                _fail()
        elif key == "needsReview":
            if type(item) is not bool:
                _fail()
            result[key] = item
        else:
            result[key] = _string(item, 2048 if key == "segmentsRelativePath" else 512, empty=False)
            if key == "createdAt":
                moment = datetime.fromisoformat(item.replace("Z", "+00:00"))
                if moment.tzinfo is None:
                    _fail()
            elif key == "segmentsRelativePath":
                if (item.startswith("/") or "\\" in item or any(ord(c) < 32 for c in item)
                        or any(part in ("", ".", "..") for part in item.split("/"))):
                    _fail("Unsafe generated-text metadata path")
    if len(json.dumps(result, allow_nan=False).encode("utf-8")) > 16384:
        _fail("Generated-text metadata exceeds local limit")
    return result


def _input_reference(kind: str, value: dict) -> dict:
    if not isinstance(value, dict):
        _fail("Invalid generated-text input reference")
    keys = ({"audioRole", "audioSha256", "previousTextVersion"} if kind == "transcript"
            else {"transcriptVersion", "transcriptSha256", "previousTextVersion"})
    if set(value) != keys:
        _fail("Invalid generated-text input reference")
    result = {"previousTextVersion": _integer(value["previousTextVersion"], 999999)}
    if kind == "transcript":
        if value["audioRole"] not in ("audio", "wav"):
            _fail("Generated transcript requires a playable audio artifact")
        result.update(audioRole=value["audioRole"], audioSha256=_sha256(value["audioSha256"]))
    else:
        version = _integer(value["transcriptVersion"], 999999)
        if version == 0:
            _fail()
        result.update(transcriptVersion=version, transcriptSha256=_sha256(value["transcriptSha256"]))
    return result


def _check_links(path: Path) -> Path:
    absolute = Path(os.path.abspath(os.fspath(path)))
    # macOS has these root-owned system aliases; custom links remain prohibited.
    system_aliases = {Path("/var"), Path("/tmp"), Path("/etc")} if sys_platform_is_macos() else set()
    for part in (absolute, *absolute.parents):
        try:
            info = part.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) and part not in system_aliases:
            _fail("Symbolic links are not accepted by the recording library")
    return absolute.resolve(strict=False)


def sys_platform_is_macos() -> bool:
    import sys
    return sys.platform == "darwin"


def _private_directory(path: Path) -> None:
    _check_links(path)
    missing = []
    parent = path
    while not parent.exists():
        missing.append(parent)
        parent = parent.parent
    for directory in reversed(missing):
        directory.mkdir(mode=0o700)
    if not stat.S_ISDIR(path.lstat().st_mode):
        _fail()
    os.chmod(path, 0o700)


def _open_regular(path: Path):
    _check_links(path)
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > MAX_FILE_BYTES:
            _fail("Require a bounded regular file without links")
        return os.fdopen(fd, "rb")
    except Exception:
        os.close(fd)
        raise


def _hash_stream(stream) -> tuple[int, str]:
    digest = hashlib.sha256()
    size = 0
    while True:
        block = stream.read(1024 * 1024)
        if not block:
            break
        size += len(block)
        if size > MAX_FILE_BYTES:
            _fail()
        digest.update(block)
    return size, digest.hexdigest()


def _file_info(path: Path) -> tuple[int, str]:
    with _open_regular(path) as stream:
        return _hash_stream(stream)


def _remove_uncommitted(created: list[tuple[Path, int, int]]) -> None:
    # Internal rollback only: never remove an existing/imported catalogue file.
    for path, device, inode in reversed(created):
        try:
            info = path.lstat()
            if stat.S_ISREG(info.st_mode) and (info.st_dev, info.st_ino) == (device, inode):
                path.unlink()
        except OSError:
            pass


class Library:
    @_public
    def __init__(self, root: Path):
        self.root = _check_links(Path(root))
        if self.root in {Path("/"), Path.home(), Path("/tmp"), Path("/private/tmp"), Path("/var"), Path("/Users")}:
            _fail("Use a dedicated recording library directory")
        _private_directory(self.root)
        _private_directory(self.root / "records")
        self.database = self.root / "library.sqlite3"
        _check_links(self.database)
        try:
            fd = os.open(self.database, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
            os.close(fd)
        except FileExistsError:
            info = self.database.lstat()
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                _fail()
        os.chmod(self.database, 0o600)
        with self._db() as connection:
            connection.executescript("""
                CREATE TABLE IF NOT EXISTS recordings (
                    id TEXT PRIMARY KEY, sn TEXT NOT NULL, session_id INTEGER NOT NULL,
                    title TEXT NOT NULL, tags TEXT NOT NULL DEFAULT '[]', project TEXT NOT NULL DEFAULT '',
                    notes TEXT NOT NULL DEFAULT '', duration REAL, source TEXT NOT NULL DEFAULT '',
                    decode_verified INTEGER NOT NULL DEFAULT 0, playback_confirmed INTEGER NOT NULL DEFAULT 0,
                    integrity_verified INTEGER NOT NULL DEFAULT 0, validated_at TEXT,
                    created_at TEXT NOT NULL, imported_at TEXT NOT NULL, updated_at TEXT NOT NULL,
                    UNIQUE(sn, session_id));
                CREATE TABLE IF NOT EXISTS artifacts (
                    record_id TEXT NOT NULL REFERENCES recordings(id), role TEXT NOT NULL,
                    relative_path TEXT NOT NULL UNIQUE, bytes INTEGER NOT NULL, sha256 TEXT NOT NULL,
                    valid INTEGER NOT NULL, validated_at TEXT NOT NULL,
                    PRIMARY KEY(record_id, role));
                CREATE TABLE IF NOT EXISTS text_versions (
                    record_id TEXT NOT NULL REFERENCES recordings(id), kind TEXT NOT NULL,
                    version INTEGER NOT NULL, body TEXT NOT NULL, relative_path TEXT NOT NULL UNIQUE,
                    bytes INTEGER NOT NULL, sha256 TEXT NOT NULL, valid INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    source TEXT NOT NULL DEFAULT 'user_or_external_import',
                    metadata TEXT NOT NULL DEFAULT '{}', PRIMARY KEY(record_id, kind, version));
                CREATE TABLE IF NOT EXISTS device_snapshots (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, sn TEXT NOT NULL,
                    observed_at TEXT NOT NULL, stored_at TEXT NOT NULL, body TEXT NOT NULL);
            """)
            # executescript commits a prior transaction. Serialize inspection + ALTER anew.
            connection.execute("BEGIN IMMEDIATE")
            columns = {row[1] for row in connection.execute("PRAGMA table_info(text_versions)")}
            if "source" not in columns:
                connection.execute("ALTER TABLE text_versions ADD COLUMN source TEXT NOT NULL DEFAULT 'user_or_external_import'")
            if "metadata" not in columns:
                connection.execute("ALTER TABLE text_versions ADD COLUMN metadata TEXT NOT NULL DEFAULT '{}'")

    @contextmanager
    def _db(self):
        _check_links(self.root)
        _check_links(self.root / "records")
        _check_links(self.database)
        for suffix in ("", "-journal", "-wal", "-shm"):
            path = Path(str(self.database) + suffix)
            if path.exists() or path.is_symlink():
                _check_links(path)
                info = path.lstat()
                if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
                    _fail()
                os.chmod(path, 0o600)
        connection = sqlite3.connect(self.database.as_uri() + "?mode=rw", uri=True, timeout=5)
        connection.row_factory = sqlite3.Row
        try:
            connection.execute("PRAGMA foreign_keys=ON")
            connection.execute("PRAGMA journal_mode=DELETE")
            connection.execute("PRAGMA synchronous=FULL")
            connection.execute("BEGIN IMMEDIATE")
            yield connection
            connection.commit()
        except Exception:
            connection.rollback()
            raise
        finally:
            connection.close()

    def _id(self, record_id: str) -> str:
        if not isinstance(record_id, str) or not re.fullmatch(r"rec_[0-9a-f]{64}", record_id):
            _fail("Recording not found")
        return record_id

    def _row(self, connection, record_id):
        row = connection.execute("SELECT * FROM recordings WHERE id=?", (self._id(record_id),)).fetchone()
        if row is None:
            _fail("Recording not found")
        return row

    def _path(self, relative: str) -> Path:
        if not isinstance(relative, str) or not re.fullmatch(r"records/rec_[0-9a-f]{64}/(?:original\.plaud|audio\.ogg|playback\.wav|texts/(?:transcript|minutes)-v[0-9]{4,6}\.md)", relative):
            _fail()
        return _check_links(self.root / relative)

    def _probe(self, relative: str, size: int, digest: str) -> bool:
        try:
            return _file_info(self._path(relative)) == (size, digest)
        except Exception:
            return False

    def _validate(self, connection, record_id) -> None:
        self._row(connection, record_id)
        now = _now()
        artifacts = connection.execute("SELECT * FROM artifacts WHERE record_id=?", (record_id,)).fetchall()
        all_valid = bool(artifacts)
        for artifact in artifacts:
            valid = self._probe(artifact["relative_path"], artifact["bytes"], artifact["sha256"])
            all_valid = all_valid and valid
            connection.execute("UPDATE artifacts SET valid=?,validated_at=? WHERE record_id=? AND role=?",
                               (int(valid), now, record_id, artifact["role"]))
        connection.execute("""UPDATE recordings SET integrity_verified=?,validated_at=?,
            decode_verified=CASE WHEN ? THEN decode_verified ELSE 0 END,
            playback_confirmed=CASE WHEN ? THEN playback_confirmed ELSE 0 END WHERE id=?""",
                           (int(all_valid), now, int(all_valid), int(all_valid), record_id))
        for text in connection.execute("SELECT * FROM text_versions WHERE record_id=?", (record_id,)).fetchall():
            valid = self._probe(text["relative_path"], text["bytes"], text["sha256"])
            connection.execute("UPDATE text_versions SET valid=? WHERE record_id=? AND kind=? AND version=?",
                               (int(valid), record_id, text["kind"], text["version"]))

    def _commit_validation(self, record_id: str, *, required: bool = True) -> None:
        """Commit current acceptance revocation separately from a fallible mutation."""
        record_id = self._id(record_id)
        with self._db() as connection:
            exists = connection.execute("SELECT 1 FROM recordings WHERE id=?", (record_id,)).fetchone()
            if exists is not None:
                self._validate(connection, record_id)
            elif required:
                _fail("Recording not found")

    def _snapshot(self, connection, sn: str | None = None):
        if sn is None:
            row = connection.execute("SELECT * FROM device_snapshots ORDER BY id DESC LIMIT 1").fetchone()
        else:
            row = connection.execute("SELECT * FROM device_snapshots WHERE sn=? ORDER BY id DESC LIMIT 1", (sn,)).fetchone()
        if row is None:
            return None
        return {**json.loads(row["body"]), "snapshotId": row["id"], "sn": row["sn"],
                "observedAt": row["observed_at"], "storedAt": row["stored_at"], "historical": True}

    def _detail(self, connection, record_id) -> dict:
        row = self._row(connection, record_id)
        artifacts = {a["role"]: {"relativePath": a["relative_path"], "bytes": a["bytes"],
                     "sha256": a["sha256"], "valid": bool(a["valid"]), "validatedAt": a["validated_at"]}
                     for a in connection.execute("SELECT * FROM artifacts WHERE record_id=?", (record_id,))}
        versions = {kind: [] for kind in TEXT_KINDS}
        statuses, bodies = {}, {}
        all_text_valid = True
        for kind in TEXT_KINDS:
            rows = connection.execute("SELECT * FROM text_versions WHERE record_id=? AND kind=? ORDER BY version", (record_id, kind)).fetchall()
            for text in rows:
                provenance = self._text_provenance(text)
                versions[kind].append({"version": text["version"], "relativePath": text["relative_path"],
                    "bytes": text["bytes"], "sha256": text["sha256"], "valid": bool(text["valid"]),
                    "createdAt": text["created_at"], **provenance})
            latest = rows[-1] if rows else None
            present = latest is not None and bool(latest["valid"])
            all_text_valid = all_text_valid and (latest is None or present)
            statuses[kind] = {"present": present, "version": latest["version"] if latest else None,
                "relativePath": latest["relative_path"] if latest else None,
                "sha256": latest["sha256"] if latest else None, "valid": bool(present),
                **(self._text_provenance(latest) if latest else self._text_provenance(None))}
            bodies[kind] = latest["body"] if present else ""
        return {"id": row["id"], "sn": row["sn"], "sessionId": row["session_id"],
            "title": row["title"], "tags": json.loads(row["tags"]), "project": row["project"],
            "notes": row["notes"], "durationSeconds": row["duration"], "source": row["source"],
            "decodeVerified": bool(row["decode_verified"]), "playbackConfirmed": bool(row["playback_confirmed"]),
            "integrityVerified": bool(row["integrity_verified"]), "validatedAt": row["validated_at"],
            "createdAt": row["created_at"], "importedAt": row["imported_at"], "updatedAt": row["updated_at"],
            "artifacts": artifacts, "textStatus": statuses, "textVersions": versions,
            "textIntegrityVerified": all_text_valid, **bodies, "deviceSnapshot": self._snapshot(connection, row["sn"])}

    def _text_provenance(self, row) -> dict:
        source = row["source"] if row is not None else TEXT_SOURCE
        if source not in (TEXT_SOURCE, *GENERATED_SOURCES):
            _fail("Unsupported stored text provenance")
        metadata = _metadata(json.loads(row["metadata"])) if row is not None else {}
        return {"source": source, "generated": source in GENERATED_SOURCES,
                "automaticAsr": source == "whisper_cpp", "metadata": metadata}

    def _append_text(self, connection, id: str, kind: str, text: str, data: bytes,
                     source: str, metadata: dict, created) -> dict:
        version = connection.execute("SELECT COALESCE(MAX(version),0)+1 FROM text_versions WHERE record_id=? AND kind=?", (id, kind)).fetchone()[0]
        if version > 999999:
            _fail()
        relative = f"records/{id}/texts/{kind}-v{version:04d}.md"
        digest = hashlib.sha256(data).hexdigest()
        from io import BytesIO
        self._copy(BytesIO(data), self._path(relative), (len(data), digest), created)
        now = _now()
        connection.execute("""INSERT INTO text_versions
            (record_id,kind,version,body,relative_path,bytes,sha256,valid,created_at,source,metadata)
            VALUES(?,?,?,?,?,?,?,1,?,?,?)""", (id, kind, version, text, relative, len(data), digest,
                                            now, source, json.dumps(metadata, ensure_ascii=False, allow_nan=False)))
        connection.execute("UPDATE recordings SET updated_at=? WHERE id=?", (now, id))
        return self._detail(connection, id)

    def _copy(self, source, target: Path, expected: tuple[int, str], created) -> None:
        _private_directory(target.parent)
        _check_links(target)
        if target.exists():
            if _file_info(target) != expected:
                _fail("Recording identity or artifact conflict")
            os.chmod(target, 0o600)
            return  # Identical uncommitted orphan or pre-existing idempotent copy.
        fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
        info = os.fstat(fd)
        created.append((target, info.st_dev, info.st_ino))
        source.seek(0)
        digest = hashlib.sha256()
        size = 0
        with os.fdopen(fd, "wb") as output:
            os.fchmod(output.fileno(), 0o600)
            while True:
                block = source.read(1024 * 1024)
                if not block:
                    break
                size += len(block)
                if size > MAX_FILE_BYTES:
                    _fail()
                digest.update(block)
                output.write(block)
            output.flush()
            os.fsync(output.fileno())
        if (size, digest.hexdigest()) != expected:
            _fail("Source changed during import")

    @_public
    def import_recording(self, sn: str, session_id: int, files: dict[str, Path], *, title: str,
                         duration_seconds: float | None = None, decode_verified: bool = False,
                         playback_confirmed: bool = False, source: str = "") -> dict:
        sn, session_id = _serial(sn), _integer(session_id, 0xFFFFFFFF)
        title, source = _string(title, 512, empty=False), _string(source, 2048)
        duration_seconds = _duration(duration_seconds)
        if type(decode_verified) is not bool or type(playback_confirmed) is not bool:
            _fail()
        if not isinstance(files, dict) or not files or set(files) - ROLES.keys():
            _fail()
        record_id = "rec_" + hashlib.sha256(json.dumps([sn, session_id], separators=(",", ":")).encode()).hexdigest()
        self._commit_validation(record_id, required=False)
        created = []
        try:
            with ExitStack() as opened, self._db() as connection:
                inputs = {}
                for role, path in files.items():
                    stream = opened.enter_context(_open_regular(Path(path)))
                    inputs[role] = (stream, _hash_stream(stream))
                old = connection.execute("SELECT * FROM recordings WHERE id=?", (record_id,)).fetchone()
                now = _now()
                if old is None:
                    connection.execute("""INSERT INTO recordings
                        (id,sn,session_id,title,duration,source,created_at,imported_at,updated_at)
                        VALUES(?,?,?,?,?,?,?,?,?)""", (record_id, sn, session_id, title, duration_seconds, source, now, now, now))
                for role, (_stream, expected) in inputs.items():
                    row = connection.execute("SELECT * FROM artifacts WHERE record_id=? AND role=?", (record_id, role)).fetchone()
                    if row is not None and (row["bytes"], row["sha256"]) != expected:
                        _fail("Recording identity or artifact conflict")
                    relative = f"records/{record_id}/{ROLES[role]}"
                    target = self._path(relative)
                    if row is not None and not self._probe(relative, *expected):
                        _fail("Recording identity or artifact conflict")
                    if target.exists() and _file_info(target) != expected:
                        _fail("Recording identity or artifact conflict")
                for role, (stream, expected) in inputs.items():
                    relative = f"records/{record_id}/{ROLES[role]}"
                    self._copy(stream, self._path(relative), expected, created)
                    connection.execute("""INSERT OR IGNORE INTO artifacts
                        (record_id,role,relative_path,bytes,sha256,valid,validated_at) VALUES(?,?,?,?,?,1,?)""",
                        (record_id, role, relative, *expected, now))
                self._validate(connection, record_id)
                current = self._detail(connection, record_id)
                if decode_verified or playback_confirmed:
                    if not current["integrityVerified"] or not any(current["artifacts"].get(r, {}).get("valid") for r in ("audio", "wav")):
                        _fail("Current playable artifacts must pass integrity validation")
                connection.execute("""UPDATE recordings SET
                    decode_verified=MAX(decode_verified,?),playback_confirmed=MAX(playback_confirmed,?),
                    duration=COALESCE(duration,?),updated_at=? WHERE id=?""",
                    (int(decode_verified), int(playback_confirmed), duration_seconds, now, record_id))
                return self._detail(connection, record_id)
        except Exception:
            _remove_uncommitted(created)
            raise

    @_public
    def get_recording(self, id: str) -> dict:
        with self._db() as connection:
            self._validate(connection, id)
            return self._detail(connection, id)

    @_public
    def validate_recording(self, id: str) -> dict:
        return self.get_recording(id)

    @_public
    def list_recordings(self, query: str = "") -> list[dict]:
        needle = _string(query, 1024).casefold().strip()
        with self._db() as connection:
            result = []
            ids = [row[0] for row in connection.execute("SELECT id FROM recordings ORDER BY imported_at DESC,id")]
            for record_id in ids:
                self._validate(connection, record_id)
                detail = self._detail(connection, record_id)
                historic_text = "\n".join(row[0] for row in connection.execute("SELECT body FROM text_versions WHERE record_id=?", (record_id,)))
                searchable = "\n".join([detail["title"], detail["sn"], str(detail["sessionId"]),
                    detail["project"], detail["notes"], *detail["tags"], historic_text]).casefold()
                if not needle or needle in searchable:
                    result.append(detail)
            return result

    @_public
    def update_recording(self, id: str, title: str, tags: list[str], project: str, notes: str) -> dict:
        title, project, notes = _string(title, 512, empty=False), _string(project, 256), _string(notes, 262144)
        if not isinstance(tags, list) or len(tags) > 64:
            _fail()
        tags = list(dict.fromkeys(_string(tag, 64, empty=False).strip() for tag in tags))
        self._commit_validation(id)
        with self._db() as connection:
            self._validate(connection, id)
            connection.execute("UPDATE recordings SET title=?,tags=?,project=?,notes=?,updated_at=? WHERE id=?",
                               (title, json.dumps(tags, ensure_ascii=False), project, notes, _now(), id))
            return self._detail(connection, id)

    @_public
    def confirm_playback(self, id: str) -> dict:
        with self._db() as connection:
            self._validate(connection, id)
            current = self._detail(connection, id)
            accepted = current["integrityVerified"] and current["decodeVerified"]
            if accepted:
                connection.execute("UPDATE recordings SET playback_confirmed=1,updated_at=? WHERE id=?", (_now(), id))
                current = self._detail(connection, id)
        # Commit any revocation before rejecting the user's confirmation request.
        if not accepted:
            _fail("Current integrity and verified decode are required before listening confirmation")
        return current

    @_public
    def save_text(self, id: str, kind: str, text: str) -> dict:
        if kind not in TEXT_KINDS:
            _fail()
        text = _string(text, MAX_TEXT_BYTES, empty=False)
        data = text.encode("utf-8")
        if len(data) > MAX_TEXT_BYTES:
            _fail()
        self._commit_validation(id)
        created = []
        try:
            with self._db() as connection:
                self._validate(connection, id)
                return self._append_text(connection, id, kind, text, data, TEXT_SOURCE, {}, created)
        except Exception:
            _remove_uncommitted(created)
            raise

    @_public
    def save_generated_text(self, id: str, kind: str, text: str, *, source: str,
                            metadata: dict, input_ref: dict) -> dict:
        if source not in GENERATED_SOURCES or GENERATED_SOURCES[source] != kind:
            _fail("Generated-text source does not match its kind")
        text = _string(text, MAX_TEXT_BYTES, empty=False)
        data = text.encode("utf-8")
        if len(data) > MAX_TEXT_BYTES:
            _fail()
        reference = _input_reference(kind, input_ref)
        provenance = _metadata(metadata)
        binding = ({"inputSha256": reference["audioSha256"]} if kind == "transcript" else
                   {"transcriptVersion": reference["transcriptVersion"],
                    "transcriptSha256": reference["transcriptSha256"]})
        for key, value in binding.items():
            if key in provenance and provenance[key] != value:
                _fail("Generated-text metadata does not match its input")
            provenance[key] = value
        if kind == "minutes" and "inputSha256" in provenance and provenance["inputSha256"] != reference["transcriptSha256"]:
            _fail("Generated-text metadata does not match its input")
        self._commit_validation(id)
        created, result = [], None
        try:
            with self._db() as connection:
                # The same IMMEDIATE transaction protects validation, version comparison and append.
                self._validate(connection, id)
                previous = connection.execute("SELECT COALESCE(MAX(version),0) FROM text_versions WHERE record_id=? AND kind=?", (id, kind)).fetchone()[0]
                valid = previous == reference["previousTextVersion"]
                if kind == "transcript":
                    artifact = connection.execute("SELECT * FROM artifacts WHERE record_id=? AND role=?", (id, reference["audioRole"])).fetchone()
                    valid = (valid and artifact is not None and bool(artifact["valid"])
                             and artifact["sha256"] == reference["audioSha256"])
                else:
                    transcript = connection.execute("SELECT * FROM text_versions WHERE record_id=? AND kind='transcript' ORDER BY version DESC LIMIT 1", (id,)).fetchone()
                    valid = (valid and transcript is not None and bool(transcript["valid"])
                             and transcript["version"] == reference["transcriptVersion"]
                             and transcript["sha256"] == reference["transcriptSha256"])
                if valid:
                    result = self._append_text(connection, id, kind, text, data, source, provenance, created)
            # A stale-input refusal must commit newly discovered integrity revocation first.
            if result is None:
                _fail("Generated text input changed; existing versions were preserved")
            return result
        except Exception:
            _remove_uncommitted(created)
            # A later file/DB error must not resurrect acceptance flags through rollback.
            try:
                self._commit_validation(id)
            except Exception:
                pass
            raise

    @_public
    def record_device_snapshot(self, sn: str, snapshot: dict) -> dict:
        sn = _serial(sn)
        if not isinstance(snapshot, dict):
            _fail()
        observed = _string(snapshot.get("observedAt"), 64, empty=False)
        moment = datetime.fromisoformat(observed.replace("Z", "+00:00"))
        if moment.tzinfo is None or moment.timestamp() > datetime.now(timezone.utc).timestamp() + 300:
            _fail()
        body = {}
        for name in ("batteryPercent", "freeBytes", "totalBytes", "recordingCount", "recordingSeconds"):
            if name in snapshot and snapshot[name] is not None:
                body[name] = _integer(snapshot[name], 100 if name == "batteryPercent" else (1 << 63) - 1)
        for name in ("charging", "sourceRecordRetained"):
            if name in snapshot:
                if type(snapshot[name]) is not bool:
                    _fail()
                body[name] = snapshot[name]
        if "freeBytes" in body and "totalBytes" in body and body["freeBytes"] > body["totalBytes"]:
            _fail()
        entries = snapshot.get("files", [])
        if not isinstance(entries, list) or len(entries) > 10000:
            _fail()
        files, seen = [], set()
        for item in entries:
            if not isinstance(item, dict):
                _fail()
            session = _integer(item.get("sessionId"), 0xFFFFFFFF)
            size = _integer(item.get("size", item.get("fileSize", item.get("bytes"))))
            if session in seen:
                _fail()
            seen.add(session)
            entry = {"sessionId": session, "size": size}
            if "scene" in item:
                entry["scene"] = _integer(item["scene"], 255)
            if "marked" in item:
                if type(item["marked"]) is not bool:
                    _fail()
                entry["marked"] = item["marked"]
            files.append(entry)
        body["files"] = files
        body.setdefault("recordingCount", len(files))
        with self._db() as connection:
            connection.execute("INSERT INTO device_snapshots(sn,observed_at,stored_at,body) VALUES(?,?,?,?)",
                               (sn, observed, _now(), json.dumps(body, ensure_ascii=False)))
            return self._snapshot(connection, sn)

    @_public
    def latest_device_snapshot(self) -> dict | None:
        with self._db() as connection:
            return self._snapshot(connection)

    @_public
    def cleanup_state(self, record: dict) -> dict:
        if not isinstance(record, dict):
            _fail()
        with self._db() as connection:
            record_id = self._id(record.get("id"))
            self._validate(connection, record_id)
            return _cleanup_state(self._detail(connection, record_id), fresh=True)


def _cleanup_state(record: dict, *, fresh: bool) -> dict:
    artifacts = record.get("artifacts", {})
    raw, audio = artifacts.get("raw", {}), artifacts.get("audio", {})
    snapshot = record.get("deviceSnapshot")
    matching = (isinstance(snapshot, dict) and snapshot.get("sn") == record.get("sn")
                and any(item.get("sessionId") == record.get("sessionId") and item.get("size") == raw.get("bytes")
                        for item in snapshot.get("files", []) if isinstance(item, dict)))
    reasons = []
    if not fresh:
        reasons.append("current_integrity_check_required")
    if not isinstance(snapshot, dict):
        reasons.append("device_snapshot_missing")
    elif not matching:
        reasons.append("device_record_not_matched")
    for condition, code in ((raw.get("valid") is True, "raw_not_valid"),
                            (audio.get("valid") is True, "audio_not_valid"),
                            (record.get("decodeVerified") is True, "decode_not_verified"),
                            (record.get("playbackConfirmed") is True, "playback_not_confirmed")):
        if not condition:
            reasons.append(code)
    reasons.append("independent_backup_not_configured")
    return {"blocked": True, "eligibleForDeletion": False, "requiresConfirmation": True,
        "reasons": reasons, "reasonDetails": {"deviceRecordMatched": bool(matching),
            "deviceSnapshotObservedAt": snapshot.get("observedAt") if isinstance(snapshot, dict) else None,
            "deviceSnapshotHistorical": True, "rawValid": raw.get("valid") is True,
            "audioValid": audio.get("valid") is True, "decodeVerified": record.get("decodeVerified") is True,
            "playbackConfirmed": record.get("playbackConfirmed") is True,
            "independentBackupConfigured": False, "sameDiskCopyCountsAsBackup": False}}


@_public
def cleanup_state(record: dict) -> dict:
    """Pure historical evaluation; use Library.cleanup_state for current rehashing."""
    if not isinstance(record, dict):
        _fail()
    return _cleanup_state(record, fresh=False)
