"""Join normal first pairing, encrypted owner preservation, and cloud registration.

No clear-key, recovery, unbind, recording or new-key generation operation exists.
The candidate remains untouched. Only a verified challenge AND CMD 1 status zero
allow a new confirmed identity file; a failed cloud request never undoes that bind.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
from pathlib import Path

from binding_registration import register_cloud_binding, validate_candidate_user
from candidate_diagnostic import load_candidate_in_memory
from cloud_auth import authenticate_from_keychain
import mac_adapter
import receiver_state


class PairingAcceptanceError(RuntimeError):
    pass


def save_accepted_owner(material, state_dir: Path, password: str, expected_sn: str, proof: dict):
    if not (proof.get("challengeVerified") is True
            and proof.get("handshakeAccepted") is True
            and type(proof.get("handshakeStatus")) is int
            and proof["handshakeStatus"] == 0):
        raise PairingAcceptanceError("Verified challenge and accepted owner handshake are required")
    if material.get("verification") != "candidate":
        raise PairingAcceptanceError("This transition requires the isolated candidate")
    confirmed = mac_adapter.validate_identity({**material, "verification": "confirmed"}, expected_sn)
    payload = json.dumps(mac_adapter.seal(confirmed, password, "device-identity")).encode()
    target = state_dir / mac_adapter.IDENTITY_FILE
    # O_EXCL also refuses preexisting symlinks. Never replace a prior owner identity.
    fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as output:
        output.write(payload)
        output.flush()
        os.fsync(output.fileno())
    if mac_adapter.load_identity(state_dir, password, expected_sn) != confirmed:
        raise PairingAcceptanceError("Encrypted owner read-back did not match")


async def accept_candidate(material, state_dir: Path, password: str, expected_sn: str,
                           user_token: str, *, run_pair, cloud_register=register_cloud_binding):
    if (state_dir / mac_adapter.IDENTITY_FILE).exists() or (state_dir / mac_adapter.IDENTITY_FILE).is_symlink():
        raise PairingAcceptanceError("Owner identity already exists; refuse another first pairing")
    material = mac_adapter.validate_identity(material, expected_sn, allow_candidate=True)
    if material.get("verification") != "candidate":
        raise PairingAcceptanceError("Require the original isolated candidate")
    validate_candidate_user(material, user_token)
    result = await run_pair(material)
    result.update(confirmedOwnerStoreWritten=False, cloudBindAttempted=False,
                  cloudBindingRegistrationVerified=False)
    if not (result.get("challengeVerified") is True
            and result.get("handshakeAccepted") is True
            and type(result.get("handshakeStatus")) is int
            and result["handshakeStatus"] == 0):
        return result
    try:
        save_accepted_owner(material, state_dir, password, expected_sn, result)
    except Exception as error:
        # Keep the real device proof even if disk preservation fails. Do not cloud-bind
        # or roll back the device, and retain the independently encrypted candidate.
        result["ownerPreservationErrorType"] = type(error).__name__
        result["ownerStoreFileExists"] = (state_dir / mac_adapter.IDENTITY_FILE).exists()
        return result
    result["confirmedOwnerStoreWritten"] = True
    result["cloudBindAttempted"] = True
    try:
        result.update(cloud_register(user_token, expected_sn, ble_bind_accepted=True))
    except Exception as error:
        result["cloudRegistrationErrorType"] = type(error).__name__
        status = getattr(error, "http_status", None)
        if type(status) is int:
            result["cloudHttpStatus"] = status
    return result


def main():
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--candidate-package", type=Path, required=True)
    parser.add_argument("--state-dir", type=Path, required=True)
    parser.add_argument("--sn", required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--execute-normal-pairing", action="store_true", required=True)
    args = parser.parse_args()
    # Reserve a new private report before any operation; an old path stops immediately.
    with args.report.open("x") as output:
        result = {"outcome": "not_started", "keyClearSent": False, "recordingCommandsSent": False}
        try:
            from first_pair import pair_candidate
            config = json.loads(args.config.read_text())
            material = load_candidate_in_memory(args.candidate_package, args.state_dir, args.sn)
            tokens = authenticate_from_keychain(config["clientId"], config["stableUserId"], base_url=config["baseUrl"])
            password = receiver_state.load_store_passphrase()
            async def run_pair(candidate):
                return await pair_candidate(args.sn, candidate, enroll_if_requested=True)
            result = asyncio.run(accept_candidate(material, args.state_dir, password, args.sn,
                tokens.user_access_token, run_pair=run_pair))
            del material, tokens, password
        except Exception as error:
            result.update(outcome="stopped", errorType=type(error).__name__,
                          localOwnerStoreExists=(args.state_dir / mac_adapter.IDENTITY_FILE).exists())
            status = getattr(error, "http_status", None)
            if type(status) is int:
                result["httpStatus"] = status
        output.write(json.dumps(result, indent=2) + "\n")
        output.flush()
    print(json.dumps(result))


if __name__ == "__main__":
    main()
