"""In-memory PLAUD official authentication only; no CLI, file output, or logging.

Calling these functions makes the documented authentication requests. Importing this
module does not read Keychain, call a network endpoint, or mint a token.
"""
from __future__ import annotations

import base64
from dataclasses import dataclass
import json
import re
import ssl
import time
from typing import Any, Callable
import urllib.error
import urllib.parse
import urllib.request

from keychain_credentials import AppCredentials, read_credentials

OFFICIAL_HOST = "platform-us.plaud.ai"
OFFICIAL_BASE = f"https://{OFFICIAL_HOST}/developer/api"
PARTNER_PATH = "/oauth/partner/access-token"
USER_PATH = "/open/partner/users/access-token"
MAX_RESPONSE_BYTES = 128 * 1024


class OfficialApiError(RuntimeError):
    """Controlled errors omit response bodies, headers, credentials, and tokens."""

    def __init__(self, message: str, http_status: int | None = None):
        super().__init__(message)
        self.http_status = http_status


@dataclass(frozen=True, repr=False)
class AuthTokens:
    partner_access_token: str
    user_access_token: str
    user_expires_at: int

    def __repr__(self) -> str:
        return "AuthTokens(<redacted>)"


def validate_base_url(base_url: str) -> str:
    parsed = urllib.parse.urlsplit(base_url)
    if (parsed.scheme != "https" or parsed.netloc != OFFICIAL_HOST
            or parsed.path.rstrip("/") != "/developer/api" or parsed.query or parsed.fragment):
        raise OfficialApiError("Only the confirmed official PLAUD US authentication origin is allowed")
    return OFFICIAL_BASE


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, newurl):
        # Never follow even an apparent official redirect with credential-bearing headers.
        return None


def post_official(url: str, headers: dict[str, str], body: bytes) -> dict[str, Any]:
    if url not in {OFFICIAL_BASE + PARTNER_PATH, OFFICIAL_BASE + USER_PATH}:
        raise OfficialApiError("Endpoint is outside the authentication allowlist")
    request = urllib.request.Request(url, method="POST", data=body, headers={
        **headers, "Accept": "application/json", "User-Agent": "codex-plaud-local/0.1"})
    opener = urllib.request.build_opener(_NoRedirect(),
        urllib.request.HTTPSHandler(context=ssl.create_default_context()))
    try:
        with opener.open(request, timeout=30) as response:
            if response.geturl() != url:
                raise OfficialApiError("Unexpected authentication response origin")
            raw = response.read(MAX_RESPONSE_BYTES + 1)
    except urllib.error.HTTPError as error:
        # In particular: no alternate endpoints, fingerprint changes, retries or edge bypass.
        status = int(error.code)
        error.close()
        raise OfficialApiError(f"Official PLAUD API returned HTTP {status}; stopped", status) from None
    except OfficialApiError:
        raise
    except Exception:
        raise OfficialApiError("Official PLAUD authentication transport failed") from None
    if len(raw) > MAX_RESPONSE_BYTES:
        raise OfficialApiError("Authentication response exceeded the size limit")
    try:
        payload = json.loads(raw)
    except Exception:
        raise OfficialApiError("Official API did not return valid JSON") from None
    if not isinstance(payload, dict):
        raise OfficialApiError("Official API returned an unexpected response shape")
    return payload


def _access_token(payload: dict[str, Any]) -> str:
    # The documented response uses access_token; accept its conventional data wrapper only.
    data = payload.get("data", payload)
    token = data.get("access_token") if isinstance(data, dict) else None
    if not isinstance(token, str) or not 16 <= len(token) <= 32768 or any(
        char.isspace() for char in token
    ):
        raise OfficialApiError("Official response did not contain an access token")
    return token


def _validate_user_claims(token: str, client_id: str, user_id: str) -> int:
    """Format/identity sanity only: the token's trusted source is the TLS API response."""
    try:
        parts = token.split(".")
        if len(parts) != 3:
            raise ValueError()
        claims = json.loads(base64.urlsafe_b64decode(parts[1] + "=" * (-len(parts[1]) % 4)))
        expiry = int(claims["exp"])
        if (claims.get("client_id") != client_id or claims.get("user_id") != user_id
                or expiry <= int(time.time())):
            raise ValueError()
    except Exception:
        raise OfficialApiError("User token identity or expiration did not match the request") from None
    return expiry


def authenticate(credentials: AppCredentials, stable_user_id: str, *,
                 base_url: str = OFFICIAL_BASE,
                 _post: Callable[[str, dict[str, str], bytes], dict[str, Any]] | None = None) -> AuthTokens:
    base = validate_base_url(base_url)
    if not isinstance(stable_user_id, str) or not 6 <= len(stable_user_id) <= 120 or re.search(
        r"[\x00-\x20\x7f]", stable_user_id
    ):
        raise OfficialApiError("Use a stable application User ID of 6 to 120 non-space characters")
    if not credentials.client_id or ":" in credentials.client_id or not credentials.client_secret:
        raise OfficialApiError("Incomplete application credentials")
    post = post_official if _post is None else _post
    basic = base64.b64encode(f"{credentials.client_id}:{credentials.client_secret}".encode()).decode("ascii")
    partner = _access_token(post(base + PARTNER_PATH, {
        "Authorization": "Basic " + basic, "Content-Type": "application/x-www-form-urlencoded"}, b""))
    user = _access_token(post(base + USER_PATH, {
        "Authorization": "Bearer " + partner, "Content-Type": "application/json"},
        json.dumps({"user_id": stable_user_id, "expires_in": 86400}, separators=(",", ":")).encode()))
    return AuthTokens(partner, user, _validate_user_claims(user, credentials.client_id, stable_user_id))


def authenticate_from_keychain(client_id: str, stable_user_id: str, *,
                               base_url: str = OFFICIAL_BASE) -> AuthTokens:
    validate_base_url(base_url)  # Reject a bad destination before even reading a credential.
    return authenticate(read_credentials(client_id), stable_user_id, base_url=base_url)
