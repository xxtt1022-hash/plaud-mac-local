"""One-time, local RAM diagnostics for an owner's candidate RSA identity.

This is NOT a constant-time authentication implementation or a replacement for
SessionCrypto's authenticated PLAUD.AI challenge. Never expose it as a service or
use its result as an external padding oracle. It exists only to distinguish an
invalid PKCS#1 v1.5 encoded block from a later AEAD failure in one local diagnosis.

False alone cannot identify a wrong key, damaged transport, or a different protocol.
No encoded block, padding position, payload, or private-key value is returned,
printed, logged, persisted, or sent to a network/device/Keychain.
"""
from __future__ import annotations

from collections.abc import Iterable

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa


def rsa_pkcs1_structure_valid(frames: Iterable[bytes], private_key_pem: str) -> bool:
    """Return only whether this candidate yields 00 02 PS(8+ nonzero) 00 payload.

    The payload must be nonempty. This checks the RSA encoded-block structure only;
    the caller must still run the unchanged authenticated session/challenge verifier.
    All malformed input, framing, key, length and range failures return False.
    """
    from plaud_pc.protocol import CMD_PRE_RSA, assemble_pre_handshake

    try:
        ciphertext = assemble_pre_handshake(frames, CMD_PRE_RSA)
        private = serialization.load_pem_private_key(private_key_pem.encode("ascii"), password=None)
        if not isinstance(private, rsa.RSAPrivateKey):
            return False
        numbers = private.private_numbers()
        n = numbers.public_numbers.n
        size = (n.bit_length() + 7) // 8
        if len(ciphertext) != size:
            return False
        c = int.from_bytes(ciphertext, "big")
        if c >= n:
            return False
        # Deliberately local-only raw RSA math: this is not blinded or constant time.
        encoded = pow(c, numbers.d, n).to_bytes(size, "big")
        if not encoded.startswith(b"\x00\x02"):
            return False
        delimiter = encoded.find(b"\x00", 2)
        # Finding the first zero also proves every preceding PS byte was nonzero.
        return 10 <= delimiter < size - 1
    except Exception:
        # Exception strings may contain key/input context; never emit them.
        return False
