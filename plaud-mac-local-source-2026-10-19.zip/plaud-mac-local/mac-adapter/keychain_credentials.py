#!/usr/bin/env python3
"""Store only this PLAUD SDK application's credentials in the current Mac Keychain.

CLI: receive {"clientId": "...", "clientSecret": "..."} via stdin, add once,
and print no credential. There is intentionally no CLI to retrieve credentials.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
import re
import sys
from typing import Any

SERVICE = "codex.plaud.notepro.mac-local"
MAX_INPUT_BYTES = 16 * 1024


class CredentialStoreError(RuntimeError):
    """A controlled error whose message never contains a credential."""


@dataclass(frozen=True, repr=False)
class AppCredentials:
    client_id: str
    client_secret: str

    def __repr__(self) -> str:
        return "AppCredentials(<redacted>)"


def _validate_client_id(value: Any) -> str:
    if not isinstance(value, str) or re.fullmatch(r"[A-Za-z0-9_.-]{1,200}", value) is None:
        raise CredentialStoreError("Invalid Client ID format")
    return value


def _validate_secret(value: Any) -> str:
    if not isinstance(value, str) or not 8 <= len(value) <= 4096 or any(
        char in value for char in ("\0", "\r", "\n")
    ):
        raise CredentialStoreError("Invalid Client Secret format")
    return value


def _security():
    try:
        import Security
    except ImportError:
        raise CredentialStoreError("PyObjC Security framework is unavailable") from None
    return Security


def _nsdata(payload: bytes):
    try:
        from Foundation import NSData
        return NSData.dataWithBytes_length_(payload, len(payload))
    except Exception:
        raise CredentialStoreError("Unable to prepare Keychain CFData") from None


def _result(value: Any) -> tuple[int, Any]:
    # PyObjC exposes the OSStatus result plus the optional out parameter.
    if isinstance(value, tuple) and len(value) == 2:
        return int(value[0]), value[1]
    if isinstance(value, int):
        return value, None
    raise CredentialStoreError("Unexpected Keychain API result")


def store_credentials(client_id: str, client_secret: str) -> None:
    """Atomically add a new GenericPassword; existing items are never updated."""
    client_id, client_secret = _validate_client_id(client_id), _validate_secret(client_secret)
    security = _security()
    payload = json.dumps({"version": 1, "clientId": client_id, "clientSecret": client_secret},
                         separators=(",", ":")).encode("utf-8")
    attributes = {
        security.kSecClass: security.kSecClassGenericPassword,
        security.kSecAttrService: SERVICE,
        security.kSecAttrAccount: client_id,
        security.kSecAttrLabel: "Codex PLAUD Note Pro SDK application",
        # Omit synchronizable/DataProtection-only attributes for the legacy local login
        # Keychain. A normal GenericPassword is not opted in to iCloud synchronization.
        security.kSecValueData: _nsdata(payload),
    }
    try:
        status, _ = _result(security.SecItemAdd(attributes, None))
    except CredentialStoreError:
        raise
    except Exception:
        raise CredentialStoreError("Keychain add failed") from None
    if status == security.errSecDuplicateItem:
        raise CredentialStoreError("Credential already exists; refusing to overwrite")
    if status != security.errSecSuccess:
        raise CredentialStoreError(f"Keychain add failed with OSStatus {status}")


def read_credentials(client_id: str) -> AppCredentials:
    """Read this one account for in-memory use; callers must not log the return value."""
    client_id = _validate_client_id(client_id)
    security = _security()
    query = {
        security.kSecClass: security.kSecClassGenericPassword,
        security.kSecAttrService: SERVICE,
        security.kSecAttrAccount: client_id,
        security.kSecMatchLimit: security.kSecMatchLimitOne,
        security.kSecReturnData: True,
    }
    try:
        status, data = _result(security.SecItemCopyMatching(query, None))
    except CredentialStoreError:
        raise
    except Exception:
        raise CredentialStoreError("Keychain read failed") from None
    if status == security.errSecItemNotFound:
        raise CredentialStoreError("Credential is not present in the Keychain")
    if status != security.errSecSuccess:
        raise CredentialStoreError(f"Keychain read failed with OSStatus {status}")
    try:
        raw = bytes(data)
        if len(raw) > MAX_INPUT_BYTES:
            raise ValueError()
        payload = json.loads(raw)
        if payload.get("version") != 1 or payload.get("clientId") != client_id:
            raise ValueError()
        secret = _validate_secret(payload.get("clientSecret"))
    except Exception:
        raise CredentialStoreError("Invalid stored credential payload") from None
    return AppCredentials(client_id, secret)


def main() -> None:
    try:
        if len(sys.argv) != 1:
            raise CredentialStoreError("Credentials must be supplied only through stdin JSON")
        raw = sys.stdin.buffer.read(MAX_INPUT_BYTES + 1)
        if len(raw) > MAX_INPUT_BYTES:
            raise CredentialStoreError("Input exceeds the credential size limit")
        try:
            payload = json.loads(raw)
            if not isinstance(payload, dict) or set(payload) != {"clientId", "clientSecret"}:
                raise ValueError()
        except Exception:
            raise CredentialStoreError("Expected only Client ID and Client Secret in stdin JSON") from None
        store_credentials(payload["clientId"], payload["clientSecret"])
    except CredentialStoreError as error:
        print(str(error), file=sys.stderr)
        raise SystemExit(1) from None
    except Exception:
        print("Credential storage stopped; no credential printed", file=sys.stderr)
        raise SystemExit(1) from None
    print("PLAUD SDK application credentials stored in Mac Keychain")


if __name__ == "__main__":
    main()
