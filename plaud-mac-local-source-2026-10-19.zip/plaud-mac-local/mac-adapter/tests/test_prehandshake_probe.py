import base64
import json
from pathlib import Path
import struct
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from prehandshake_probe import observe_signature_only, ProbeError

class FakeClient:
    def __init__(self, response=None):
        self.response = response
        self.writes = []
        self.notifying = False

    async def start_notify(self, uuid, callback):
        self.callback = callback
        self.notifying = True

    async def write_gatt_char(self, uuid, value, response):
        self.writes.append(bytes(value))
        if value[3] == value[2] - 1 and self.response is not None:
            self.callback(None, self.response)

    async def stop_notify(self, uuid):
        self.notifying = False

class SignatureProbeTest(unittest.IsolatedAsyncioTestCase):
    signature = base64.b64encode(bytes(256)).decode()

    def assert_only_signature(self, client):
        self.assertEqual(len(client.writes), 3)
        self.assertEqual({struct.unpack_from("<H", x)[0] for x in client.writes}, {65040})
        self.assertFalse(client.notifying)

    async def test_confirmation_never_triggers_key_enrollment_or_owner_handshake(self):
        client = FakeClient(struct.pack("<HB", 65041, 0))
        result = await observe_signature_only(client, self.signature, seconds=.01)
        self.assert_only_signature(client)
        self.assertEqual(result["responses"][0]["command"], 65041)
        self.assertEqual(result["responses"][0]["confirmationByte"], 0)
        self.assertFalse(result["clientPublicKeySent"])
        self.assertFalse(result["ownerHandshakeSent"])

    async def test_encrypted_challenge_records_only_packet_metadata(self):
        client = FakeClient(struct.pack("<HBB", 65042, 1, 0) + b"SECRET_CIPHERTEXT_MARKER")
        result = await observe_signature_only(client, self.signature, seconds=.01)
        self.assert_only_signature(client)
        self.assertTrue(result["responseObserved"])
        self.assertNotIn("SECRET_CIPHERTEXT_MARKER", json.dumps(result))
        self.assertEqual(result["responses"][0]["chunkCount"], 1)

    async def test_no_response_is_bounded_without_any_fallback(self):
        client = FakeClient()
        result = await observe_signature_only(client, self.signature, seconds=.01)
        self.assert_only_signature(client)
        self.assertFalse(result["responseObserved"])

    async def test_force_clear_packet_is_rejected_before_notification_or_write(self):
        client = FakeClient()
        with patch("prehandshake_probe.signature_chunks", return_value=[struct.pack("<HBB", 65056, 1, 0)]):
            with self.assertRaises(ProbeError):
                await observe_signature_only(client, self.signature, seconds=.01)
        self.assertEqual(client.writes, [])
        self.assertFalse(client.notifying)

    async def test_candidate_verification_cannot_send_owner_or_key_enrollment(self):
        client = FakeClient(struct.pack("<HBB", 65042, 1, 0) + b"SYNTHETIC_CHALLENGE")
        observed = []
        def verify(frames):
            observed.extend(frames)
            return True
        result = await observe_signature_only(client, self.signature, seconds=.01, verify_challenge=verify)
        self.assert_only_signature(client)
        self.assertTrue(result["candidateChallengeVerified"])
        self.assertEqual(len(observed), 1)
        self.assertFalse(result["ownerHandshakeSent"])
        self.assertFalse(result["keyClearSent"])

    async def test_private_verifier_error_is_redacted_and_not_a_bound_identity(self):
        client = FakeClient(struct.pack("<HBB", 65042, 1, 0) + b"SYNTHETIC_CHALLENGE")
        def verify(frames):
            raise ValueError("SENSITIVE_PRIVATE_KEY_TEXT")
        result = await observe_signature_only(client, self.signature, seconds=.01, verify_challenge=verify)
        self.assertFalse(result["candidateChallengeVerified"])
        self.assertNotIn("SENSITIVE_PRIVATE_KEY_TEXT", json.dumps(result))
        self.assertEqual(result["challengeVerificationErrorType"], "ValueError")
        self.assert_only_signature(client)
