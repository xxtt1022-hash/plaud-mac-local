from __future__ import annotations

import copy
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import codex_minutes as minutes


class CodexMinutesTest(unittest.TestCase):
    transcript = "[00:03] 小林：我会在周五提交接口清单。\n[00:09] 先讨论方案，尚未决定部署。"
    structured = {"summary": "讨论了接口清单和方案，片段不构成完整会议。",
        "discussion": ["[00:09] 讨论方案，尚未决定部署。"], "decisions": [],
        "actionItems": [{"task": "提交接口清单", "owner": "小林", "deadline": "周五",
                         "evidence": "[00:03] 小林：我会在周五提交接口清单。"}],
        "uncertainties": ["会议日期和完整参与者未明确；转写及片段范围需人工复核。"]}

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.calls = []
        self.processes = []
        self.child_events = [
            {"type": "thread.started", "thread_id": "SYNTHETIC_THREAD_ID", "model": "synthetic-model-1"},
            {"type": "turn.started"},
            {"type": "item.completed", "item": {"type": "reasoning", "text": "SYNTHETIC_REASONING_NOT_RETAINED"}},
            {"type": "item.completed", "item": {"type": "agent_message", "text": "SYNTHETIC_MESSAGE_NOT_RETAINED"}},
            {"type": "turn.completed", "usage": {"input_tokens": 123, "output_tokens": 45}}]

    def fake_popen(self, result=None, *, returncode=0, events=None, raw=None):
        payload = copy.deepcopy(self.structured) if result is None else result
        event_data = self.child_events if events is None else events
        stdout_data = b"".join(json.dumps(item).encode() + b"\n" for item in event_data)
        def spawn(args, **kwargs):
            self.calls.append((args, kwargs))
            self.assertEqual(list(Path(kwargs["cwd"]).iterdir()), [])
            output = Path(args[args.index("-o") + 1])
            output.write_bytes(json.dumps(payload, ensure_ascii=False).encode() if raw is None else raw)
            incoming_read, incoming_write = os.pipe()
            outgoing_read, outgoing_write = os.pipe()
            os.write(outgoing_write, stdout_data)
            os.close(outgoing_write)
            class Process:
                pid = 987654321
                def __init__(inner):
                    inner.stdin = os.fdopen(incoming_write, "wb", buffering=0)
                    inner.stdout = os.fdopen(outgoing_read, "rb", buffering=0)
                    inner.returncode = returncode
                    inner.wait = Mock(return_value=returncode)
                def input(inner):
                    data = bytearray()
                    while chunk := os.read(incoming_read, 65536):
                        data.extend(chunk)
                    return bytes(data)
            process = Process()
            self.processes.append(process)
            self.addCleanup(lambda: os.close(incoming_read))
            self.addCleanup(lambda: process.stdin.close() if not process.stdin.closed else None)
            self.addCleanup(lambda: process.stdout.close() if not process.stdout.closed else None)
            return process
        return spawn

    def call(self, **kwargs):
        return minutes.generate_minutes(self.transcript, self.root / "runs", Path(sys.executable),
                                        title="接口讨论", **kwargs)

    def test_success_uses_only_stdin_text_no_tools_and_private_artifacts(self):
        with patch.object(subprocess, "Popen", side_effect=self.fake_popen()) as popen, \
                patch.dict(os.environ, {"OPENAI_API_KEY": "SYNTHETIC_API_SECRET", "CODEX_API_KEY": "SYNTHETIC_OTHER_SECRET",
                                         "CODEX_REMOTE_ADDR": "SYNTHETIC_DAEMON"}):
            result = self.call()
        self.assertTrue(result["ok"], result)
        self.assertIn("[00:03]", result["markdown"])
        self.assertIn("未明确", result["markdown"])
        self.assertEqual(result["metadata"]["provider"], "codex_cli")
        self.assertTrue(result["metadata"]["needsReview"])
        self.assertEqual(result["metadata"]["model"], "synthetic-model-1")
        args, kwargs = self.calls[0]
        for flag in ("--no-daemon", "--strict-config", "--ignore-user-config", "--ignore-rules",
                     "--ephemeral", "--skip-git-repo-check", "read-only", "--output-schema", "--json"):
            self.assertIn(flag, args)
        for setting in ('orchestrator.mcp.enabled=false', 'web_search="disabled"',
                        'skills.bundled.enabled=false', 'skills.include_instructions=false',
                        'features.skip_host_skill_discovery=true', 'project_doc_max_bytes=0',
                        'suppress_unstable_features_warning=true'):
            self.assertIn(setting, args)
        self.assertNotIn("-m", args)
        self.assertNotIn("--model", args)
        for feature in ("shell_tool", "hooks", "apps", "plugins", "browser_use", "computer_use", "view_image"):
            self.assertIn(feature, args)
        self.assertNotIn(self.transcript, " ".join(args))
        self.assertEqual(json.loads(self.processes[0].input()), {"title": "接口讨论", "transcript": self.transcript})
        self.assertNotIn("OPENAI_API_KEY", kwargs["env"])
        self.assertNotIn("CODEX_API_KEY", kwargs["env"])
        self.assertNotIn("CODEX_REMOTE_ADDR", kwargs["env"])
        self.assertIs(kwargs["stderr"], subprocess.DEVNULL)
        self.assertTrue(kwargs["start_new_session"])
        self.assertFalse(kwargs["shell"])
        self.assertEqual(kwargs["umask"], 0o077)
        directory = Path(result["runDirectory"])
        self.assertEqual(directory.stat().st_mode & 0o777, 0o700)
        self.assertEqual(list((directory / "empty-cwd").iterdir()), [])
        for path in directory.iterdir():
            if path.is_file():
                self.assertEqual(path.stat().st_mode & 0o777, 0o600)
        saved = (directory / "events.json").read_text() + (directory / "run.json").read_text()
        self.assertNotIn("NOT_RETAINED", saved)
        self.assertNotIn("SYNTHETIC_THREAD_ID", saved)
        self.assertNotIn("SYNTHETIC_API_SECRET", saved)
        self.assertNotIn(self.transcript, saved)
        self.assertEqual(popen.call_count, 1)

    def test_no_actual_model_event_does_not_invent_a_model(self):
        events = [{"type": "thread.started"}, {"type": "turn.started"}, {"type": "turn.completed"}]
        with patch.object(subprocess, "Popen", side_effect=self.fake_popen(events=events)):
            result = self.call()
        self.assertTrue(result["ok"])
        self.assertNotIn("model", result["metadata"])

    def test_nonzero_exit_and_missing_turn_completion_reject_even_valid_result(self):
        for returncode, events in ((7, self.child_events), (0, [{"type": "turn.started"}])):
            with self.subTest(returncode=returncode), \
                    patch.object(subprocess, "Popen", side_effect=self.fake_popen(returncode=returncode, events=events)):
                result = self.call()
                self.assertFalse(result["ok"])
                self.assertEqual(result["markdown"], "")
                self.assertEqual(result["errorType"], "CodexRunFailed")
                self.assertTrue(Path(result["rawJsonPath"]).exists())
                self.assertFalse((Path(result["runDirectory"]) / "minutes.md").exists())

    def test_any_tool_event_is_rejected_and_process_group_terminated(self):
        for item in ("command_execution", "mcp_tool_call", "web_search", "file_change", "todo_list"):
            events = [{"type": "item.started", "item": {"type": item,
                       "command": "SYNTHETIC_PRIVATE_COMMAND", "arguments": "SYNTHETIC_PRIVATE_ARGUMENT"}}]
            with self.subTest(item=item), patch.object(subprocess, "Popen", side_effect=self.fake_popen(events=events)), \
                    patch.object(os, "killpg") as kill:
                result = self.call()
                self.assertFalse(result["ok"])
                self.assertEqual(result["errorType"], "ToolUseDetected")
                self.assertTrue(result["metadata"]["toolUseDetected"])
                kill.assert_any_call(987654321, signal.SIGTERM)
                kill.assert_any_call(987654321, signal.SIGKILL)
                saved = (Path(result["runDirectory"]) / "events.json").read_text()
                self.assertNotIn("PRIVATE_COMMAND", saved)
                self.assertNotIn("PRIVATE_ARGUMENT", saved)

    def test_invalid_schema_blank_and_duplicate_properties_never_become_markdown(self):
        missing = copy.deepcopy(self.structured)
        del missing["decisions"]
        extra = {**self.structured, "unexpected": "untrusted"}
        wrong_type = {**self.structured, "summary": 12}
        blank = {**self.structured, "summary": " \n "}
        no_review = {**self.structured, "uncertainties": []}
        for value in (missing, extra, wrong_type, blank, no_review):
            with self.subTest(value=value), patch.object(subprocess, "Popen", side_effect=self.fake_popen(value)):
                result = self.call()
                self.assertFalse(result["ok"])
                self.assertEqual(result["stage"], "validate_result")
                self.assertEqual(result["markdown"], "")
        with patch.object(subprocess, "Popen", side_effect=self.fake_popen(raw=b'{"summary":"a","summary":"b"}')):
            result = self.call()
        self.assertEqual(result["errorType"], "InvalidMinutesResult")

    def test_action_evidence_and_owner_deadline_must_be_verbatim_source(self):
        for field, fabricated in (("evidence", "[00:99] invented evidence"), ("owner", "不存在的人"),
                                  ("deadline", "2099-01-01"), ("evidence", "未明确")):
            value = copy.deepcopy(self.structured)
            value["actionItems"][0][field] = fabricated
            with self.subTest(field=field, fabricated=fabricated), \
                    patch.object(subprocess, "Popen", side_effect=self.fake_popen(value)):
                result = self.call()
                self.assertFalse(result["ok"])
                self.assertEqual(result["errorType"], "InvalidMinutesResult")
                self.assertEqual(result["markdown"], "")

    def test_timeout_kills_group_and_retains_only_safe_failure_metadata(self):
        with patch.object(subprocess, "Popen", side_effect=self.fake_popen()), \
                patch.object(minutes.time, "monotonic", side_effect=[0, 2]), \
                patch.object(os, "killpg") as kill:
            result = self.call(timeout_seconds=1)
        self.assertFalse(result["ok"])
        self.assertEqual(result["errorType"], "CodexTimeout")
        self.assertEqual(result["markdown"], "")
        kill.assert_any_call(987654321, signal.SIGTERM)
        kill.assert_any_call(987654321, signal.SIGKILL)
        self.assertTrue((Path(result["runDirectory"]) / "run.json").is_file())

    def test_event_output_is_bounded_and_error_text_is_never_saved(self):
        events = [{"type": "error", "message": "SYNTHETIC_AUTH_ERROR_SECRET"}]
        with patch.object(subprocess, "Popen", side_effect=self.fake_popen(events=events)), \
                patch.object(os, "killpg"):
            result = self.call()
        self.assertFalse(result["ok"])
        directory = Path(result["runDirectory"])
        self.assertNotIn("AUTH_ERROR_SECRET", (directory / "events.json").read_text())
        self.assertNotIn("AUTH_ERROR_SECRET", json.dumps(result))
        # The CLI's known pre-turn warning is safe metadata; an actual error item
        # must fail and never be mislabeled as tool use. Timing is part of the gate.
        warning = next(iter(minutes.SAFE_STARTUP_WARNING_MESSAGES))
        warning_item = {"type": "item.completed", "item": {"id": "synthetic", "type": "error", "message": warning}}
        for error_item in (
            {"type": "item.completed", "item": {"type": "error", "message": "SYNTHETIC_AUTH_ERROR_SECRET"}},
            {"type": "item.completed", "item": {"type": "error", "message": warning + " modified"}},
        ):
            with patch.object(subprocess, "Popen", side_effect=self.fake_popen(events=[error_item])), \
                    patch.object(os, "killpg"):
                failure = self.call()
            self.assertEqual(failure["errorType"], "CodexRunFailed")
            self.assertFalse(failure["metadata"]["toolUseDetected"])
            self.assertNotIn("AUTH_ERROR_SECRET", json.dumps(failure))
        with patch.object(subprocess, "Popen", side_effect=self.fake_popen(events=[
                {"type": "thread.started"}, warning_item, {"type": "turn.started"}, {"type": "turn.completed"}])):
            startup = self.call()
        self.assertTrue(startup["ok"], startup)
        self.assertFalse(startup["metadata"]["toolUseDetected"])
        safe_events = json.loads((Path(startup["runDirectory"]) / "events.json").read_text())
        self.assertEqual(safe_events["startupWarnings"], ["code_mode_host_disabled"])
        self.assertNotIn(warning, json.dumps(safe_events))
        with patch.object(subprocess, "Popen", side_effect=self.fake_popen(events=[
                {"type": "turn.started"}, warning_item])), patch.object(os, "killpg"):
            late = self.call()
        self.assertEqual(late["errorType"], "CodexRunFailed")
        with patch.object(subprocess, "Popen", side_effect=self.fake_popen()), \
                patch.object(minutes, "MAX_EVENT_BYTES", 20), patch.object(os, "killpg"):
            result = self.call()
        self.assertEqual(result["errorType"], "InvalidEventStream")

    def test_blank_oversized_or_invalid_timeout_stops_before_subprocess(self):
        for transcript, timeout in ((" ", 300), ("x" * (minutes.MAX_TRANSCRIPT_BYTES + 1), 300),
                                    (self.transcript, True), (self.transcript, 601)):
            with self.subTest(timeout=timeout), patch.object(subprocess, "Popen") as popen:
                result = minutes.generate_minutes(transcript, self.root / "runs", Path(sys.executable),
                                                  timeout_seconds=timeout)
                self.assertFalse(result["ok"])
                self.assertIsNone(result["runDirectory"])
                popen.assert_not_called()


if __name__ == "__main__":
    unittest.main()
