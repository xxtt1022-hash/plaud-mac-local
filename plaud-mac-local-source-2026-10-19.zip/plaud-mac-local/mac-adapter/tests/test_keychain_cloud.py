from __future__ import annotations

import base64
import json
from pathlib import Path
import sys
import time
import types
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import keychain_credentials as credentials
import cloud_auth


class FakeSecurity:
    kSecClass, kSecClassGenericPassword, kSecAttrService = "class", "generic", "service"
    kSecAttrAccount, kSecAttrLabel, kSecAttrSynchronizable = "account", "label", "sync"
    kSecValueData, kSecMatchLimit, kSecMatchLimitOne, kSecReturnData = "data", "limit", "one", "return"
    errSecSuccess, errSecDuplicateItem, errSecItemNotFound = 0, -25299, -25300

    def __init__(self):
        self.items = {}
        self.add_calls = []

    def SecItemAdd(self, attributes, unused):
        self.add_calls.append(dict(attributes))
        key = attributes[self.kSecAttrService], attributes[self.kSecAttrAccount]
        if key in self.items:
            return self.errSecDuplicateItem, None
        self.items[key] = attributes[self.kSecValueData]
        return 0, None

    def SecItemCopyMatching(self, query, unused):
        key = query[self.kSecAttrService], query[self.kSecAttrAccount]
        return (0, self.items[key]) if key in self.items else (self.errSecItemNotFound, None)


class KeychainTest(unittest.TestCase):
    def test_add_once_read_same_account_without_real_keychain(self):
        fake = FakeSecurity()
        with patch.object(credentials, "_security", return_value=fake), \
                patch.object(credentials, "_nsdata", side_effect=lambda value: value):
            credentials.store_credentials("client-test", "only-a-synthetic-secret")
            actual = credentials.read_credentials("client-test")
            self.assertEqual(actual.client_secret, "only-a-synthetic-secret")
            self.assertNotIn(actual.client_secret, repr(actual))
            attributes = fake.add_calls[0]
            self.assertEqual(attributes[fake.kSecAttrService], "codex.plaud.notepro.mac-local")
            self.assertNotIn(fake.kSecAttrSynchronizable, attributes)
            with self.assertRaisesRegex(credentials.CredentialStoreError, "refusing to overwrite"):
                credentials.store_credentials("client-test", "replacement-must-not-win")
            self.assertEqual(credentials.read_credentials("client-test").client_secret,
                             "only-a-synthetic-secret")
            with self.assertRaises(credentials.CredentialStoreError):
                credentials.read_credentials("client-other")


class CloudTest(unittest.TestCase):
    def jwt(self, **overrides):
        payload = {"client_id": "client-test", "user_id": "stable-user-test",
                   "sub": "test-subject", "exp": int(time.time()) + 3600, **overrides}
        part = base64.urlsafe_b64encode(json.dumps(payload).encode()).decode().rstrip("=")
        return "test-header." + part + ".test-signature"

    def test_only_two_documented_authentication_requests_and_memory_result(self):
        calls, user = [], self.jwt()
        def fake_post(url, headers, body):
            calls.append((url, headers, body))
            return {"access_token": "synthetic-partner-token" if len(calls) == 1 else user}
        actual = cloud_auth.authenticate(credentials.AppCredentials("client-test", "synthetic-secret"),
                                         "stable-user-test", _post=fake_post)
        self.assertEqual(len(calls), 2)
        self.assertEqual(calls[0][0], cloud_auth.OFFICIAL_BASE + cloud_auth.PARTNER_PATH)
        self.assertEqual(base64.b64decode(calls[0][1]["Authorization"].split(" ")[1]),
                         b"client-test:synthetic-secret")
        self.assertEqual(calls[1][1]["Authorization"], "Bearer synthetic-partner-token")
        self.assertEqual(json.loads(calls[1][2])["user_id"], "stable-user-test")
        self.assertEqual(actual.user_access_token, user)
        self.assertNotIn(user, repr(actual))

    def test_unconfirmed_origin_rejected_before_keychain_or_transport(self):
        invalid = ["http://platform-us.plaud.ai/developer/api", "https://platform-us.plaud.ai.evil/developer/api",
                   "https://platform-cn.plaud.ai/developer/api", "https://platform-us.plaud.ai:443/developer/api",
                   "https://platform-us.plaud.ai/developer/api?redirect=bad"]
        with patch.object(cloud_auth, "read_credentials") as read:
            for url in invalid:
                with self.assertRaises(cloud_auth.OfficialApiError):
                    cloud_auth.authenticate_from_keychain("client-test", "stable-user-test", base_url=url)
            read.assert_not_called()

    def test_403_stops_no_fallback_or_retry(self):
        calls = []
        def denied(url, headers, body):
            calls.append(url)
            raise cloud_auth.OfficialApiError("Official API returned HTTP 403; stopped", 403)
        with self.assertRaises(cloud_auth.OfficialApiError) as caught:
            cloud_auth.authenticate(credentials.AppCredentials("client-test", "synthetic-secret"),
                                    "stable-user-test", _post=denied)
        self.assertEqual(caught.exception.http_status, 403)
        self.assertEqual(len(calls), 1)

    def test_user_identity_mismatch_rejected(self):
        def fake_post(url, headers, body):
            return {"access_token": "synthetic-partner-token" if url.endswith(cloud_auth.PARTNER_PATH)
                    else self.jwt(user_id="another-user")}
        with self.assertRaises(cloud_auth.OfficialApiError):
            cloud_auth.authenticate(credentials.AppCredentials("client-test", "synthetic-secret"),
                                    "stable-user-test", _post=fake_post)

    def test_redirect_handler_never_forwards_credentials(self):
        self.assertIsNone(cloud_auth._NoRedirect().redirect_request(None, None, 302, "", {},
                                                                   "https://example.invalid"))


if __name__ == "__main__":
    unittest.main()
