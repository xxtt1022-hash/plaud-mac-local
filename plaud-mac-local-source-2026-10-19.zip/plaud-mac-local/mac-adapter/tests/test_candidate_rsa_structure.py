from __future__ import annotations

from contextlib import redirect_stderr, redirect_stdout
from io import StringIO
from pathlib import Path
import struct
import sys
import unittest

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import candidate_rsa_structure


class CandidateRsaStructureTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        source = Path(__file__).resolve().parents[2] / "plaud-direct-pc-research" / "pc-bridge" / "src"
        if not source.is_dir():
            raise unittest.SkipTest("Sibling upstream source checkout is required")
        sys.path.insert(0, str(source))
        cls.private = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        cls.pem = cls.private.private_bytes(serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8, serialization.NoEncryption()).decode()
        cls.public = cls.private.public_key().public_numbers()
        cls.size = (cls.public.n.bit_length() + 7) // 8

    @staticmethod
    def frames(ciphertext):
        from plaud_pc.protocol import CMD_PRE_RSA, pre_handshake_chunks
        return pre_handshake_chunks(CMD_PRE_RSA, ciphertext)

    def ciphertext_for_encoded(self, encoded):
        self.assertEqual(len(encoded), self.size)
        value = int.from_bytes(encoded, "big")
        self.assertLess(value, self.public.n)
        # Public RSA operation creates the exact chosen encoded block, with no chance-based
        # assumption about wrong-key output or OpenSSL's implicit-rejection behavior.
        return pow(value, self.public.e, self.public.n).to_bytes(self.size, "big")

    def valid_encoded(self):
        payload = b"SYNTHETIC_SESSION_PAYLOAD_NEVER_REAL"
        return b"\x00\x02" + b"\xa5" * (self.size - len(payload) - 3) + b"\x00" + payload

    def check_encoded(self, encoded):
        return candidate_rsa_structure.rsa_pkcs1_structure_valid(
            self.frames(self.ciphertext_for_encoded(encoded)), self.pem)

    def test_exact_valid_encoded_block_and_shuffled_frames(self):
        ciphertext = self.ciphertext_for_encoded(self.valid_encoded())
        frames = self.frames(ciphertext)
        self.assertIs(candidate_rsa_structure.rsa_pkcs1_structure_valid(frames, self.pem), True)
        self.assertIs(candidate_rsa_structure.rsa_pkcs1_structure_valid(list(reversed(frames)), self.pem), True)
        # The minimum PS length of eight and a one-byte payload are both accepted.
        encoded = b"\x00\x02" + b"\x01" * 8 + b"\x00" + b"p" * (self.size - 11)
        self.assertTrue(self.check_encoded(encoded))
        self.assertTrue(self.check_encoded(b"\x00\x02" + b"\x01" * (self.size - 4) + b"\x00p"))

    def test_deterministically_invalid_padding_prefix_ps_delimiter_and_payload(self):
        good = self.valid_encoded()
        invalid = [
            b"\x00\x01" + good[2:],  # signature-padding prefix, not encryption padding
            b"\x00\x03" + good[2:],  # unsupported encoded-block type
            b"\x00\x02" + b"\x01" * (self.size - 2),  # no zero delimiter
            b"\x00\x02" + b"\x01" * 7 + b"\x00" + b"p" * (self.size - 10),  # short PS
            b"\x00\x02\x00" + b"p" * (self.size - 3),  # zero-length PS
            b"\x00\x02" + b"\x01" * (self.size - 3) + b"\x00",  # empty payload
        ]
        for encoded in invalid:
            self.assertIs(self.check_encoded(encoded), False)

    def test_ciphertext_length_and_integer_range_are_rejected(self):
        good = self.ciphertext_for_encoded(self.valid_encoded())
        for ciphertext in (good[:-1], b"\x00" + good, self.public.n.to_bytes(self.size, "big"),
                           bytes([255]) * self.size):
            self.assertIs(candidate_rsa_structure.rsa_pkcs1_structure_valid(
                self.frames(ciphertext), self.pem), False)

    def test_bad_framing_and_bad_key_return_only_false_without_output(self):
        good = self.frames(self.ciphertext_for_encoded(self.valid_encoded()))
        conflict = bytearray(good[0])
        conflict[-1] ^= 1
        cases = [(good[:-1], self.pem), ([*good, bytes(conflict)], self.pem),
                 ([struct.pack("<HBB", 65040, 1, 0) + b"not-rsa"], self.pem),
                 (good, "SYNTHETIC_INVALID_PRIVATE_KEY_MARKER")]
        out, err = StringIO(), StringIO()
        with redirect_stdout(out), redirect_stderr(err):
            for frames, key in cases:
                self.assertIs(candidate_rsa_structure.rsa_pkcs1_structure_valid(frames, key), False)
        self.assertEqual(out.getvalue() + err.getvalue(), "")


if __name__ == "__main__":
    unittest.main()
