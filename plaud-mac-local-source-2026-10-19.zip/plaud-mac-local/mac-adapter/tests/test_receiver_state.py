from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

from cryptography.hazmat.primitives import serialization

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import keychain_credentials
import mac_adapter
import receiver_state
from test_keychain_cloud import FakeSecurity


class ReceiverStateTest(unittest.TestCase):
    def test_new_recipient_passphrase_in_fake_keychain_only_and_refuse_reinit(self):
        fake = FakeSecurity()
        with tempfile.TemporaryDirectory() as temporary, \
                patch.object(keychain_credentials, "_security", return_value=fake), \
                patch.object(keychain_credentials, "_nsdata", side_effect=lambda value: value):
            root = Path(temporary) / "receiver"
            public_info = receiver_state.initialize_receiver(root)
            public = root / mac_adapter.PUBLIC_FILE
            self.assertEqual(public_info["publicKeySha256"], hashlib.sha256(public.read_bytes()).hexdigest())
            self.assertEqual(serialization.load_pem_public_key(public.read_bytes()).key_size, 3072)
            slot = receiver_state.STORE_SERVICE, receiver_state.STORE_ACCOUNT
            self.assertEqual(set(fake.items), {slot})
            passphrase = receiver_state.load_store_passphrase()
            self.assertEqual(len(passphrase), 64)
            encrypted = (root / mac_adapter.RECIPIENT_FILE).read_text()
            self.assertNotIn(passphrase, encrypted)
            payload = mac_adapter.unseal(json.loads(encrypted), passphrase, "recipient-key")
            self.assertIn("PRIVATE KEY", payload["privatePem"])
            initial = public.read_bytes()
            with self.assertRaises(receiver_state.ReceiverStateError):
                receiver_state.initialize_receiver(root)
            self.assertEqual(public.read_bytes(), initial)
            self.assertEqual(len(fake.add_calls), 1)
            # A separate path cannot create a different receiver under the fixed same account.
            with self.assertRaises(receiver_state.ReceiverStateError):
                receiver_state.initialize_receiver(Path(temporary) / "second")
            self.assertFalse((Path(temporary) / "second").exists())

    def test_import_forwards_only_in_memory_passphrase_and_exact_expected_serial(self):
        # This tests receiver orchestration; Android crypto is covered in adapter tests.
        with patch.object(receiver_state, "load_store_passphrase", return_value="synthetic-phrase"), \
                patch.object(mac_adapter, "import_android") as importer:
            receiver_state.import_android_envelope(Path("encrypted.json"), Path("state"), "881TESTONLY")
            importer.assert_called_once_with(Path("encrypted.json"), Path("state"),
                                             "synthetic-phrase", "881TESTONLY")

    def test_failed_keychain_add_removes_only_this_calls_new_files(self):
        class RefusingSecurity(FakeSecurity):
            def SecItemAdd(self, attributes, unused):
                return -50, None
        fake = RefusingSecurity()
        with tempfile.TemporaryDirectory() as temporary, \
                patch.object(keychain_credentials, "_security", return_value=fake), \
                patch.object(keychain_credentials, "_nsdata", side_effect=lambda value: value):
            root = Path(temporary) / "receiver"
            with self.assertRaises(receiver_state.ReceiverStateError):
                receiver_state.initialize_receiver(root)
            self.assertFalse(root.exists())
            self.assertFalse(fake.items)


if __name__ == "__main__":
    unittest.main()
