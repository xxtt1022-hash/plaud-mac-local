import base64
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
import urllib.error

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import binding_registration as binding


class BindingRegistrationTest(unittest.TestCase):
    serial = "8811A2B3C4D5E6F7"
    owner = "0123456789abcdef0123456789abcdef"
    token = "SYNTHETIC_USER_TOKEN_NEVER_REAL"

    def jwt(self, subject):
        body = base64.urlsafe_b64encode(json.dumps({"sub": subject}).encode()).rstrip(b"=").decode()
        return "synthetic." + body + ".signature"

    def test_exact_subject_normalization_and_fail_closed_mismatch(self):
        subject = "client_user_01234567-89ab-cdef-0123-456789abcdef"
        binding.validate_candidate_user({"bindToken": self.owner}, self.jwt(subject))
        for subject in [self.owner.upper(), "other_user", "client_user_" + self.owner + "0"]:
            with self.assertRaises(binding.BindingRegistrationError):
                binding.validate_candidate_user({"bindToken": self.owner}, self.jwt(subject))

    def test_bad_token_errors_never_echo_input(self):
        for token in ["PRIVATE_TOKEN_MARKER", "a.e30.c"]:
            with self.assertRaises(binding.BindingRegistrationError) as error:
                binding.validate_candidate_user({"bindToken": self.owner}, token)
            self.assertNotIn("PRIVATE_TOKEN", str(error.exception))

    def test_no_request_before_explicit_verified_ble_status(self):
        sent = []
        for proof in [False, None, 1, "true"]:
            with self.assertRaises(binding.BindingRegistrationError):
                binding.register_cloud_binding(self.token, self.serial,
                    ble_bind_accepted=proof, _send=sent.append)
        self.assertEqual(sent, [])

    def test_single_exact_registration_request_and_strict_success(self):
        sent = []
        def send(request):
            sent.append(request)
            return 200, json.dumps({"is_bind": True, "sn": self.serial, "type": "notepro"}).encode()
        result = binding.register_cloud_binding(self.token, self.serial, ble_bind_accepted=True, _send=send)
        self.assertTrue(result["cloudBindingRegistrationVerified"])
        self.assertEqual(len(sent), 1)
        request = sent[0]
        self.assertEqual(request.full_url, binding.BIND_URL)
        self.assertEqual(request.method, "POST")
        self.assertEqual(json.loads(request.data), {"type": "notepro", "sn": self.serial})
        self.assertEqual(request.get_header("Authorization"), "Bearer " + self.token)
        self.assertNotIn(self.token, json.dumps(result))

    def test_403_does_not_retry_or_change_destination(self):
        sent = []
        def send(request):
            sent.append(request)
            return 403, b'{"private":"DO_NOT_ECHO_RESPONSE"}'
        with self.assertRaises(binding.BindingRegistrationError) as error:
            binding.register_cloud_binding(self.token, self.serial, ble_bind_accepted=True, _send=send)
        self.assertEqual(len(sent), 1)
        self.assertEqual(error.exception.http_status, 403)
        self.assertNotIn("DO_NOT_ECHO", str(error.exception))

    def test_bad_registration_responses_are_not_success(self):
        bodies = [b"not json", b"[]", b'{"is_bind":1}', b'{"is_bind":false}',
            b'{"is_bind":true,"sn":"WRONG"}', b'{"is_bind":true,"type":"notepin"}',
            b" " * (binding.MAX_RESPONSE + 1)]
        for body in bodies:
            with self.assertRaises(binding.BindingRegistrationError):
                binding.register_cloud_binding(self.token, self.serial, ble_bind_accepted=True,
                    _send=lambda request: (200, body))

    def test_invalid_serial_never_reaches_transport(self):
        sent = []
        with self.assertRaises(binding.BindingRegistrationError):
            binding.register_cloud_binding(self.token, "PRIVATE_SERIAL_MARKER", ble_bind_accepted=True,
                _send=sent.append)
        self.assertEqual(sent, [])

    def test_default_transport_keeps_tls_verification_and_blocks_redirects(self):
        fake_response = unittest.mock.MagicMock()
        fake_response.__enter__.return_value = fake_response
        fake_response.geturl.return_value = binding.BIND_URL
        fake_response.status = 200
        fake_response.read.return_value = b'{"is_bind":true}'
        opener = unittest.mock.Mock()
        opener.open.return_value = fake_response
        with patch.object(binding.urllib.request, "build_opener", return_value=opener) as build:
            result = binding.register_cloud_binding(self.token, self.serial, ble_bind_accepted=True)
        handlers = build.call_args.args
        self.assertTrue(any(isinstance(handler, binding._NoRedirect) for handler in handlers))
        https = next(handler for handler in handlers if isinstance(handler, binding.urllib.request.HTTPSHandler))
        self.assertTrue(https._context.check_hostname)
        self.assertEqual(https._context.verify_mode, binding.ssl.CERT_REQUIRED)
        self.assertTrue(result["cloudBindingRegistrationVerified"])
        fake_response.geturl.return_value = "https://unapproved.invalid/"
        with patch.object(binding.urllib.request, "build_opener", return_value=opener):
            with self.assertRaises(binding.BindingRegistrationError):
                binding.register_cloud_binding(self.token, self.serial, ble_bind_accepted=True)


if __name__ == "__main__":
    unittest.main()
