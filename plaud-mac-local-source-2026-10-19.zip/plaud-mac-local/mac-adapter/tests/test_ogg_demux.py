from __future__ import annotations

from contextlib import redirect_stderr, redirect_stdout
from io import StringIO
import hashlib
import json
from pathlib import Path
import stat
import struct
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT.parent / "plaud-direct-pc-research" / "pc-bridge" / "src"))
import ogg_demux
from plaud_pc.audio import _ogg_crc


def page(serial, seq, flags, granule, lacing, body):
    assert sum(lacing) == len(body)
    data = bytearray(b"OggS" + bytes([0, flags]) + struct.pack("<QII", granule, serial, seq)
                     + bytes(4) + bytes([len(lacing)]) + bytes(lacing) + body)
    struct.pack_into("<I", data, 22, _ogg_crc(data))
    return bytes(data)


def packet_page(serial, seq, flags, granule, packet):
    return page(serial, seq, flags, granule, [255] * (len(packet) // 255) + [len(packet) % 255], packet)


def head(channels=1, preskip=120, rate=16000):
    return b"OpusHead" + bytes([1, channels]) + struct.pack("<HIhB", preskip, rate, 0, 0)


def tags(vendor=b"SYNTHETIC_PRIVATE_COMMENT", comments=(), padding=b""):
    return (b"OpusTags" + struct.pack("<I", len(vendor)) + vendor + struct.pack("<I", len(comments))
            + b"".join(struct.pack("<I", len(c)) + c for c in comments) + padding)


def opus_stream(serial=19, *, preskip=120):
    return [packet_page(serial, 0, 2, 0, head(preskip=preskip)),
            packet_page(serial, 1, 0, 0, tags()),
            packet_page(serial, 2, 0, 48000, b"\xf8SYNTHETIC_AUDIO_ONE"),
            packet_page(serial, 3, 4, 96120, b"\xf8SYNTHETIC_AUDIO_TWO")]


class OggDemuxTest(unittest.TestCase):
    def mux(self):
        audio = opus_stream()
        other = [packet_page(77, 0, 2, 0, b"SYNTHETIC_OTHER_STREAM"),
                 packet_page(77, 1, 4, 0, b"SYNTHETIC_OTHER_END")]
        return b"".join([audio[0], other[0], audio[1], audio[2], other[1], audio[3]]), b"".join(audio)

    def test_unique_opus_selection_preserves_every_original_page_and_safe_metadata(self):
        mux, expected = self.mux()
        result = ogg_demux.inspect_ogg(mux)
        self.assertEqual(result.data, expected)
        self.assertEqual(result.metadata["selectedSha256"], hashlib.sha256(expected).hexdigest())
        self.assertEqual(result.metadata["logicalStreams"], 2)
        self.assertEqual(result.metadata["totalPages"], 6)
        self.assertEqual(result.metadata["selectedStreamPages"], 4)
        self.assertEqual(result.metadata["channels"], 1)
        self.assertEqual(result.metadata["preSkip"], 120)
        self.assertEqual(result.metadata["inputSampleRate"], 16000)
        self.assertEqual(result.metadata["containerTimelineSeconds"], 2)
        for flag in ("allPageCrcValid", "allStreamSequencesValid", "allStreamsEnded", "pagesVerbatim"):
            self.assertIs(result.metadata[flag], True)
        self.assertFalse(result.metadata["decodedDurationVerified"])
        for secret in ("SYNTHETIC_PRIVATE_COMMENT", "SYNTHETIC_AUDIO", "SYNTHETIC_OTHER"):
            self.assertNotIn(secret, json.dumps(result.metadata))
            self.assertNotIn(secret, repr(result))

    def test_crc_error_in_selected_or_unselected_stream_rejects_whole_mux(self):
        mux, _ = self.mux()
        for marker in (b"SYNTHETIC_AUDIO_ONE", b"SYNTHETIC_OTHER_END"):
            bad = bytearray(mux)
            bad[mux.index(marker)] ^= 1
            with self.assertRaises(ogg_demux.OggChecksumError):
                ogg_demux.inspect_ogg(bytes(bad))

    def test_sequence_missing_repeated_reordered_bos_and_page_after_eos_fail(self):
        stream = opus_stream()
        invalid = [b"".join([stream[0], stream[2], stream[3]]),
                   b"".join([stream[0], stream[1], stream[1], stream[2], stream[3]]),
                   b"".join([stream[0], stream[2], stream[1], stream[3]]),
                   b"".join(stream + [packet_page(19, 4, 0, 100000, b"late")]),
                   b"".join([packet_page(19, 0, 0, 0, head()), *stream[1:]])]
        for data in invalid:
            with self.assertRaises(ogg_demux.OggSequenceError):
                ogg_demux.inspect_ogg(data)

    def test_truncated_fixed_header_lacing_body_and_trailing_garbage_fail(self):
        data = b"".join(opus_stream())
        last = opus_stream()[-1]
        for truncated in (data[:-1], data[:-len(last)] + last[:26], data[:-len(last)] + last[:27], data + b"junk"):
            with self.assertRaises(ogg_demux.OggDemuxError):
                ogg_demux.inspect_ogg(truncated)

    def test_continued_comment_and_exact_255_audio_packet_are_valid_without_reslicing(self):
        comment = tags(vendor=b"v" * 300, comments=[b"c"], padding=b"padding")
        pieces = [packet_page(8, 0, 2, 0, head()),
                  page(8, 1, 0, ogg_demux.NO_GRANULE, [255], comment[:255]),
                  page(8, 2, 1, 0, [len(comment) - 255], comment[255:]),
                  page(8, 3, 0, ogg_demux.NO_GRANULE, [255], b"a" * 255),
                  page(8, 4, 5, 48120, [0], b"")]
        data = b"".join(pieces)
        result = ogg_demux.inspect_ogg(data)
        self.assertEqual(result.data, data)
        self.assertEqual(result.metadata["audioPackets"], 1)
        self.assertEqual(result.metadata["containerTimelineSeconds"], 1)

    def test_missing_spurious_continuation_and_unfinished_eos_fail(self):
        base = opus_stream()
        cases = [b"".join([base[0], base[1], packet_page(19, 2, 5, 48120, b"audio")]),
                 b"".join([base[0], base[1], page(19, 2, 4, ogg_demux.NO_GRANULE, [255], b"a" * 255)]),
                 b"".join([base[0], base[1], page(19, 2, 0, ogg_demux.NO_GRANULE, [255], b"a" * 255),
                            page(19, 3, 4, 48120, [1], b"b")])]
        for data in cases:
            with self.assertRaises(ogg_demux.OggContinuationError):
                ogg_demux.inspect_ogg(data)

    def test_two_opus_streams_or_no_opus_are_not_arbitrarily_selected(self):
        for data in (b"".join(opus_stream(5) + opus_stream(6)), packet_page(9, 0, 6, 0, b"metadata")):
            with self.assertRaises(ogg_demux.AmbiguousOpusStreams):
                ogg_demux.inspect_ogg(data)

    def test_invalid_or_missing_opus_headers_tags_and_granules_fail(self):
        stream = opus_stream()
        bad_tags = [b"OpusTags", b"OpusTags" + struct.pack("<I", 0xFFFFFFFF) + bytes(4),
                    b"OpusTags" + struct.pack("<II", 0, 1),
                    b"OpusTags" + struct.pack("<III", 0, 1, 999)]
        cases = [b"".join([stream[0], packet_page(19, 1, 0, 0, value), *stream[2:]]) for value in bad_tags]
        cases.extend([b"".join(stream[:-1]),
                      b"".join([stream[0], stream[1], packet_page(19, 2, 4, 119, b"audio")]),
                      b"".join([stream[0], stream[1], stream[2], packet_page(19, 3, 4, 100, b"audio")]),
                      b"".join([stream[0], stream[1], packet_page(19, 2, 4, 48120, head())])])
        for data in cases:
            with self.assertRaises(ogg_demux.OggDemuxError):
                ogg_demux.inspect_ogg(data)

    def test_header_must_be_alone_and_tags_must_finish_their_page(self):
        first = page(19, 0, 2, 0, [19, 1], head() + b"x")
        tags_then_audio = page(19, 1, 0, 0, [len(tags()), 1], tags() + b"x")
        stream = opus_stream()
        for data in (b"".join([first, *stream[1:]]), b"".join([stream[0], tags_then_audio, *stream[2:]])):
            with self.assertRaises(ogg_demux.OggDemuxError):
                ogg_demux.inspect_ogg(data)

    def test_nonzero_mapping_or_version_is_explicitly_unsupported(self):
        for offset, value in ((8, 2), (18, 1)):
            packet = bytearray(head())
            packet[offset] = value
            with self.assertRaises(ogg_demux.UnsupportedOpusProfile):
                ogg_demux.inspect_ogg(b"".join([packet_page(19, 0, 2, 0, packet), *opus_stream()[1:]]))

    def test_file_output_is_exclusive_private_and_input_is_unchanged(self):
        mux, expected = self.mux()
        with tempfile.TemporaryDirectory() as temporary:
            source, target = Path(temporary) / "source.ogg", Path(temporary) / "selected.ogg"
            source.write_bytes(mux)
            before = source.read_bytes()
            metadata = ogg_demux.demux_file(source, target)
            self.assertEqual(target.read_bytes(), expected)
            self.assertEqual(source.read_bytes(), before)
            self.assertEqual(stat.S_IMODE(target.stat().st_mode), 0o600)
            self.assertFalse(metadata["sourceModified"])
            for path in (target, source):
                with self.assertRaises(FileExistsError):
                    ogg_demux.demux_file(source, path)
            link = Path(temporary) / "link.ogg"
            link.symlink_to(source)
            with self.assertRaises(FileExistsError):
                ogg_demux.demux_file(source, link)
            self.assertEqual(source.read_bytes(), before)

    def test_invalid_input_never_creates_output_and_cli_suppresses_content(self):
        with tempfile.TemporaryDirectory() as temporary:
            source, target = Path(temporary) / "source.ogg", Path(temporary) / "selected.ogg"
            source.write_bytes(b"PRIVATE_CONTENT_MARKER")
            argv = ["ogg_demux.py", "--input", str(source), "--output", str(target)]
            out, err = StringIO(), StringIO()
            with patch.object(sys, "argv", argv), redirect_stdout(out), redirect_stderr(err), self.assertRaises(SystemExit):
                ogg_demux.main()
            self.assertFalse(target.exists())
            self.assertEqual(out.getvalue(), "")
            self.assertNotIn("PRIVATE_CONTENT_MARKER", err.getvalue())
            self.assertIn("OggDemuxError", err.getvalue())


if __name__ == "__main__":
    unittest.main()
