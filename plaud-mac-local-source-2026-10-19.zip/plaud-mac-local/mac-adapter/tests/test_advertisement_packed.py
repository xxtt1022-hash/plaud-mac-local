from __future__ import annotations

from pathlib import Path
import sys
import types
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import mac_adapter


class NoteProAdvertisementTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        upstream = Path(__file__).resolve().parents[2] / "plaud-direct-pc-research"
        if not upstream.is_dir():
            raise unittest.SkipTest("Sibling upstream source checkout is required")
        mac_adapter.attach_upstream(upstream)

    @staticmethod
    def packed(serial="8811A2B3C4D5E6F7"):
        # Synthetic serial only. Mirrors the observed wire structure, not a real device.
        return (b"\x02\x71\x03\x04V\x07\x04\x01\x08" + bytes.fromhex(serial)
                + b"\x44\x14\x00" + bytes(7))

    def test_packed_serial_is_hex_of_exact_eight_bytes(self):
        payload = self.packed()
        self.assertEqual(len(payload), 27)
        parsed = mac_adapter.parse_notepro_advertisement(payload)
        self.assertEqual(parsed.serial_number, "8811A2B3C4D5E6F7")
        self.assertEqual(parsed.project_code, 881)
        self.assertEqual(parsed.port_version, 20)
        adv = types.SimpleNamespace(manufacturer_data={93: payload}, local_name="Plaud Note Pro")
        self.assertTrue(mac_adapter.advertisement_matches(adv, "8811a2b3c4d5e6f7"))
        self.assertFalse(mac_adapter.advertisement_matches(adv, "8811A2B3C4D5E6F8"))
        self.assertFalse(mac_adapter.advertisement_matches(adv, "8811A2B3C4D5E6F7 "))

    def test_legacy_ascii_is_preserved_with_or_without_explicit_project(self):
        serial = b"881ASCII_TEST"
        tail = bytes([len(serial)]) + serial
        for prefix in (b"\x04V\x00\x07\x01", b"\x02\x71\x03\x04V\x00\x07\x01"):
            payload = prefix + tail
            parsed = mac_adapter.parse_notepro_advertisement(payload)
            self.assertEqual(parsed.serial_number, serial.decode())
            adv = types.SimpleNamespace(manufacturer_data={93: payload})
            self.assertTrue(mac_adapter.advertisement_matches(adv, serial.decode()))
            self.assertFalse(mac_adapter.advertisement_matches(adv, serial.decode().lower()))

    def test_all_truncations_and_unsupported_packed_layouts_are_rejected(self):
        original = self.packed()
        for length in range(len(original)):
            self.assertIsNone(mac_adapter.parse_notepro_advertisement(original[:length]), length)
        mutated = []
        for offset, value in ((0, 3), (1, 0x72), (3, 3), (4, ord("X")), (8, 9), (18, 21)):
            payload = bytearray(original)
            payload[offset] = value
            mutated.append(bytes(payload))
        mutated.extend((original + b"\x00", self.packed("8821A2B3C4D5E6F7")))
        for payload in mutated:
            self.assertIsNone(mac_adapter.parse_notepro_advertisement(payload))

    def test_invalid_ascii_does_not_match_after_dropping_bytes_or_by_name(self):
        malformed = b"881TEST\xffONLY"
        payload = b"\x04V\x00\x07\x01" + bytes([len(malformed)]) + malformed
        self.assertIsNone(mac_adapter.parse_notepro_advertisement(payload))
        adv = types.SimpleNamespace(manufacturer_data={93: payload}, local_name="Plaud Note Pro")
        self.assertFalse(mac_adapter.advertisement_matches(adv, "881TESTONLY"))
        self.assertFalse(mac_adapter.advertisement_matches(
            types.SimpleNamespace(manufacturer_data={}, local_name="Plaud Note Pro"), "881TESTONLY"))


if __name__ == "__main__":
    unittest.main()
