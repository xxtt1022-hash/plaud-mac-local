from __future__ import annotations

from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path
import signal
import struct
import subprocess
import sys
import tempfile
import types
import unittest
from unittest.mock import Mock, patch
import wave

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import asr_transcribe as asr


class AsrTranscribeTest(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.base = Path(self.temporary.name).resolve()
        self.source = self.base / "audio.ogg"
        self.source.write_bytes(b"SYNTHETIC_OGG_NOT_REAL_RECORDING")
        self.model = self.base / "synthetic-model.bin"
        self.model.write_bytes(b"SYNTHETIC_MODEL_NOT_FOR_INFERENCE")
        self.model_hash = hashlib.sha256(self.model.read_bytes()).hexdigest()
        self.binary = self.base / "fake-whisper"
        self.decoder = self.base / "fake-ffmpeg"
        for executable in (self.binary, self.decoder):
            executable.write_bytes(b"SYNTHETIC_NOT_EXECUTED")
            executable.chmod(0o700)
        self.run_dir = self.base / "asr-run"
        self.payload = {"params": {"translate": False}, "result": {"language": "zh"},
            "transcription": [
                {"offsets": {"from": 0, "to": 1200}, "timestamps": {"from": "00:00:00,000", "to": "00:00:01,200"},
                 "text": " 原语言第一段。 "},
                {"offsets": {"from": 1200, "to": 2400}, "text": "第二段没有编造说话人。"}]}
        self.processes = []
        self.arguments = []
        self.decode_action = None
        self.whisper_action = None
        self.decode_returncode = 0
        self.whisper_returncode = 0
        stack = ExitStack()
        self.addCleanup(stack.close)
        stack.enter_context(patch.dict(sys.modules, {"imageio_ffmpeg": types.SimpleNamespace(
            get_ffmpeg_exe=lambda: str(self.decoder))}))
        self.start = stack.enter_context(patch.object(asr.subprocess, "Popen", side_effect=self.spawn))

    @staticmethod
    def write_pcm(path: Path, frames=40000, *, rate=16000, channels=1, width=2):
        with wave.open(str(path), "wb") as output:
            output.setnchannels(channels)
            output.setsampwidth(width)
            output.setframerate(rate)
            output.writeframes(b"\x00" * frames * channels * width)

    def spawn(self, arguments, **kwargs):
        self.arguments.append((arguments, kwargs))
        self.assertFalse(kwargs["shell"])
        self.assertTrue(kwargs["start_new_session"])
        self.assertTrue(kwargs["close_fds"])
        self.assertEqual(kwargs["stdin"], subprocess.DEVNULL)
        self.assertEqual(kwargs["stderr"], subprocess.STDOUT)
        self.assertEqual(os.fstat(kwargs["stdout"].fileno()).st_mode & 0o777, 0o600)
        self.assertEqual(arguments[1:3], ["-c", asr._PRIVATE_EXEC])
        is_decoder = arguments[3] == str(self.decoder)
        kwargs["stdout"].write(b"PRIVATE_SYNTHETIC_SUBPROCESS_LOG\n")
        if is_decoder:
            action = self.decode_action or (lambda args: self.write_pcm(Path(args[-1])))
            action(arguments)
            returncode = self.decode_returncode
        else:
            self.assertEqual(arguments[3], str(self.binary))
            action = self.whisper_action or self.write_whisper
            action(arguments)
            returncode = self.whisper_returncode
        process = Mock(pid=987654, returncode=returncode)
        process.wait.return_value = returncode
        self.processes.append(process)
        return process

    def write_whisper(self, arguments):
        prefix = Path(arguments[arguments.index("-of") + 1])
        prefix.with_suffix(".json").write_text(json.dumps(self.payload, ensure_ascii=False), encoding="utf-8")
        prefix.with_suffix(".txt").write_text("原语言第一段。\n第二段。\n", encoding="utf-8")
        prefix.with_suffix(".srt").write_text("1\n00:00:00,000 --> 00:00:01,200\n原语言第一段。\n", encoding="utf-8")

    def transcribe(self, **overrides):
        arguments = {"source": self.source, "run_dir": self.run_dir, "whisper_binary": self.binary,
                     "model_path": self.model, "model_sha256": self.model_hash}
        arguments.update(overrides)
        return asr.transcribe_audio(**arguments)

    def assert_safe_failure(self, call, *, code=None):
        with self.assertRaises(asr.TranscriptionError) as caught:
            call()
        message = str(caught.exception)
        for forbidden in (str(self.base), "PRIVATE_SYNTHETIC_SUBPROCESS_LOG", "SYNTHETIC_MODEL", "原语言第一段"):
            self.assertNotIn(forbidden, message)
        if code is not None:
            self.assertEqual(caught.exception.code, code)
        return caught.exception

    def test_full_local_pipeline_preserves_language_measures_frames_and_private_artifacts(self):
        original_source = self.source.read_bytes()
        result = self.transcribe()
        self.assertEqual(self.source.read_bytes(), original_source)
        self.assertEqual(result["durationSeconds"], 2.5)
        self.assertEqual(result["segmentCount"], 2)
        self.assertEqual(result["metadata"], {"engine": "whisper_cpp", "model": self.model.name,
            "modelSha256": self.model_hash, "language": "zh", "needsReview": True,
            "inputSha256": hashlib.sha256(original_source).hexdigest()})
        self.assertIn("[00:00:00.000 --> 00:00:01.200]\n\n原语言第一段。", result["markdown"])
        self.assertIn("[00:00:01.200 --> 00:00:02.400]", result["markdown"])
        self.assertNotIn("说话人1", result["markdown"])
        segments_path = Path(result["segmentsPath"])
        self.assertTrue(segments_path.is_absolute())
        normalized = json.loads(segments_path.read_text())
        self.assertEqual(normalized["decodedFrames"], 40000)
        self.assertEqual(normalized["segments"][1]["endMilliseconds"], 2400)
        self.assertTrue(normalized["needsReview"])
        self.assertEqual((self.run_dir / "transcript.md").read_text(), result["markdown"])
        self.assertEqual(self.run_dir.stat().st_mode & 0o777, 0o700)
        for path in self.run_dir.iterdir():
            self.assertTrue(path.is_file())
            self.assertFalse(path.is_symlink())
            self.assertEqual(path.stat().st_mode & 0o777, 0o600)
        self.assertFalse((self.run_dir / "failure.json").exists())
        decode = self.arguments[0][0]
        for flag in ("-nostdin", "-n", "-xerror", "-err_detect", "-protocol_whitelist", "-format_whitelist"):
            self.assertIn(flag, decode)
        self.assertEqual(decode[decode.index("-protocol_whitelist") + 1], "file,pipe")
        self.assertEqual(decode[decode.index("-ar") + 1], "16000")
        self.assertEqual(decode[decode.index("-ac") + 1], "1")
        self.assertEqual(decode[decode.index("-c:a") + 1], "pcm_s16le")
        command = self.arguments[1][0]
        self.assertEqual(command[command.index("-l") + 1], "auto")
        self.assertNotIn("--translate", command)
        self.assertNotIn("-tr", command)
        for flag in ("-otxt", "-osrt", "-oj"):
            self.assertIn(flag, command)
        for process in self.processes:
            process.wait.assert_called_once_with(timeout=7200)

    def test_timestamp_only_json_and_explicit_language(self):
        self.payload = {"transcription": [{"timestamps": {"from": "00:00:00.200", "to": "00:00:02,400"},
                                            "text": "An original-language paragraph."}]}
        result = self.transcribe(language="en")
        self.assertEqual(result["metadata"]["language"], "en")
        self.assertIn("[00:00:00.200 --> 00:00:02.400]", result["markdown"])
        self.assertEqual(self.arguments[1][0][self.arguments[1][0].index("-l") + 1], "en")

    def test_model_hash_mismatch_never_launches_decoder_and_retains_safe_failure(self):
        self.assert_safe_failure(lambda: self.transcribe(model_sha256="0" * 64), code="model_hash_mismatch")
        self.start.assert_not_called()
        failure = json.loads((self.run_dir / "failure.json").read_text())
        self.assertEqual(failure["stage"], "model")
        self.assertFalse((self.run_dir / "result.json").exists())
        self.assertEqual((self.run_dir / "failure.json").stat().st_mode & 0o777, 0o600)

    def test_preexisting_run_is_never_reused_or_overwritten(self):
        self.run_dir.mkdir()
        sentinel = self.run_dir / "keep"
        sentinel.write_text("DO_NOT_OVERWRITE")
        self.assert_safe_failure(self.transcribe)
        self.assertEqual(sentinel.read_text(), "DO_NOT_OVERWRITE")
        self.assertEqual([p.name for p in self.run_dir.iterdir()], ["keep"])
        self.start.assert_not_called()

    def test_source_model_run_and_custom_ancestor_symlinks_are_rejected(self):
        link_source = self.base / "source-link"
        link_source.symlink_to(self.source)
        link_model = self.base / "model-link"
        link_model.symlink_to(self.model)
        real_dir = self.base / "real"
        real_dir.mkdir()
        link_run = self.base / "run-link"
        link_run.symlink_to(real_dir, target_is_directory=True)
        directory_link = self.base / "parent-link"
        directory_link.symlink_to(self.base, target_is_directory=True)
        for overrides in ({"source": link_source}, {"model_path": link_model}, {"run_dir": link_run},
                          {"source": directory_link / self.source.name}, {"run_dir": directory_link / "new-run"}):
            with self.subTest(overrides=tuple(overrides)):
                self.assert_safe_failure(lambda: self.transcribe(**overrides), code="symlink_not_allowed")
        self.start.assert_not_called()
        self.assertEqual(list(real_dir.iterdir()), [])

    def test_source_hardlink_and_untrusted_executable_alias_are_rejected(self):
        hardlink = self.base / "source-hardlink"
        os.link(self.source, hardlink)
        self.assert_safe_failure(self.transcribe, code="regular_file_required")
        hardlink.unlink()
        executable_link = self.base / "binary-link"
        executable_link.symlink_to(self.binary)
        self.assert_safe_failure(lambda: self.transcribe(whisper_binary=executable_link), code="symlink_not_allowed")
        self.start.assert_not_called()

    def test_invalid_configuration_rejected_before_any_files_are_created(self):
        for overrides in ({"model_sha256": "secret"}, {"language": "auto --translate"},
                          {"timeout_seconds": True}, {"timeout_seconds": 0}, {"timeout_seconds": 86401}):
            with self.subTest(overrides=overrides):
                self.assert_safe_failure(lambda: self.transcribe(**overrides))
        self.assertFalse(self.run_dir.exists())
        self.start.assert_not_called()

    def test_decoder_failure_keeps_logs_without_starting_asr(self):
        self.decode_returncode = 1
        self.assert_safe_failure(self.transcribe, code="process_failed")
        self.assertEqual(self.start.call_count, 1)
        self.assertIn(b"PRIVATE_SYNTHETIC_SUBPROCESS_LOG", (self.run_dir / "ffmpeg.log").read_bytes())
        self.assertFalse((self.run_dir / "whisper.log").exists())
        self.assertFalse((self.run_dir / "result.json").exists())

    def test_asr_failure_keeps_all_existing_outputs_and_no_success_manifest(self):
        self.whisper_returncode = 7
        self.assert_safe_failure(self.transcribe, code="process_failed")
        for name in ("whisper.log", "whisper.txt", "whisper.srt", "whisper.json", "failure.json"):
            self.assertTrue((self.run_dir / name).is_file())
        self.assertFalse((self.run_dir / "result.json").exists())
        self.assertFalse((self.run_dir / "transcript.md").exists())

    def test_timeout_kills_entire_child_process_group_and_retains_logs(self):
        process = Mock(pid=987655)
        process.wait.side_effect = [subprocess.TimeoutExpired(["PRIVATE_ARGUMENT"], 1), -9]
        self.start.side_effect = None
        self.start.return_value = process
        with patch.object(asr.os, "killpg") as kill:
            error = self.assert_safe_failure(lambda: self.transcribe(timeout_seconds=1), code="process_timeout")
        self.assertEqual(error.stage, "decode")
        kill.assert_called_once_with(987655, signal.SIGKILL)
        self.assertEqual(process.wait.call_args_list[0].kwargs, {"timeout": 1})
        self.assertEqual(process.wait.call_args_list[1].kwargs, {"timeout": 5})
        self.assertTrue((self.run_dir / "failure.json").exists())

    def test_full_pcm_measurement_rejects_bad_format_and_truncated_data(self):
        def truncated(arguments):
            path = Path(arguments[-1])
            self.write_pcm(path)
            data = bytearray(path.read_bytes())
            data[40:44] = struct.pack("<I", 80002)
            path.write_bytes(data)
        for index, action in enumerate((lambda args: self.write_pcm(Path(args[-1]), rate=8000),
                                        lambda args: self.write_pcm(Path(args[-1]), channels=2),
                                        lambda args: self.write_pcm(Path(args[-1]), frames=0), truncated)):
            with self.subTest(index=index):
                self.decode_action = action
                self.assert_safe_failure(lambda: self.transcribe(run_dir=self.base / f"bad-pcm-{index}"))
        self.assertEqual(self.start.call_count, 4)

    def test_model_changed_during_inference_is_not_reported_successful(self):
        def mutate(arguments):
            self.write_whisper(arguments)
            self.model.write_bytes(b"CHANGED_MODEL")
        self.whisper_action = mutate
        self.assert_safe_failure(self.transcribe, code="model_changed")
        self.assertFalse((self.run_dir / "result.json").exists())

    def test_decoder_cannot_prepopulate_whisper_output_for_later_overwrite(self):
        def prepopulate(arguments):
            self.write_pcm(Path(arguments[-1]))
            (self.run_dir / "whisper.txt").write_text("PRESERVE_EXISTING")
        self.decode_action = prepopulate
        self.assert_safe_failure(self.transcribe, code="output_already_exists")
        self.assertEqual((self.run_dir / "whisper.txt").read_text(), "PRESERVE_EXISTING")
        self.assertEqual(self.start.call_count, 1)

    def test_empty_missing_malformed_or_translated_json_never_succeeds(self):
        bad_payloads = [{}, {"transcription": []}, {"transcription": [{"text": " "}]},
            {"transcription": [{"text": "words", "offsets": {"from": True, "to": 1000}}]},
            {"transcription": [{"text": "words", "timestamps": {"from": "00:00:61,000", "to": "00:00:62,000"}}]},
            {"params": {"translate": True}, "transcription": [{"text": "translated", "offsets": {"from": 0, "to": 1000}}]}]
        for index, payload in enumerate(bad_payloads):
            with self.subTest(index=index):
                self.payload = payload
                directory = self.base / f"empty-{index}"
                self.assert_safe_failure(lambda: self.transcribe(run_dir=directory))
                self.assertFalse((directory / "result.json").exists())

    def test_offsets_are_milliseconds_ordered_and_bounded_by_measured_duration(self):
        invalid = [
            [{"text": "a", "offsets": {"from": -1, "to": 1000}}],
            [{"text": "a", "offsets": {"from": 1000, "to": 1000}}],
            [{"text": "a", "offsets": {"from": 0, "to": 1001}}, {"text": "b", "offsets": {"from": 1000, "to": 2000}}],
            [{"text": "a", "offsets": {"from": 0, "to": 3501}}],
            [{"text": "a", "offsets": {"from": 0, "to": 1000}, "timestamps": {"from": "00:00:00,000", "to": "00:00:02,000"}}],
        ]
        for index, items in enumerate(invalid):
            with self.subTest(index=index):
                self.assert_safe_failure(lambda: asr._parse_segments({"transcription": items}, 2.5))
        accepted = asr._parse_segments({"transcription": [{"text": "within decoder tolerance", "offsets": {"from": 0, "to": 3500}}]}, 2.5)
        self.assertEqual(accepted[0]["endMilliseconds"], 3500)

    def test_missing_required_text_output_is_failure_even_with_valid_json(self):
        def omit(arguments):
            self.write_whisper(arguments)
            prefix = Path(arguments[arguments.index("-of") + 1])
            prefix.with_suffix(".txt").unlink()
        self.whisper_action = omit
        self.assert_safe_failure(self.transcribe)
        self.assertFalse((self.run_dir / "segments.json").exists())


if __name__ == "__main__":
    unittest.main()
