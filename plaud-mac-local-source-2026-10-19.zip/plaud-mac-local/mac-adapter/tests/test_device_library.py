from __future__ import annotations

import asyncio
from contextlib import ExitStack
import json
import os
from pathlib import Path
import struct
import sys
import tempfile
import types
import unittest
from unittest.mock import AsyncMock, Mock, patch
import wave

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import device_library as library
import mac_adapter
import receiver_state
import ogg_demux


class DeviceLibraryTest(unittest.IsolatedAsyncioTestCase):
    @classmethod
    def setUpClass(cls):
        source = Path(__file__).resolve().parents[2] / "plaud-direct-pc-research" / "pc-bridge" / "src"
        sys.path.insert(0, str(source))
        private = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        cls.sn = "8811A2B3C4D5E6F7"
        cls.owner = {"version": 1, "verification": "confirmed", "sn": cls.sn,
            "signature": mac_adapter.b64(b"s" * 256), "bindToken": "a" * 32,
            "rsaPublicKey": private.public_key().public_bytes(serialization.Encoding.PEM,
                serialization.PublicFormat.SubjectPublicKeyInfo).decode(),
            "rsaPrivateKey": private.private_bytes(serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8, serialization.NoEncryption()).decode()}

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.raw = self.raw_container()
        self.file = types.SimpleNamespace(session_id=7, size=len(self.raw), scene=0, marked=False)
        self.snapshot = self.make_snapshot([self.file])
        self.connection = types.SimpleNamespace(connect=AsyncMock(), disconnect=AsyncMock(),
            start_notify=AsyncMock(), stop_notify=AsyncMock())
        self.bridge = types.SimpleNamespace(authenticate=AsyncMock(return_value=(1, 20)),
            read_snapshot=AsyncMock(return_value=self.snapshot), download_file=AsyncMock(side_effect=self.download))
        self.scan = AsyncMock(return_value=object())
        self.client_factory = Mock(return_value=self.connection)
        fake_bleak = types.SimpleNamespace(BleakClient=self.client_factory,
            BleakScanner=types.SimpleNamespace(find_device_by_filter=self.scan))
        stack = ExitStack()
        self.addCleanup(stack.close)
        stack.enter_context(patch.dict(sys.modules, {"bleak": fake_bleak}))
        stack.enter_context(patch.object(receiver_state, "load_device_identity", return_value=self.owner))
        stack.enter_context(patch.object(mac_adapter, "attach_upstream"))
        stack.enter_context(patch.object(mac_adapter, "paired_client", return_value=self.bridge))
        self.service = library.DeviceLibrary(Path("synthetic-upstream"), self.root / "state", self.sn,
                                              self.root / "downloads")

    @staticmethod
    def raw_container(counter=0):
        header = bytearray(512)
        header[:8] = b"PLAUD.AI"
        struct.pack_into("<HHI", header, 8, 1, 512, 0)
        struct.pack_into("<HHH", header, 48, 1, 1, 1)
        struct.pack_into("<I", header, 54, 0)  # Header duration is intentionally not trusted.
        struct.pack_into("<I", header, 128, counter)
        struct.pack_into("<I", header, 144, 0)
        return bytes(header) + b"SYNTHETIC_ENCRYPTED_AUDIO"

    @staticmethod
    def make_snapshot(files):
        return types.SimpleNamespace(battery_percent=59, charging=False,
            free_bytes=100_000, total_bytes=200_000, files=tuple(files))

    async def download(self, connection, selected, output_dir, *, port_version):
        self.assertIs(connection, self.connection)
        self.assertEqual((selected.session_id, selected.size, port_version), (7, len(self.raw), 20))
        partial = output_dir / "7.plaud.part"
        self.assertEqual(partial.stat().st_mode & 0o777, 0o600)
        self.assertEqual(partial.stat().st_size, 0)  # A fresh destination, never resumed.
        partial.write_bytes(self.raw)
        target = output_dir / "7.plaud"
        partial.replace(target)
        return types.SimpleNamespace(path=target, file=selected, crc=1234)

    def pipeline(self):
        stack = ExitStack()
        def decrypt(source, target, private):
            self.assertEqual(private, self.owner["rsaPrivateKey"])
            self.assertTrue(source.exists())
            partial = target.with_suffix(".ogg.part")
            partial.write_bytes(b"OggS_SYNTHETIC_MULTIPLEX")
            partial.replace(target)
        def demux(source, target):
            fd = library._new_private_file(target)
            with os.fdopen(fd, "wb") as output:
                output.write(b"OggS_SYNTHETIC_OPUS")
            return {"allPageCrcValid": True, "logicalStreams": 2, "channels": 1,
                    "decodedDurationVerified": False}
        async def decode(audio, wav):
            self.write_wav(wav)
            return {"durationSeconds": 0.25, "sampleRate": 8000, "channels": 1,
                    "sampleWidthBytes": 2, "decodedFrames": 2000, "decodeVerified": True}
        stack.enter_context(patch("plaud_pc.audio.decrypt_plaud_audio", side_effect=decrypt))
        stack.enter_context(patch.object(ogg_demux, "demux_file", side_effect=demux))
        stack.enter_context(patch.object(library, "_decode_wav", side_effect=decode))
        return stack

    @staticmethod
    def write_wav(path):
        fd = library._new_private_file(path)
        with os.fdopen(fd, "wb") as output:
            with wave.open(output, "wb") as wav:
                wav.setnchannels(1)
                wav.setsampwidth(2)
                wav.setframerate(8000)
                wav.writeframes(bytes(4000))

    async def test_refresh_is_one_live_connection_and_exact_sn_filter(self):
        result = await self.service.refresh()
        self.assertTrue(result["ok"])
        self.assertEqual(result["snapshotSource"], "live")
        self.assertEqual(result["sn"], self.sn)
        self.assertTrue(result["observedAt"].endswith("Z"))
        self.assertEqual(result["files"], [{"sessionId": 7, "size": len(self.raw), "scene": 0, "marked": False}])
        self.assertEqual(result["freeBytes"], 100_000)
        with patch.object(mac_adapter, "advertisement_matches", return_value=False) as matches:
            self.assertFalse(self.scan.call_args.args[0](object(), "synthetic-advertisement"))
            matches.assert_called_once_with("synthetic-advertisement", self.sn)
        self.assertEqual(self.scan.await_count, 1)
        self.assertEqual(self.client_factory.call_count, 1)
        self.assertEqual(self.connection.connect.await_count, 1)
        self.assertEqual(self.connection.disconnect.await_count, 1)
        self.bridge.download_file.assert_not_awaited()

    async def test_download_keeps_raw_matches_source_and_uses_only_decoded_duration(self):
        self.bridge.read_snapshot.side_effect = [self.snapshot, self.snapshot]
        with self.pipeline():
            result = await self.service.download(7, len(self.raw))
        self.assertTrue(result["ok"])
        self.assertTrue(result["sourceRetained"])
        self.assertTrue(result["decodeVerified"])
        self.assertEqual(result["durationSeconds"], 0.25)  # Not the encrypted header's zero.
        self.assertEqual({file["role"] for file in result["files"]}, {"raw", "audio", "wav"})
        self.assertEqual(result["transport"]["tailCrcReceived"], 1234)
        self.assertIs(result["transport"]["tailCrcVerified"], False)
        folder = Path(result["outputDirectory"])
        self.assertEqual(folder.stat().st_mode & 0o777, 0o700)
        for path in folder.iterdir():
            self.assertEqual(path.stat().st_mode & 0o777, 0o600)
        report = json.loads((folder / "report.json").read_text())
        self.assertNotIn(self.owner["rsaPrivateKey"], json.dumps(report))
        self.assertNotIn(self.owner["bindToken"], json.dumps(report))
        self.assertEqual(self.bridge.read_snapshot.await_count, 2)
        self.assertEqual(self.connection.connect.await_count, 1)

    async def test_stale_selection_and_missing_source_stop_without_claiming_success(self):
        changed = types.SimpleNamespace(session_id=7, size=len(self.raw) + 1, scene=0, marked=False)
        self.bridge.read_snapshot.return_value = self.make_snapshot([changed])
        stale = await self.service.download(7, len(self.raw))
        self.assertFalse(stale["ok"])
        self.assertEqual(stale["stage"], "verify_live_selection")
        self.bridge.download_file.assert_not_awaited()
        self.bridge.read_snapshot.side_effect = [self.snapshot, self.make_snapshot([])]
        missing = await self.service.download(7, len(self.raw))
        self.assertFalse(missing["sourceRetained"])
        self.assertFalse(missing["decodeVerified"])
        self.assertEqual(missing["stage"], "verify_source_retained")
        self.assertEqual([f["role"] for f in missing["files"]], ["raw"])

    async def test_unknown_profile_retains_raw_and_does_not_attempt_decrypt(self):
        self.raw = self.raw_container(counter=1)
        with patch("plaud_pc.audio.decrypt_plaud_audio") as decrypt:
            result = await self.service.download(7, len(self.raw))
        self.assertFalse(result["ok"])
        self.assertEqual(result["errorType"], "UnsupportedPlaudProfile")
        self.assertEqual(result["stage"], "validate_audio_profile")
        self.assertEqual([f["role"] for f in result["files"]], ["raw"])
        self.assertTrue(result["sourceRetained"])
        decrypt.assert_not_called()

    async def test_partial_download_error_is_redacted_preserved_and_not_false_success(self):
        async def partial(connection, selected, folder, *, port_version):
            (folder / "7.plaud.part").write_bytes(b"partial")
            raise ValueError("SYNTHETIC_PRIVATE_ERROR_MARKER")
        self.bridge.download_file.side_effect = partial
        result = await self.service.download(7, len(self.raw))
        self.assertFalse(result["ok"])
        self.assertFalse(result["decodeVerified"])
        self.assertEqual(result["files"], [])
        self.assertEqual(result["stage"], "download")
        self.assertEqual(result["errorType"], "ValueError")
        folder = Path(result["outputDirectory"])
        self.assertEqual((folder / "7.plaud.part").read_bytes(), b"partial")
        self.assertNotIn("PRIVATE_ERROR", json.dumps(result))
        self.assertEqual(self.connection.disconnect.await_count, 1)

    async def test_candidate_identity_and_bad_selection_stop_before_connection(self):
        with patch.object(receiver_state, "load_device_identity", return_value={**self.owner, "verification": "candidate"}):
            result = await self.service.refresh()
        self.assertFalse(result["ok"])
        self.assertEqual(result["snapshotSource"], "unavailable")
        self.client_factory.assert_not_called()
        result = await self.service.download(True, len(self.raw))
        self.assertFalse(result["ok"])
        self.client_factory.assert_not_called()

    async def test_strict_decoder_flags_and_wave_measurement_without_running_binary(self):
        wav, audio = self.root / "synthetic.wav", self.root / "synthetic.ogg"
        process = types.SimpleNamespace(wait=AsyncMock(return_value=0), returncode=0)
        async def spawn(*args, **kwargs):
            self.write_wav(wav)
            return process
        imageio = types.SimpleNamespace(get_ffmpeg_exe=lambda: sys.executable)
        with patch.dict(sys.modules, {"imageio_ffmpeg": imageio}), \
                patch.object(asyncio, "create_subprocess_exec", side_effect=spawn) as start:
            result = await library._decode_wav(audio, wav)
        args = start.call_args.args
        for flag in ("-nostdin", "-n", "-xerror", "explode", "0:a:0", "pcm_s16le"):
            self.assertIn(flag, args)
        self.assertIn("os.umask(0o077)", args[2])
        self.assertTrue(result["decodeVerified"])
        self.assertEqual((result["durationSeconds"], result["sampleRate"], result["channels"]), (0.25, 8000, 1))

    async def test_nonzero_full_file_decoder_never_claims_verified_audio(self):
        wav, audio = self.root / "failed.wav", self.root / "synthetic.ogg"
        process = types.SimpleNamespace(wait=AsyncMock(return_value=1), returncode=1)
        imageio = types.SimpleNamespace(get_ffmpeg_exe=lambda: sys.executable)
        with patch.dict(sys.modules, {"imageio_ffmpeg": imageio}), \
                patch.object(asyncio, "create_subprocess_exec", AsyncMock(return_value=process)):
            with self.assertRaises(library.DeviceLibraryError):
                await library._decode_wav(audio, wav)
        self.assertFalse(wav.exists())
        with self.pipeline(), patch.object(library, "_decode_wav",
                AsyncMock(side_effect=library.DeviceLibraryError("SYNTHETIC_PRIVATE_DECODER_ERROR"))):
            result = await self.service.download(7, len(self.raw))
        self.assertFalse(result["ok"])
        self.assertFalse(result["decodeVerified"])
        self.assertTrue(result["sourceRetained"])
        self.assertEqual(result["stage"], "decode_complete_file")
        self.assertEqual([item["role"] for item in result["files"]], ["raw", "audio"])
        self.assertNotIn("PRIVATE_DECODER", json.dumps(result))


if __name__ == "__main__":
    unittest.main()
