from __future__ import annotations

from contextlib import redirect_stderr, redirect_stdout
from email.message import Message
from http.server import HTTPServer
from io import BytesIO, StringIO
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import token_bridge


class HandlerHarness:
    """A handler-shaped object, without sockets, HTTP service or credential access."""
    def __init__(self, path, hosts=None, deadline=100):
        self.path = path
        self.server = types.SimpleNamespace(path="/synthetic-capability", png=b"synthetic-png",
                                            deadline=deadline, server_port=41999)
        self.headers = Message()
        for host in hosts or []:
            self.headers.add_header("Host", host)
        self.wfile = BytesIO()
        self.send_error = Mock()
        self.send_response = Mock()
        self.send_header = Mock()
        self.end_headers = Mock()

    def get(self):
        token_bridge.TokenHandler.do_GET(self)


class HandlerBoundaryTest(unittest.TestCase):
    def test_exact_host_and_exact_paths_only(self):
        with patch.object(token_bridge.time, "monotonic", return_value=20):
            for path, expected_type in (("/synthetic-capability", "text/html; charset=utf-8"),
                                         ("/synthetic-capability/qr.png", "image/png")):
                handler = HandlerHarness(path, ["127.0.0.1:41999"])
                handler.get()
                handler.send_response.assert_called_once_with(200)
                handler.send_header.assert_any_call("Content-Type", expected_type)
                handler.send_header.assert_any_call("Cache-Control", "no-store, max-age=0")
                handler.send_header.assert_any_call("Referrer-Policy", "no-referrer")
            for path in ("/", "/synthetic-capability?x=1", "/synthetic-capability/",
                         "/synthetic-capability/qr.png?x=1", "/other/qr.png"):
                handler = HandlerHarness(path, ["127.0.0.1:41999"])
                handler.get()
                handler.send_error.assert_called_once_with(404)
                self.assertEqual(handler.wfile.getvalue(), b"")
            for hosts in ([], ["evil.example"], ["localhost:41999"], ["127.0.0.1:42000"],
                          ["127.0.0.1:41999", "evil.example"]):
                handler = HandlerHarness("/synthetic-capability/qr.png", hosts)
                handler.get()
                handler.send_error.assert_called_once_with(403)
                self.assertEqual(handler.wfile.getvalue(), b"")

    def test_deadline_refuses_both_html_and_png(self):
        with patch.object(token_bridge.time, "monotonic", return_value=100):
            for path in ("/synthetic-capability", "/synthetic-capability/qr.png"):
                handler = HandlerHarness(path, ["127.0.0.1:41999"])
                handler.get()
                handler.send_error.assert_called_once_with(410)
                self.assertEqual(handler.wfile.getvalue(), b"")

    def test_request_logging_suppressed_even_if_secret_in_message(self):
        out, err = StringIO(), StringIO()
        with redirect_stdout(out), redirect_stderr(err):
            token_bridge.TokenHandler.log_message(object(), "synthetic-secret-token %s", "example")
        self.assertEqual(out.getvalue() + err.getvalue(), "")


class ServerLifecycleTest(unittest.TestCase):
    def test_loopback_binding_ttl_and_close_clear_without_opening_socket(self):
        with patch.object(HTTPServer, "__init__", return_value=None) as initialize, \
                patch.object(token_bridge.time, "monotonic", return_value=10), \
                patch.object(HTTPServer, "server_close", return_value=None):
            server = token_bridge.TokenView(b"synthetic-qr-png", ttl=30)
            initialize.assert_called_once_with(("127.0.0.1", 0), token_bridge.TokenHandler)
            self.assertEqual(server.deadline, 40)
            self.assertGreaterEqual(len(server.path), 40)
            server.server_close()
            self.assertEqual(server.png, b"")
        with patch.object(HTTPServer, "__init__") as initialize:
            for ttl in (0, -1, 601, True, 1.5):
                with self.assertRaises(ValueError):
                    token_bridge.TokenView(b"synthetic", ttl=ttl)
            initialize.assert_not_called()

    def test_accepted_connection_has_timeout(self):
        connection = Mock()
        server = object.__new__(token_bridge.TokenView)
        with patch.object(HTTPServer, "get_request", return_value=(connection, ("127.0.0.1", 123))):
            actual, address = server.get_request()
        self.assertIs(actual, connection)
        self.assertEqual(address[0], "127.0.0.1")
        connection.settimeout.assert_called_once_with(2)

    def test_qr_uses_in_memory_stream_and_emits_no_secret(self):
        image = Mock()
        def save(output, **kwargs):
            self.assertIsInstance(output, BytesIO)
            self.assertEqual(kwargs, {"format": "PNG"})
            output.write(b"synthetic-qr-png")
        image.save.side_effect = save
        qr = Mock()
        qr.make_image.return_value = image
        package = types.SimpleNamespace(QRCode=Mock(return_value=qr),
                                        constants=types.SimpleNamespace(ERROR_CORRECT_L=1))
        out, err = StringIO(), StringIO()
        with patch.dict(sys.modules, {"qrcode": package}), \
                patch.object(Path, "write_bytes", side_effect=AssertionError("No disk output")), \
                patch.object(Path, "write_text", side_effect=AssertionError("No disk output")), \
                redirect_stdout(out), redirect_stderr(err):
            result = token_bridge.qr_png("synthetic-token-never-real")
        qr.add_data.assert_called_once_with("synthetic-token-never-real")
        self.assertEqual(result, b"synthetic-qr-png")
        self.assertEqual(out.getvalue() + err.getvalue(), "")


if __name__ == "__main__":
    unittest.main()
