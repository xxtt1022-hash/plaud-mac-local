"""Synthetic library + mocked ASR/Codex; no user audio, models or network."""
from __future__ import annotations

import hashlib
from pathlib import Path
import sys
import tempfile
import threading
import time
import types
import unittest
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from auto_pipeline import ProcessingEngine
from recording_library import Library


class AutomaticPipelineTest(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.base = Path(temporary.name)
        self.library = Library(self.base / "library")
        audio = self.base / "synthetic.ogg"
        audio.write_bytes(b"OggS_SYNTHETIC_AUDIO_NO_REAL_RECORDING")
        self.record = self.library.import_recording("881SYNTHETIC0001", 123456789,
            {"audio": audio}, title="合成音频", decode_verified=True)
        for name in ("whisper", "model", "codex"):
            (self.base / name).write_bytes(b"SYNTHETIC_FILE_NEVER_EXECUTED")
        self.config = {"enabled": True, "autoProcessNew": False,
            "whisperBinary": str(self.base / "whisper"), "modelPath": str(self.base / "model"),
            "modelSha256": "a" * 64, "codexBinary": str(self.base / "codex"), "language": "auto"}
        self.asr = Mock(side_effect=self.asr_result)
        self.minutes = Mock(side_effect=self.minutes_result)
        asr_module = types.ModuleType("asr_transcribe")
        asr_module.transcribe_audio = self.asr
        minutes_module = types.ModuleType("codex_minutes")
        minutes_module.generate_minutes = self.minutes
        self.module_patch = patch.dict(sys.modules, {
            "asr_transcribe": asr_module, "codex_minutes": minutes_module})
        self.module_patch.start()
        self.addCleanup(self.module_patch.stop)
        self.engine = self.new_engine()

    def new_engine(self):
        engine = ProcessingEngine(self.library, self.config)
        self.addCleanup(self.close_engine, engine)
        return engine

    @staticmethod
    def close_engine(engine):
        engine.close()
        if engine.thread is not None:
            engine.thread.join(5)
            if engine.thread.is_alive():
                raise AssertionError("Synthetic processing thread did not stop")

    def asr_result(self, audio_path, output_dir, *args, **kwargs):
        self.assertEqual(audio_path.read_bytes(), b"OggS_SYNTHETIC_AUDIO_NO_REAL_RECORDING")
        output_dir.mkdir(mode=0o700)
        segments = output_dir / "segments.json"
        segments.write_text('{"segments":[]}')
        return {"ok": True, "markdown": "[00:00] 合成原语言转写。",
            "segmentsPath": str(segments), "metadata": {"engine": "whisper.cpp",
                "model": "synthetic-model", "modelSha256": "a" * 64, "language": "zh"}}

    def minutes_result(self, transcript, output_dir, *args, **kwargs):
        current = self.library.get_recording(self.record["id"])
        self.assertEqual(transcript, current["transcript"])
        self.assertTrue(current["textStatus"]["transcript"]["present"])
        output_dir.mkdir(mode=0o700)
        return {"ok": True, "markdown": "合成纪要：仅供测试。",
            "metadata": {"provider": "codex_cli", "needsReview": True, "model": "synthetic-model",
                "exitCode": 0, "toolUseDetected": False, "modelSource": "cli_event"}}

    def latest(self, engine=None):
        return (engine or self.engine).status()["latest"][self.record["id"]]

    def run_job(self, action="pipeline"):
        job = self.engine.enqueue(self.record["id"], action)
        self.engine.execute(job)
        return self.latest()

    def wait_terminal(self, timeout=5):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            latest = self.latest()
            if latest["state"] not in ("queued", "running"):
                return latest
            threading.Event().wait(0.01)
        self.fail("Synthetic job did not reach a terminal state")

    def test_pipeline_saves_transcript_before_minutes_with_bound_generated_sources(self):
        job = self.run_job()
        self.assertEqual(job["state"], "completed")
        self.assertEqual((self.asr.call_count, self.minutes.call_count), (1, 1))
        detail = self.library.get_recording(self.record["id"])
        transcript = detail["textStatus"]["transcript"]
        minutes = detail["textStatus"]["minutes"]
        self.assertEqual(transcript["source"], "whisper_cpp")
        self.assertTrue(transcript["automaticAsr"])
        self.assertEqual(transcript["metadata"]["inputSha256"], detail["artifacts"]["audio"]["sha256"])
        self.assertEqual(transcript["sha256"], hashlib.sha256(detail["transcript"].encode()).hexdigest())
        self.assertEqual(minutes["source"], "codex_cli")
        self.assertTrue(minutes["generated"])
        self.assertEqual(minutes["metadata"]["transcriptVersion"], transcript["version"])
        self.assertEqual(minutes["metadata"]["transcriptSha256"], transcript["sha256"])
        self.assertEqual(job["result"]["transcriptVersion"], 1)
        self.assertEqual(job["result"]["minutesVersion"], 1)
        self.assertEqual(len(detail["textVersions"]["transcript"]), 1)
        self.assertEqual(len(detail["textVersions"]["minutes"]), 1)

    def test_minutes_failure_keeps_transcript_and_pipeline_retry_does_not_repeat_asr(self):
        self.minutes.side_effect = RuntimeError("PRIVATE_SYNTHETIC_ERROR_NOT_FOR_UI")
        first = self.run_job()
        self.assertEqual(first["state"], "failed")
        self.assertEqual(first["stage"], "generating_minutes")
        self.assertEqual(first["errorType"], "RuntimeError")
        self.assertNotIn("PRIVATE_SYNTHETIC", str(first))
        saved = self.library.get_recording(self.record["id"])
        self.assertTrue(saved["textStatus"]["transcript"]["present"])
        self.assertFalse(saved["textStatus"]["minutes"]["present"])
        first_path = saved["textStatus"]["transcript"]["relativePath"]
        self.minutes.side_effect = self.minutes_result
        second = self.run_job()
        self.assertNotEqual(second["id"], first["id"])
        self.assertEqual(second["state"], "completed")
        self.assertEqual(self.asr.call_count, 1)
        self.assertEqual(self.minutes.call_count, 2)
        detail = self.library.get_recording(self.record["id"])
        self.assertEqual(detail["textStatus"]["transcript"]["relativePath"], first_path)
        self.assertEqual(len(detail["textVersions"]["transcript"]), 1)

    def test_pipeline_refreshes_outdated_generated_minutes_and_preserves_history(self):
        self.assertEqual(self.run_job()["state"], "completed")
        edited = self.library.save_text(self.record["id"], "transcript", "用户核对后修正的原语言转写。")
        first_minutes = edited["textStatus"]["minutes"]["sha256"]
        self.assertEqual(self.run_job()["state"], "completed")
        current = self.library.get_recording(self.record["id"])
        self.assertEqual(self.asr.call_count, 1)
        self.assertEqual(self.minutes.call_count, 2)
        self.assertEqual(current["textStatus"]["minutes"]["metadata"]["transcriptSha256"],
                         current["textStatus"]["transcript"]["sha256"])
        self.assertEqual(current["textStatus"]["minutes"]["version"], 2)
        self.assertEqual(current["textVersions"]["minutes"][0]["sha256"], first_minutes)

    def test_same_record_queued_and_inflight_enqueue_is_idempotent(self):
        entered, release = threading.Event(), threading.Event()
        self.addCleanup(release.set)
        def blocked_asr(*args, **kwargs):
            entered.set()
            if not release.wait(5):
                raise AssertionError("Synthetic ASR was not released")
            return self.asr_result(*args, **kwargs)
        self.asr.side_effect = blocked_asr
        job = self.engine.enqueue(self.record["id"])
        queued_duplicate = self.engine.enqueue(self.record["id"], "transcribe")
        self.assertEqual(queued_duplicate["id"], job["id"])
        self.engine.start()
        try:
            self.assertTrue(entered.wait(5))
            running_duplicate = self.engine.enqueue(self.record["id"], "pipeline")
            self.assertEqual(running_duplicate["id"], job["id"])
            self.assertEqual(running_duplicate["state"], "running")
        finally:
            release.set()
        self.assertEqual(self.wait_terminal()["state"], "completed")
        self.assertEqual((self.asr.call_count, self.minutes.call_count), (1, 1))

    def test_user_transcript_edit_during_asr_is_preserved_and_generated_save_rejected(self):
        def edited_during_asr(*args, **kwargs):
            result = self.asr_result(*args, **kwargs)
            self.library.save_text(self.record["id"], "transcript", "用户在转写运行期间的修改")
            return result
        self.asr.side_effect = edited_during_asr
        job = self.run_job()
        self.assertEqual(job["state"], "failed")
        self.assertEqual(job["stage"], "transcribing")
        self.assertEqual(job["errorType"], "ValueError")
        self.minutes.assert_not_called()
        detail = self.library.get_recording(self.record["id"])
        self.assertEqual(detail["transcript"], "用户在转写运行期间的修改")
        self.assertEqual(detail["textStatus"]["transcript"]["source"], "user_or_external_import")
        self.assertEqual(len(detail["textVersions"]["transcript"]), 1)
        self.assertTrue((self.library.root / job["runDirectory"] / "asr" / "segments.json").is_file())

    def test_manual_edits_convert_queued_job_and_keep_only_one_running_successor(self):
        self.library.save_text(self.record["id"], "transcript", "用户第一版转写")
        # Wall-clock timestamps must not be the uniqueness mechanism. Repeated
        # events can share a timestamp, or the system clock can move backwards.
        with patch("auto_pipeline.now", return_value="2026-01-01T00:00:00Z"):
            initial = self.engine.enqueue(self.record["id"], "pipeline")
            converted = self.engine.enqueue(self.record["id"], "minutes", followup=True)
            self.assertEqual(converted["id"], initial["id"])
            self.assertEqual(converted["action"], "minutes")
            self.engine.update(initial["id"], "running", "generating_minutes", "合成的运行中纪要")
            self.library.save_text(self.record["id"], "transcript", "用户第二版转写")
            successor = self.engine.enqueue(self.record["id"], "minutes", followup=True)
            self.assertNotEqual(successor["id"], initial["id"])
            self.library.save_text(self.record["id"], "transcript", "用户第三版转写")
            repeated = self.engine.enqueue(self.record["id"], "minutes", followup=True)
            self.assertEqual(repeated["id"], successor["id"])
            active = self.engine.status()["active"]
            self.assertEqual(len(active), 2)
            self.assertEqual(sum(job["state"] == "queued" for job in active), 1)
            self.engine.update(initial["id"], "failed", "generating_minutes", "旧输入已变化")
            self.engine.execute(repeated)
        with self.engine.db() as db:
            completed = db.execute("SELECT state FROM jobs WHERE id=?", (successor["id"],)).fetchone()[0]
        self.assertEqual(completed, "completed")
        self.asr.assert_not_called()
        self.minutes.assert_called_once()
        self.assertEqual(self.minutes.call_args.args[0], "用户第三版转写")
        detail = self.library.get_recording(self.record["id"])
        self.assertEqual(detail["textStatus"]["minutes"]["metadata"]["transcriptVersion"], 3)

    def test_duplicate_launcher_initialization_does_not_interrupt_running_job(self):
        entered, release = threading.Event(), threading.Event()
        self.addCleanup(release.set)
        def blocked_asr(*args, **kwargs):
            entered.set()
            if not release.wait(5):
                raise AssertionError("Synthetic ASR was not released")
            return self.asr_result(*args, **kwargs)
        self.asr.side_effect = blocked_asr
        job = self.engine.enqueue(self.record["id"])
        self.engine.start()
        try:
            self.assertTrue(entered.wait(5))
            duplicate_launcher = self.new_engine()
            same = self.latest(duplicate_launcher)
            self.assertEqual(same["id"], job["id"])
            self.assertEqual(same["state"], "running")
            self.assertIsNone(duplicate_launcher.thread)
        finally:
            release.set()
        self.assertEqual(self.wait_terminal()["state"], "completed")
        self.assertEqual(self.asr.call_count, 1)

    def test_restart_marks_running_interrupted_without_repeating_expensive_calls(self):
        job = self.engine.enqueue(self.record["id"])
        self.engine.update(job["id"], "running", "transcribing", "合成的前次运行")
        restarted = self.new_engine()
        self.assertEqual(self.latest(restarted)["state"], "running")
        restarted.start()
        self.close_engine(restarted)
        current = self.latest(restarted)
        self.assertEqual(current["id"], job["id"])
        self.assertEqual(current["state"], "interrupted")
        self.assertEqual(current["stage"], "interrupted")
        self.asr.assert_not_called()
        self.minutes.assert_not_called()
        self.assertEqual(self.library.get_recording(self.record["id"])["textVersions"]["transcript"], [])


if __name__ == "__main__":
    unittest.main()
