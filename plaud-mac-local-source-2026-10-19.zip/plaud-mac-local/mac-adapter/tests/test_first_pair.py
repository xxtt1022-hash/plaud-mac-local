from __future__ import annotations

from contextlib import redirect_stderr, redirect_stdout
from io import StringIO
import asyncio
import base64
import copy
import json
from pathlib import Path
import stat
import struct
import sys
import tempfile
import types
import unittest
from unittest.mock import AsyncMock, patch

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305

ROOT = Path(__file__).resolve().parents[1]
UPSTREAM = ROOT.parent / "plaud-direct-pc-research"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(UPSTREAM / "pc-bridge" / "src"))
import first_pair
from plaud_pc import protocol


class FakeGatt:
    """Synthetic GATT only. No Bleak import or hardware/Keychain/API operation."""
    def __init__(self, first_responses=(), public_responses=(), *, status=0,
                 response_command=1, bad_handshake_tag=False):
        self.first_responses = list(first_responses)
        self.public_responses = list(public_responses)
        self.status = status
        self.response_command = response_command
        self.bad_handshake_tag = bad_handshake_tag
        self.writes = []
        self.signature_writes = []
        self.public_writes = []
        self.decrypted_commands = []
        self.notifying = False
        self.notify_calls = 0
        self.connected = False
        self.disconnect_calls = 0
        self.device_session = protocol.SessionCrypto(b"k" * 32, b"n" * 12, b"a" * 12)

    async def connect(self):
        self.connected = True

    async def disconnect(self):
        self.connected = False
        self.disconnect_calls += 1

    async def start_notify(self, uuid, callback):
        assert uuid == first_pair.NOTIFY_UUID
        self.callback = callback
        self.notifying = True
        self.notify_calls += 1

    def emit(self, packets):
        for packet in packets:
            self.callback(None, packet)

    async def write_gatt_char(self, uuid, value, response):
        assert uuid == first_pair.WRITE_UUID and response is True
        packet = bytes(value)
        self.writes.append(packet)
        if len(self.signature_writes) < 3:
            assert struct.unpack_from("<H", packet)[0] == 65040
            self.signature_writes.append(packet)
            if len(self.signature_writes) == 3:
                self.emit(self.first_responses)
            return
        command = struct.unpack_from("<H", packet)[0]
        if command == 65042:
            self.public_writes.append(packet)
            if packet[3] == packet[2] - 1:
                self.emit(self.public_responses)
            return
        _, command, payload = self.device_session.decrypt_command(packet)
        self.decrypted_commands.append((command, payload))
        reply = self.device_session.encrypt_command(self.response_command, bytes([self.status, 20]))
        if self.bad_handshake_tag:
            reply = reply[:-1] + bytes([reply[-1] ^ 1])
        self.emit([reply])

    async def stop_notify(self, uuid):
        assert uuid == first_pair.NOTIFY_UUID
        self.notifying = False


class FirstPairTest(unittest.IsolatedAsyncioTestCase):
    @classmethod
    def setUpClass(cls):
        cls.private = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        cls.other_private = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        cls.material = {
            "version": 1, "verification": "candidate", "sn": "8811A2B3C4D5E6F7",
            "signature": base64.b64encode(b"s" * 256).decode(), "bindToken": "a" * 32,
            "rsaPublicKey": cls.private.public_key().public_bytes(serialization.Encoding.PEM,
                serialization.PublicFormat.SubjectPublicKeyInfo).decode(),
            "rsaPrivateKey": cls.private.private_bytes(serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8, serialization.NoEncryption()).decode()}

    def challenge(self, *, public=None, plaintext=b"PLAUD.AI", bad_tag=False):
        wrapped = ChaCha20Poly1305(b"k" * 32).encrypt(b"n" * 12, plaintext, b"a" * 12)
        if bad_tag:
            wrapped = wrapped[:-1] + bytes([wrapped[-1] ^ 1])
        secret = b"k" * 32 + b"n" * 12 + b"a" * 12 + wrapped
        ciphertext = (public or self.private.public_key()).encrypt(secret, padding.PKCS1v15())
        return protocol.pre_handshake_chunks(65042, ciphertext)

    async def run_pair(self, client, *, enroll=False, material=None, seconds=.08):
        before = copy.deepcopy(self.material if material is None else material)
        result = await first_pair.first_pair(client, before, enroll_if_requested=enroll,
                                             response_seconds=seconds, total_seconds=3)
        self.assertEqual(before, self.material if material is None else material)
        self.assertFalse(client.notifying)
        self.assertFalse(result["keyClearSent"])
        self.assertFalse(result["recordingCommandsSent"])
        self.assertFalse(result["confirmedOwnerStoreWritten"])
        self.assertFalse(result["cloudBindAttempted"])
        # Inspect protocol plaintext in the mock, not random encrypted packet prefixes.
        self.assertTrue(all(command == 1 for command, _ in client.decrypted_commands))
        for packet in client.signature_writes:
            self.assertEqual(struct.unpack_from("<H", packet)[0], 65040)
        for packet in client.public_writes:
            self.assertEqual(struct.unpack_from("<H", packet)[0], 65042)
        safe = json.dumps(result)
        for secret in (self.material["sn"], self.material["signature"],
                       self.material["rsaPrivateKey"], self.material["rsaPublicKey"],
                       self.material["bindToken"], "PRIVATE_EXCEPTION_MARKER"):
            self.assertNotIn(secret, safe)
        return result

    async def test_default_supported_request_is_observation_only(self):
        client = FakeGatt([struct.pack("<HB", 65041, 0)])
        result = await self.run_pair(client)
        self.assertEqual(len(client.writes), 3)
        self.assertEqual(result["outcome"], "enrollment_request_observed_only")
        self.assertTrue(result["supportedEnrollmentRequest"])
        self.assertEqual(result["confirmationByte"], 0)
        self.assertFalse(result["clientPublicKeySent"])
        self.assertFalse(result["ownerHandshakeSent"])
        self.assertFalse(result["ownerHandshakeWriteAttempted"])
        self.assertFalse(result["handshakeAccepted"])
        self.assertNotIn("signatureAccepted", result)

    async def test_explicit_enrollment_uses_same_public_key_and_authenticated_cmd1(self):
        client = FakeGatt([struct.pack("<HB", 65041, 0)], self.challenge())
        result = await self.run_pair(client, enroll=True)
        self.assertTrue(result["clientPublicKeySent"])
        self.assertTrue(result["challengeVerified"])
        self.assertTrue(result["handshakeAccepted"])
        self.assertTrue(result["ownerHandshakeWriteAttempted"])
        self.assertEqual(result["handshakeStatus"], 0)
        self.assertEqual(result["portVersion"], 20)
        self.assertEqual(result["outcome"], "handshake_accepted")
        self.assertEqual(protocol.assemble_pre_handshake(client.public_writes, 65042),
                         self.material["rsaPublicKey"].encode("ascii"))
        self.assertEqual(client.decrypted_commands, [(1, b"\x02\x01\x00" + b"a" * 32)])

    async def test_direct_existing_key_response_never_reenrolls_and_flag_is_required_for_cmd1(self):
        for enroll in (False, True):
            client = FakeGatt(self.challenge())
            result = await self.run_pair(client, enroll=enroll)
            self.assertTrue(result["challengeVerified"])
            self.assertFalse(result["supportedEnrollmentRequest"])
            self.assertEqual(client.public_writes, [])
            self.assertIs(result["ownerHandshakeSent"], enroll)
            self.assertIs(result["handshakeAccepted"], enroll)

    async def test_unsupported_or_malformed_ack_cannot_register_even_with_flag(self):
        for packet in (struct.pack("<HB", 65041, 1), struct.pack("<HB", 65041, 255),
                       struct.pack("<H", 65041), struct.pack("<HB", 65041, 0) + b"\x00"):
            client = FakeGatt([packet], self.challenge())
            result = await self.run_pair(client, enroll=True)
            self.assertEqual(result["errorType"], "UnsupportedEnrollmentRequest")
            self.assertEqual(len(client.writes), 3)
            self.assertFalse(result["supportedEnrollmentRequest"])
            self.assertFalse(result["ownerHandshakeSent"])

    async def test_wrong_rsa_key_bad_tag_and_wrong_challenge_never_send_cmd1_or_fallback(self):
        for frames in (self.challenge(public=self.other_private.public_key()),
                       self.challenge(bad_tag=True), self.challenge(plaintext=b"NOTPLAUD")):
            client = FakeGatt(frames)
            result = await self.run_pair(client, enroll=True)
            self.assertEqual(result["outcome"], "stopped")
            self.assertIn("errorType", result)
            self.assertFalse(result["challengeVerified"])
            self.assertEqual(len(client.writes), 3)
            self.assertEqual(client.public_writes, [])
            self.assertFalse(result["ownerHandshakeSent"])

    async def test_bad_rsa_headers_sizes_conflicting_duplicate_and_missing_chunk_stop(self):
        frames = self.challenge()
        conflict = frames[0][:-1] + bytes([frames[0][-1] ^ 1])
        sets = [[struct.pack("<HBB", 65042, 0, 0)],
                [struct.pack("<HBB", 65042, 4, 0) + b"x" * 100],
                [struct.pack("<HBB", 65042, 3, 3) + b"x" * 56],
                [frames[0][:-1]], [frames[0] + b"x"],
                [frames[0], conflict, *frames[1:]],
                [frames[0], struct.pack("<HBB", 65042, 2, 1) + b"x" * 100], frames[:2]]
        for packets in sets:
            client = FakeGatt(packets)
            result = await self.run_pair(client, enroll=True, seconds=.02)
            self.assertEqual(result["outcome"], "stopped")
            self.assertFalse(result["challengeVerified"])
            self.assertFalse(result["ownerHandshakeSent"])
            self.assertEqual(len(client.writes), 3)

    async def test_identical_duplicates_and_reordering_are_bounded_and_valid(self):
        a, b, c = self.challenge()
        client = FakeGatt([b, b, a, c])
        result = await self.run_pair(client, enroll=True)
        self.assertTrue(result["handshakeAccepted"])
        self.assertEqual(len(result["responses"]), 4)

    async def test_rejected_wrong_command_or_tampered_owner_response_never_continues(self):
        for options in ({"status": 1}, {"response_command": 9}, {"bad_handshake_tag": True}):
            client = FakeGatt(self.challenge(), **options)
            result = await self.run_pair(client, enroll=True)
            self.assertTrue(result["challengeVerified"])
            self.assertTrue(result["ownerHandshakeSent"])
            self.assertFalse(result["handshakeAccepted"])
            self.assertEqual(result["outcome"], "stopped")
            self.assertEqual(len(client.decrypted_commands), 1)
            self.assertEqual(len(client.writes), 4)
        self.assertEqual((await self.run_pair(FakeGatt(self.challenge(), status=1), enroll=True))["handshakeStatus"], 1)

    async def test_timeouts_overflow_and_unknown_response_are_terminal(self):
        for packets in ([], [struct.pack("<H", 9)], [self.challenge()[0]] * 65, [b"\x00"]):
            client = FakeGatt(packets)
            result = await self.run_pair(client, enroll=True, seconds=.01)
            self.assertEqual(result["outcome"], "stopped")
            self.assertFalse(result["clientPublicKeySent"])
            self.assertFalse(result["ownerHandshakeSent"])
            self.assertLessEqual(len(client.writes), 3)

    async def test_signature_public_and_handshake_helpers_cannot_emit_other_commands(self):
        client = FakeGatt()
        with patch.object(protocol, "signature_chunks", return_value=[struct.pack("<HBB", 65056, 1, 0)]):
            result = await self.run_pair(client, enroll=True)
        self.assertEqual(client.writes, [])
        self.assertEqual(client.notify_calls, 0)
        self.assertEqual(result["errorType"], "InvalidFrame")
        client = FakeGatt([struct.pack("<HB", 65041, 0)])
        with patch.object(protocol, "rsa_public_key_chunks", return_value=[struct.pack("<HBB", 65056, 1, 0)]):
            await self.run_pair(client, enroll=True)
        self.assertEqual(len(client.writes), 3)
        client = FakeGatt(self.challenge())
        with patch.object(protocol, "build_handshake_frame", return_value=struct.pack("<BH", 1, 26)):
            result = await self.run_pair(client, enroll=True)
        self.assertEqual(result["errorType"], "InvalidFrame")
        self.assertFalse(result["ownerHandshakeSent"])
        self.assertEqual(len(client.writes), 3)

    async def test_profile_pin_invalid_candidate_and_nonboolean_permission_stop_before_io(self):
        variants = [{**self.material, "verification": "confirmed"},
                    {**self.material, "bindToken": "a" * 33},
                    {**self.material, "sn": "881INCOMPLETE"}]
        for material in variants:
            client = FakeGatt()
            result = await self.run_pair(client, material=material, enroll=True)
            self.assertEqual(client.notify_calls, 0)
            self.assertEqual(client.writes, [])
            self.assertFalse(result["handshakeAccepted"])
        for enroll in (1, "yes"):
            client = FakeGatt()
            result = await first_pair.first_pair(client, self.material, enroll_if_requested=enroll)
            self.assertEqual(client.writes, [])
            self.assertEqual(client.notify_calls, 0)
        with patch.object(first_pair, "PINNED_PROTOCOL_SHA256", "0" * 64):
            client = FakeGatt()
            result = await self.run_pair(client, enroll=True)
            self.assertEqual(client.notify_calls, 0)

    async def test_exception_text_is_never_reported_and_notify_cleanup_occurs(self):
        client = FakeGatt()
        client.write_gatt_char = AsyncMock(side_effect=ValueError("PRIVATE_EXCEPTION_MARKER"))
        result = await self.run_pair(client, enroll=True)
        self.assertEqual(result["errorType"], "ValueError")

    async def test_cmd1_write_ack_failure_preserves_attempt_evidence_without_success_claim(self):
        client = FakeGatt(self.challenge())
        original_write = client.write_gatt_char
        async def delivered_but_write_failed(uuid, packet, response):
            await original_write(uuid, packet, response)
            if client.decrypted_commands:
                raise TimeoutError("PRIVATE_EXCEPTION_MARKER")
        client.write_gatt_char = delivered_but_write_failed
        result = await self.run_pair(client, enroll=True)
        self.assertTrue(result["ownerHandshakeWriteAttempted"])
        self.assertFalse(result["ownerHandshakeSent"])
        self.assertFalse(result["handshakeAccepted"])
        self.assertEqual(result["errorType"], "TimeoutError")
        self.assertEqual(len(client.decrypted_commands), 1)

    async def test_scan_uses_exact_advertisement_and_one_normal_disconnect(self):
        client = FakeGatt(self.challenge())
        packed = b"\x02\x71\x03\x04V\x07\x04\x01\x08" + bytes.fromhex(self.material["sn"]) + b"\x44\x14\x00" + bytes(7)
        right = types.SimpleNamespace(manufacturer_data={93: packed}, local_name="Plaud Note Pro")
        wrong = types.SimpleNamespace(manufacturer_data={}, local_name="Plaud Note Pro")
        async def find(match, timeout):
            self.assertFalse(match(None, wrong))
            self.assertTrue(match(None, right))
            return object()
        bleak = types.SimpleNamespace(BleakScanner=types.SimpleNamespace(find_device_by_filter=find),
                                      BleakClient=lambda *_args, **_kwargs: client)
        with patch.dict(sys.modules, {"bleak": bleak}):
            result = await first_pair.pair_candidate(self.material["sn"], self.material,
                                                      enroll_if_requested=True, response_seconds=.08)
        self.assertTrue(result["handshakeAccepted"])
        self.assertTrue(result["found"])
        self.assertTrue(result["disconnectedAfterCheck"])
        self.assertEqual(client.disconnect_calls, 1)
        self.assertFalse(client.connected)

    async def test_scan_not_found_or_wrong_expected_serial_does_not_connect(self):
        constructor = unittest.mock.Mock(side_effect=AssertionError("No connection"))
        bleak = types.SimpleNamespace(BleakScanner=types.SimpleNamespace(find_device_by_filter=AsyncMock(return_value=None)),
                                      BleakClient=constructor)
        with patch.dict(sys.modules, {"bleak": bleak}):
            result = await first_pair.pair_candidate(self.material["sn"], self.material)
            self.assertEqual(result["outcome"], "target_not_found")
            result = await first_pair.pair_candidate("8811A2B3C4D5E6F8", self.material)
            self.assertEqual(result["outcome"], "stopped")
        constructor.assert_not_called()


class ReportAndCliTest(unittest.TestCase):
    def test_report_is_exclusive_private_and_never_overwrites_candidate(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "report.json"
            report = first_pair._new_report(False)
            first_pair.write_report(path, report)
            self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)
            self.assertEqual(json.loads(path.read_text()), report)
            before = path.read_bytes()
            with self.assertRaises(FileExistsError):
                first_pair.write_report(path, {})
            self.assertEqual(path.read_bytes(), before)
            link = Path(temporary) / "candidate-link.json"
            link.symlink_to(path)
            with self.assertRaises(FileExistsError):
                first_pair.write_report(link, {})
            self.assertEqual(path.read_bytes(), before)

    def test_cli_is_observe_only_and_loads_existing_package_without_modifying_it(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            package = root / "candidate.json"
            package.write_bytes(b"SYNTHETIC_ENCRYPTED_CANDIDATE")
            before = package.read_bytes()
            result = first_pair._new_report(False)
            result["outcome"] = "enrollment_request_observed_only"
            argv = ["first_pair.py", "--candidate-package", str(package), "--state-dir", str(root),
                    "--upstream", str(UPSTREAM), "--sn", "8811A2B3C4D5E6F7",
                    "--report", str(root / "report.json")]
            out, err = StringIO(), StringIO()
            with patch.object(sys, "argv", argv), \
                    patch.object(first_pair, "load_candidate_in_memory", return_value={"sentinel": True}) as load, \
                    patch.object(first_pair, "pair_candidate", new=AsyncMock(return_value=result)) as pair, \
                    redirect_stdout(out), redirect_stderr(err):
                first_pair.main()
            load.assert_called_once_with(package, root, "8811A2B3C4D5E6F7")
            self.assertIs(pair.call_args.kwargs["enroll_if_requested"], False)
            self.assertEqual(package.read_bytes(), before)
            self.assertEqual(json.loads(out.getvalue()), result)
            self.assertEqual(err.getvalue(), "")

    def test_cli_existing_report_blocks_before_load_and_loader_errors_are_type_only(self):
        with tempfile.TemporaryDirectory() as temporary:
            report = Path(temporary) / "report.json"
            report.write_text("KEEP")
            argv = ["first_pair.py", "--candidate-package", str(report), "--state-dir", temporary,
                    "--upstream", str(UPSTREAM), "--sn", "8811A2B3C4D5E6F7", "--report", str(report)]
            with patch.object(sys, "argv", argv), patch.object(first_pair, "load_candidate_in_memory") as load, \
                    redirect_stderr(StringIO()), self.assertRaises(SystemExit):
                first_pair.main()
            load.assert_not_called()
            self.assertEqual(report.read_text(), "KEEP")
            report.unlink()
            out, err = StringIO(), StringIO()
            with patch.object(sys, "argv", argv), \
                    patch.object(first_pair, "load_candidate_in_memory", side_effect=ValueError("PRIVATE_EXCEPTION_MARKER")), \
                    redirect_stdout(out), redirect_stderr(err), self.assertRaises(SystemExit):
                first_pair.main()
            self.assertNotIn("PRIVATE_EXCEPTION_MARKER", out.getvalue() + err.getvalue())
            self.assertIn("ValueError", err.getvalue())
            self.assertFalse(report.exists())


if __name__ == "__main__":
    unittest.main()
