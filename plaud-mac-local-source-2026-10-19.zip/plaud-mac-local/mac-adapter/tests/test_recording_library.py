from __future__ import annotations

from datetime import datetime, timedelta, timezone
import copy
import hashlib
import json
from pathlib import Path
import sqlite3
import stat
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from recording_library import Library


class RecordingLibraryTest(unittest.TestCase):
    """Synthetic files only; no recording, decoder, BLE, API, or Keychain use."""

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.base = Path(self.temporary.name)
        self.root = self.base / "library"
        self.inputs = self.base / "synthetic-inputs"
        self.inputs.mkdir(mode=0o700)
        self.payloads = {
            "raw": b"SYNTHETIC_ENCRYPTED_CONTAINER\x00\x01",
            "audio": b"OggS_SYNTHETIC_SELECTED_AUDIO\x00\x02",
            "wav": b"RIFF_SYNTHETIC_PLAYBACK_WAVE\x00\x03",
        }
        self.files = {}
        for role, data in self.payloads.items():
            path = self.inputs / f"{role}.synthetic"
            path.write_bytes(data)
            self.files[role] = path
        self.sn = "881TEST000000001"
        self.session = 1_234_567_890
        self.snapshot_base = datetime.now(timezone.utc) - timedelta(minutes=10)
        self.library = Library(self.root)

    def imported(self, roles=("raw", "audio", "wav"), **kwargs):
        options = {"title": "合成录音", "duration_seconds": 23.4,
                   "decode_verified": False, "playback_confirmed": False,
                   "source": "synthetic_test"}
        options.update(kwargs)
        return self.library.import_recording(
            self.sn, self.session, {role: self.files[role] for role in roles}, **options)

    def artifact_path(self, record, role):
        return self.root / record["artifacts"][role]["relativePath"]

    def update(self, record, **kwargs):
        options = {"title": record["title"], "tags": record["tags"],
                   "project": record["project"], "notes": record["notes"]}
        options.update(kwargs)
        return self.library.update_recording(record["id"], **options)

    def assert_safe_error(self, function, *forbidden):
        with self.assertRaises(ValueError) as error:
            function()
        rendered = str(error.exception)
        for value in (str(self.base), "PRIVATE_ERROR_MARKER", *forbidden):
            self.assertNotIn(str(value), rendered)
        return error.exception

    def assert_current_utc(self, value):
        self.assertIsInstance(value, str)
        instant = datetime.fromisoformat(value.replace("Z", "+00:00"))
        self.assertIsNotNone(instant.tzinfo)
        self.assertEqual(instant.utcoffset(), timedelta(0))
        self.assertLess(abs(datetime.now(timezone.utc) - instant), timedelta(minutes=1))
        self.assertNotEqual(instant.year, datetime.fromtimestamp(self.session, timezone.utc).year)

    @staticmethod
    def stable(value):
        if isinstance(value, dict):
            return {key: RecordingLibraryTest.stable(item) for key, item in value.items() if key != "validatedAt"}
        if isinstance(value, list):
            return [RecordingLibraryTest.stable(item) for item in value]
        return value

    def observed(self, minute=0):
        return (self.snapshot_base + timedelta(minutes=minute)).isoformat(timespec="seconds").replace("+00:00", "Z")

    def snapshot(self, *, size=None, session=None, observed_at=None):
        observed_at = self.observed() if observed_at is None else observed_at
        return {"observedAt": observed_at, "batteryPercent": 77,
                "freeBytes": 1_000_000, "totalBytes": 2_000_000,
                "recordingCount": 1,
                "files": [{"sessionId": self.session if session is None else session,
                           "size": len(self.payloads["raw"]) if size is None else size}]}

    def test_private_layout_copies_fixed_artifacts_and_records_real_import_times(self):
        before = {role: path.read_bytes() for role, path in self.files.items()}
        record = self.imported()
        self.assertEqual((record["sn"], record["sessionId"]), (self.sn, self.session))
        self.assertRegex(record["id"], r"^[A-Za-z0-9_-]+$")
        self.assertEqual(stat.S_IMODE(self.root.stat().st_mode), 0o700)
        self.assertEqual(stat.S_IMODE((self.root / "records").stat().st_mode), 0o700)
        self.assertEqual(stat.S_IMODE((self.root / "records" / record["id"]).stat().st_mode), 0o700)
        self.assertEqual(stat.S_IMODE((self.root / "library.sqlite3").stat().st_mode), 0o600)
        for role, filename in (("raw", "original.plaud"), ("audio", "audio.ogg"), ("wav", "playback.wav")):
            artifact = record["artifacts"][role]
            relative = Path(artifact["relativePath"])
            self.assertFalse(relative.is_absolute())
            self.assertEqual(relative.parts, ("records", record["id"], filename))
            output = self.root / relative
            self.assertEqual(output.read_bytes(), before[role])
            self.assertEqual(self.files[role].read_bytes(), before[role])
            self.assertEqual(artifact["bytes"], len(before[role]))
            self.assertEqual(artifact["sha256"], hashlib.sha256(before[role]).hexdigest())
            self.assertTrue(artifact["valid"])
            self.assertEqual(stat.S_IMODE(output.stat().st_mode), 0o600)
            self.assertNotEqual(output.stat().st_ino, self.files[role].stat().st_ino)
        self.assertTrue(record["integrityVerified"])
        self.assertFalse(record["decodeVerified"])
        self.assertFalse(record["playbackConfirmed"])
        for field in ("createdAt", "importedAt", "updatedAt"):
            self.assert_current_utc(record[field])
        reopened = Library(self.root).get_recording(record["id"])
        self.assertEqual(self.stable(reopened["artifacts"]), self.stable(record["artifacts"]))

    def test_same_identity_same_hash_merges_missing_roles_without_resetting_user_metadata(self):
        first = self.imported(("raw",), title="原始标题")
        edited = self.update(first, title="用户标题", tags=["警务", "试验"],
                             project="无人机研究", notes="用户备注不能被导入默认值覆盖")
        raw_before = self.artifact_path(edited, "raw").read_bytes()
        second = self.imported(title="重新导入的默认标题")
        self.assertEqual(second["id"], edited["id"])
        for key in ("title", "tags", "project", "notes", "createdAt", "importedAt"):
            self.assertEqual(second[key], edited[key])
        self.assertEqual(set(second["artifacts"]), {"raw", "audio", "wav"})
        self.assertEqual(self.artifact_path(second, "raw").read_bytes(), raw_before)
        self.assertEqual(len(self.library.list_recordings()), 1)
        third = self.imported()
        self.assertEqual(third["id"], second["id"])
        self.assertEqual(self.stable(third["artifacts"]), self.stable(second["artifacts"]))

    def test_identity_is_unique_by_both_serial_and_session(self):
        first = self.imported(("raw",))
        other_sn = self.library.import_recording("881TEST000000002", self.session,
                                                  {"raw": self.files["raw"]}, title="另一台")
        other_session = self.library.import_recording(self.sn, self.session + 1,
                                                       {"raw": self.files["raw"]}, title="另一条")
        self.assertEqual(len({first["id"], other_sn["id"], other_session["id"]}), 3)
        self.assertEqual(len(self.library.list_recordings()), 3)

    def test_idempotent_import_does_not_reset_existing_verified_flags(self):
        first = self.imported(decode_verified=True, playback_confirmed=True)
        repeated = self.imported()
        self.assertEqual(repeated["id"], first["id"])
        self.assertTrue(repeated["integrityVerified"])
        self.assertTrue(repeated["decodeVerified"])
        self.assertTrue(repeated["playbackConfirmed"])

    def test_conflicting_identity_or_role_never_overwrites_existing_files_or_metadata(self):
        record = self.imported()
        original = {role: self.artifact_path(record, role).read_bytes() for role in self.files}
        self.files["raw"].write_bytes(b"PRIVATE_ERROR_MARKER_DIFFERENT_RAW")
        self.assert_safe_error(lambda: self.imported())
        self.assertEqual(self.stable(self.library.get_recording(record["id"])), self.stable(record))
        self.files["raw"].write_bytes(self.payloads["raw"])
        self.files["audio"].write_bytes(b"PRIVATE_ERROR_MARKER_DIFFERENT_AUDIO")
        self.assert_safe_error(lambda: self.imported())
        self.assertEqual(self.stable(self.library.get_recording(record["id"])), self.stable(record))
        for role, expected in original.items():
            self.assertEqual(self.artifact_path(record, role).read_bytes(), expected)

    def test_failed_missing_role_merge_does_not_leave_half_applied_record(self):
        record = self.imported(("raw",))
        link = self.inputs / "PRIVATE_ERROR_MARKER_link"
        link.symlink_to(self.files["wav"])
        self.assert_safe_error(lambda: self.library.import_recording(
            self.sn, self.session, {"raw": self.files["raw"], "audio": self.files["audio"], "wav": link},
            title="PRIVATE_ERROR_MARKER"))
        self.assertEqual(self.stable(self.library.get_recording(record["id"])), self.stable(record))
        self.assertFalse((self.root / "records" / record["id"] / "audio.ogg").exists())

    def test_source_leaf_and_ancestor_symlinks_are_rejected(self):
        leaf = self.inputs / "source-link"
        leaf.symlink_to(self.files["raw"])
        parent = self.base / "source-directory-link"
        parent.symlink_to(self.inputs, target_is_directory=True)
        for source in (leaf, parent / self.files["raw"].name):
            self.assert_safe_error(lambda source=source: self.library.import_recording(
                self.sn, self.session, {"raw": source}, title="合成"))
        self.assertEqual(self.library.list_recordings(), [])

    def test_root_database_and_records_symlinks_are_rejected(self):
        real = self.base / "other-root"
        real.mkdir(mode=0o700)
        root_link = self.base / "root-link"
        root_link.symlink_to(real, target_is_directory=True)
        self.assert_safe_error(lambda: Library(root_link))
        for name in ("library.sqlite3", "records"):
            candidate = self.base / f"symlink-case-{name}"
            candidate.mkdir(mode=0o700)
            destination = self.base / f"real-{name}"
            if name == "records":
                destination.mkdir(mode=0o700)
                (candidate / name).symlink_to(destination, target_is_directory=True)
            else:
                destination.write_bytes(b"PRIVATE_ERROR_MARKER_KEEP_DATABASE")
                (candidate / name).symlink_to(destination)
            self.assert_safe_error(lambda candidate=candidate: Library(candidate))
            if name == "library.sqlite3":
                self.assertEqual(destination.read_bytes(), b"PRIVATE_ERROR_MARKER_KEEP_DATABASE")

    def test_existing_artifact_and_record_directory_symlinks_are_never_followed(self):
        record = self.imported(("raw",))
        raw = self.artifact_path(record, "raw")
        raw.unlink()
        raw.symlink_to(self.files["raw"])
        self.assert_safe_error(lambda: self.imported(("raw",)))
        self.assertEqual(self.files["raw"].read_bytes(), self.payloads["raw"])
        raw.unlink()
        raw.write_bytes(self.payloads["raw"])
        record_dir = raw.parent
        saved_dir = record_dir.with_name(record_dir.name + "-saved")
        record_dir.rename(saved_dir)
        elsewhere = self.base / "foreign-record"
        elsewhere.mkdir(mode=0o700)
        foreign = elsewhere / "original.plaud"
        foreign.write_bytes(b"PRIVATE_ERROR_MARKER_FOREIGN")
        record_dir.symlink_to(elsewhere, target_is_directory=True)
        self.assert_safe_error(lambda: self.imported(("raw",)))
        self.assertEqual(foreign.read_bytes(), b"PRIVATE_ERROR_MARKER_FOREIGN")

    def test_validate_missing_or_modified_artifact_revokes_flags_persistently(self):
        record = self.imported(decode_verified=True, playback_confirmed=True)
        self.assertTrue(record["decodeVerified"])
        self.assertTrue(record["playbackConfirmed"])
        audio = self.artifact_path(record, "audio")
        audio.write_bytes(b"SYNTHETIC_CHANGED_AUDIO")
        invalid = self.library.validate_recording(record["id"])
        self.assertFalse(invalid["artifacts"]["audio"]["valid"])
        self.assertFalse(invalid["integrityVerified"])
        self.assertFalse(invalid["decodeVerified"])
        self.assertFalse(invalid["playbackConfirmed"])
        audio.write_bytes(self.payloads["audio"])
        restored = Library(self.root).validate_recording(record["id"])
        self.assertTrue(restored["artifacts"]["audio"]["valid"])
        self.assertTrue(restored["integrityVerified"])
        self.assertFalse(restored["decodeVerified"])
        self.assertFalse(restored["playbackConfirmed"])
        self.artifact_path(restored, "raw").unlink()
        missing = self.library.validate_recording(record["id"])
        self.assertFalse(missing["artifacts"]["raw"]["valid"])
        self.assertFalse(missing["integrityVerified"])

    def test_get_recording_does_not_report_stale_verified_flags_for_current_bad_audio(self):
        record = self.imported(decode_verified=True, playback_confirmed=True)
        self.artifact_path(record, "audio").write_bytes(b"SYNTHETIC_BAD_CURRENT_AUDIO")
        current = self.library.get_recording(record["id"])
        self.assertFalse(current["artifacts"]["audio"]["valid"])
        self.assertFalse(current["integrityVerified"])
        self.assertFalse(current["decodeVerified"])
        self.assertFalse(current["playbackConfirmed"])

    def test_playback_confirmation_is_explicit_and_persisted_only_after_valid_decode(self):
        record = self.imported(decode_verified=True, playback_confirmed=False)
        self.assertFalse(record["playbackConfirmed"])
        confirmed = self.library.confirm_playback(record["id"])
        self.assertTrue(confirmed["integrityVerified"])
        self.assertTrue(confirmed["decodeVerified"])
        self.assertTrue(confirmed["playbackConfirmed"])
        self.assertTrue(Library(self.root).get_recording(record["id"])["playbackConfirmed"])

    def test_playback_cannot_be_confirmed_without_decode_or_after_artifact_damage(self):
        record = self.imported()
        self.assert_safe_error(lambda: self.library.confirm_playback(record["id"]))
        self.assertFalse(self.library.get_recording(record["id"])["playbackConfirmed"])
        verified = self.library.import_recording(
            self.sn, self.session + 1, self.files, title="已解码合成记录", decode_verified=True)
        audio = self.artifact_path(verified, "audio")
        audio.write_bytes(b"SYNTHETIC_DAMAGED_BEFORE_CONFIRMATION")
        self.assert_safe_error(lambda: self.library.confirm_playback(verified["id"]))
        # Restore before any detail read: the rejected confirmation must itself persist revocation.
        audio.write_bytes(self.payloads["audio"])
        detail = self.library.get_recording(verified["id"])
        self.assertTrue(detail["integrityVerified"])
        self.assertFalse(detail["decodeVerified"])
        self.assertFalse(detail["playbackConfirmed"])

    def test_external_text_versions_are_private_append_only_persisted_and_searchable(self):
        record = self.imported()
        self.assertEqual(record["transcript"], "")
        self.assertEqual(record["minutes"], "")
        for kind in ("transcript", "minutes"):
            self.assertFalse(record["textStatus"][kind]["present"])
        texts = ("\n 外部导入逐字稿第一版，关于警务无人机。 \n", "\n外部修订逐字稿第二版，关于固定翼。\n")
        for text in texts:
            self.library.save_text(record["id"], "transcript", text)
        minutes = "用户提供会议纪要：检查加密回传。"
        self.library.save_text(record["id"], "minutes", minutes)
        detail = Library(self.root).get_recording(record["id"])
        self.assertEqual(detail["transcript"], texts[-1])
        self.assertEqual(detail["minutes"], minutes)
        for kind, expected in (("transcript", texts), ("minutes", (minutes,))):
            versions = detail["textVersions"][kind]
            self.assertEqual(len(versions), len(expected))
            status = detail["textStatus"][kind]
            self.assertTrue(status["present"])
            self.assertEqual(status["version"], len(expected))
            self.assertEqual(status["source"], "user_or_external_import")
            self.assertFalse(status["automaticAsr"])
            for index, (version, text) in enumerate(zip(versions, expected), 1):
                relative = f"records/{record['id']}/texts/{kind}-v{index:04d}.md"
                self.assertEqual(version["version"], index)
                self.assertEqual(version["relativePath"], relative)
                self.assertEqual((self.root / relative).read_text(), text)
                self.assertEqual(version["bytes"], len(text.encode("utf-8")))
                self.assertEqual(version["sha256"], hashlib.sha256(text.encode("utf-8")).hexdigest())
                self.assertEqual(version["source"], "user_or_external_import")
                self.assertFalse(version["automaticAsr"])
                self.assert_current_utc(version["createdAt"])
                self.assertEqual(stat.S_IMODE((self.root / relative).stat().st_mode), 0o600)
            self.assertEqual(status["relativePath"], versions[-1]["relativePath"])
        self.assertEqual([item["id"] for item in self.library.list_recordings("固定翼")], [record["id"]])
        self.assertEqual([item["id"] for item in self.library.list_recordings("加密回传")], [record["id"]])

    def generated(self, record, kind="transcript", text="合成自动转写", *, previous=0,
                  source=None, metadata=None, input_ref=None):
        if input_ref is None:
            if kind == "transcript":
                input_ref = {"audioRole": "wav", "audioSha256": record["artifacts"]["wav"]["sha256"],
                             "previousTextVersion": previous}
            else:
                transcript = record["textStatus"]["transcript"]
                input_ref = {"transcriptVersion": transcript["version"],
                             "transcriptSha256": transcript["sha256"], "previousTextVersion": previous}
        return self.library.save_generated_text(record["id"], kind, text,
            source=source or ("whisper_cpp" if kind == "transcript" else "codex_cli"),
            metadata={} if metadata is None else metadata, input_ref=input_ref)

    def test_generated_provenance_and_manual_history_round_trip_without_overwriting(self):
        record = self.imported()
        metadata = {"engine": "whisper.cpp", "model": "synthetic-model", "modelSha256": "a" * 64,
                    "language": "auto", "runId": "synthetic-run-1", "needsReview": True,
                    "createdAt": self.observed(), "segmentsRelativePath": "runs/synthetic-run-1/segments.json"}
        before_metadata = copy.deepcopy(metadata)
        transcript = self.generated(record, metadata=metadata)
        self.assertEqual(metadata, before_metadata)
        status = transcript["textStatus"]["transcript"]
        self.assertEqual(status["source"], "whisper_cpp")
        self.assertTrue(status["generated"])
        self.assertTrue(status["automaticAsr"])
        self.assertEqual(status["sha256"], hashlib.sha256("合成自动转写".encode()).hexdigest())
        self.assertEqual(status["metadata"]["inputSha256"], record["artifacts"]["wav"]["sha256"])
        self.assertEqual(status["metadata"]["modelSha256"], "a" * 64)
        minutes = self.generated(transcript, "minutes", "合成自动纪要", metadata={"engine": "codex", "needsReview": True})
        minute_status = minutes["textStatus"]["minutes"]
        self.assertEqual(minute_status["source"], "codex_cli")
        self.assertTrue(minute_status["generated"])
        self.assertFalse(minute_status["automaticAsr"])
        self.assertEqual(minute_status["metadata"]["transcriptVersion"], 1)
        self.assertEqual(minute_status["metadata"]["transcriptSha256"], status["sha256"])
        manual = self.library.save_text(record["id"], "transcript", "用户明确修订")
        self.assertEqual(manual["textStatus"]["transcript"]["source"], "user_or_external_import")
        self.assertFalse(manual["textStatus"]["transcript"]["generated"])
        self.assertFalse(manual["textStatus"]["transcript"]["automaticAsr"])
        self.assertEqual(manual["textStatus"]["transcript"]["metadata"], {})
        reopened = Library(self.root).get_recording(record["id"])
        self.assertEqual([v["source"] for v in reopened["textVersions"]["transcript"]],
                         ["whisper_cpp", "user_or_external_import"])
        first = reopened["textVersions"]["transcript"][0]
        self.assertEqual((self.root / first["relativePath"]).read_text(), "合成自动转写")
        self.assertEqual(reopened["minutes"], "合成自动纪要")
        self.assertEqual(stat.S_IMODE((self.root / first["relativePath"]).stat().st_mode), 0o600)

    def test_legacy_text_schema_migrates_idempotently_without_losing_manual_text(self):
        record = self.imported()
        old = self.library.save_text(record["id"], "transcript", "迁移前的手工文字")
        old_path = self.root / old["textStatus"]["transcript"]["relativePath"]
        columns = "record_id,kind,version,body,relative_path,bytes,sha256,valid,created_at"
        with sqlite3.connect(self.root / "library.sqlite3") as connection:
            connection.executescript("""
                ALTER TABLE text_versions RENAME TO new_text_versions;
                CREATE TABLE text_versions (
                    record_id TEXT NOT NULL REFERENCES recordings(id), kind TEXT NOT NULL,
                    version INTEGER NOT NULL, body TEXT NOT NULL, relative_path TEXT NOT NULL UNIQUE,
                    bytes INTEGER NOT NULL, sha256 TEXT NOT NULL, valid INTEGER NOT NULL,
                    created_at TEXT NOT NULL, PRIMARY KEY(record_id,kind,version));
                """ + f"INSERT INTO text_versions ({columns}) SELECT {columns} FROM new_text_versions;"
                + "DROP TABLE new_text_versions;")
        for _ in range(2):
            self.library = Library(self.root)
            detail = self.library.get_recording(record["id"])
            self.assertEqual(detail["transcript"], "迁移前的手工文字")
            self.assertEqual(old_path.read_text(), "迁移前的手工文字")
            self.assertEqual(detail["textStatus"]["transcript"]["source"], "user_or_external_import")
            self.assertEqual(detail["textStatus"]["transcript"]["metadata"], {})
            self.assertFalse(detail["textStatus"]["transcript"]["generated"])
        generated = self.generated(detail, previous=1)
        self.assertEqual(len(generated["textVersions"]["transcript"]), 2)
        self.assertEqual(generated["textStatus"]["transcript"]["source"], "whisper_cpp")

    def test_generated_transcript_rejects_changed_audio_and_persists_flag_revocation(self):
        record = self.imported(decode_verified=True, playback_confirmed=True)
        wav = self.artifact_path(record, "wav")
        wav.write_bytes(b"SYNTHETIC_CHANGED_DURING_TRANSCRIPTION")
        self.assert_safe_error(lambda: self.generated(record))
        wav.write_bytes(self.payloads["wav"])
        detail = self.library.get_recording(record["id"])
        self.assertTrue(detail["integrityVerified"])
        self.assertFalse(detail["decodeVerified"])
        self.assertFalse(detail["playbackConfirmed"])
        self.assertEqual(detail["textVersions"]["transcript"], [])
        self.assertFalse((self.root / "records" / record["id"] / "texts" / "transcript-v0001.md").exists())

    def test_generated_transcript_rejects_stale_version_and_wrong_audio_reference(self):
        record = self.imported()
        manual = self.library.save_text(record["id"], "transcript", "运行期间用户的手工编辑")
        self.assert_safe_error(lambda: self.generated(record, previous=0))
        for reference in ({"audioRole": "wav", "audioSha256": "0" * 64, "previousTextVersion": 1},
                          {"audioRole": "raw", "audioSha256": record["artifacts"]["raw"]["sha256"], "previousTextVersion": 1},
                          {"audioRole": "audio", "audioSha256": record["artifacts"]["audio"]["sha256"], "previousTextVersion": True}):
            self.assert_safe_error(lambda reference=reference: self.generated(record, input_ref=reference))
        current = self.library.get_recording(record["id"])
        self.assertEqual(current["transcript"], manual["transcript"])
        self.assertEqual(len(current["textVersions"]["transcript"]), 1)
        # Original Ogg may also be selected explicitly, with its own actual SHA.
        updated = self.generated(current, previous=1, input_ref={"audioRole": "audio",
            "audioSha256": current["artifacts"]["audio"]["sha256"], "previousTextVersion": 1})
        self.assertEqual(updated["textStatus"]["transcript"]["version"], 2)

    def test_generated_minutes_rejects_revised_damaged_or_stale_target_text(self):
        record = self.generated(self.imported())
        binding = {"transcriptVersion": 1, "transcriptSha256": record["textStatus"]["transcript"]["sha256"],
                   "previousTextVersion": 0}
        revised = self.library.save_text(record["id"], "transcript", "用户编辑后的最新转写")
        self.assert_safe_error(lambda: self.generated(record, "minutes", input_ref=binding))
        path = self.root / revised["textStatus"]["transcript"]["relativePath"]
        path.write_text("SYNTHETIC_DAMAGED_TRANSCRIPT")
        self.assert_safe_error(lambda: self.generated(revised, "minutes"))
        self.assertEqual(self.library.get_recording(record["id"])["textVersions"]["minutes"], [])
        path.write_text("用户编辑后的最新转写")
        self.library.save_text(record["id"], "minutes", "运行期间用户的纪要编辑")
        self.assert_safe_error(lambda: self.generated(revised, "minutes", previous=0))
        current = self.library.get_recording(record["id"])
        self.assertEqual(current["minutes"], "运行期间用户的纪要编辑")
        accepted = self.generated(current, "minutes", "第二版自动纪要", previous=1)
        self.assertEqual(len(accepted["textVersions"]["minutes"]), 2)

    def test_generated_source_and_finite_metadata_reject_unsupported_values(self):
        record = self.imported()
        for source, kind in (("codex_cli", "transcript"), ("whisper_cpp", "minutes"),
                             ("user_or_external_import", "transcript"), ("PRIVATE_ERROR_MARKER", "transcript")):
            self.assert_safe_error(lambda source=source, kind=kind: self.generated(record, kind, source=source))
        cases = [{"apiKey": "PRIVATE_ERROR_MARKER"}, {"needsReview": 1}, {"engine": float("nan")},
                 {"engine": {"nested": "PRIVATE_ERROR_MARKER"}}, {"modelSha256": "bad-hash"},
                 {"transcriptVersion": 0}, {"createdAt": "2026-10-19T10:00:00"},
                 {"segmentsRelativePath": "../PRIVATE_ERROR_MARKER"},
                 {"segmentsRelativePath": "/PRIVATE_ERROR_MARKER"},
                 {"inputSha256": "0" * 64}]
        for metadata in cases:
            self.assert_safe_error(lambda metadata=metadata: self.generated(record, metadata=metadata))
        self.assertEqual(self.library.get_recording(record["id"])["textVersions"]["transcript"], [])

    def test_text_destination_conflict_never_overwrites_or_adds_a_version(self):
        record = self.imported()
        texts = self.root / "records" / record["id"] / "texts"
        texts.mkdir(mode=0o700, exist_ok=True)
        existing = texts / "transcript-v0001.md"
        existing.write_text("PRIVATE_ERROR_MARKER_EXISTING_VERSION")
        self.assert_safe_error(lambda: self.library.save_text(record["id"], "transcript", "新版本"))
        self.assertEqual(existing.read_text(), "PRIVATE_ERROR_MARKER_EXISTING_VERSION")
        detail = self.library.get_recording(record["id"])
        self.assertEqual(detail["textVersions"]["transcript"], [])
        self.assertFalse(detail["textStatus"]["transcript"]["present"])

    def test_failed_mutation_cannot_rollback_prior_integrity_revocation(self):
        for offset, operation in enumerate(("save_text", "import_recording")):
            with self.subTest(operation=operation):
                record = self.library.import_recording(self.sn, self.session + offset, self.files,
                    title="合成验收", decode_verified=True, playback_confirmed=True)
                audio = self.artifact_path(record, "audio")
                audio.write_bytes(b"SYNTHETIC_DAMAGED_BEFORE_MUTATION")
                if operation == "save_text":
                    folder = self.root / "records" / record["id"] / "texts"
                    folder.mkdir(mode=0o700)
                    (folder / "transcript-v0001.md").write_text("SYNTHETIC_VERSION_CONFLICT")
                    action = lambda: self.library.save_text(record["id"], "transcript", "新文本")
                else:
                    action = lambda: self.library.import_recording(self.sn, self.session + offset,
                        self.files, title="重复导入")
                self.assert_safe_error(action)
                # Restore before a detail read; the failed mutation must not resurrect old acceptance.
                audio.write_bytes(self.payloads["audio"])
                detail = self.library.get_recording(record["id"])
                self.assertTrue(detail["integrityVerified"])
                self.assertFalse(detail["decodeVerified"])
                self.assertFalse(detail["playbackConfirmed"])

    def test_chinese_metadata_queries_and_parameterized_input_preserve_database(self):
        record = self.imported(title="海上巡检")
        record = self.update(record, tags=["中文标签", "低空"], project="港口项目", notes="维护备注与天气")
        for query in ("海上", "中文标签", "港口项目", "维护备注"):
            self.assertEqual([value["id"] for value in self.library.list_recordings(query)], [record["id"]])
        self.library.list_recordings("' OR 1=1; DROP TABLE recordings; --")
        self.assertEqual(self.library.get_recording(record["id"])["title"], "海上巡检")

    def test_snapshots_are_copied_historical_persisted_and_latest_not_device_access(self):
        self.assertIsNone(self.library.latest_device_snapshot())
        first = self.snapshot()
        first.update(ok=True, transport={"connected": True, "disconnectedAfterCheck": True})
        before = copy.deepcopy(first)
        self.library.record_device_snapshot(self.sn, first)
        self.assertEqual(first, before)
        second = self.snapshot(size=99, observed_at=self.observed(1))
        self.library.record_device_snapshot(self.sn, second)
        latest = Library(self.root).latest_device_snapshot()
        self.assertEqual(latest["sn"], self.sn)
        self.assertEqual(latest["observedAt"], second["observedAt"])
        self.assertEqual(latest["files"], second["files"])
        self.assertTrue(latest["historical"])
        self.assertNotIn("ok", latest)
        self.assertNotIn("transport", latest)

    def test_cleanup_remains_blocked_with_all_local_prerequisites_and_rechecks_current_hashes(self):
        record = self.imported(decode_verified=True, playback_confirmed=True)
        self.library.record_device_snapshot(self.sn, self.snapshot())
        state = self.library.cleanup_state(record)
        self.assertTrue(state["blocked"])
        self.assertIn("independent_backup_not_configured", state["reasons"])
        self.assertIsInstance(state["reasonDetails"], dict)
        for key in ("deviceSnapshotHistorical", "deviceRecordMatched", "rawValid", "audioValid",
                    "decodeVerified", "playbackConfirmed"):
            self.assertIs(state["reasonDetails"][key], True)
        self.assertFalse(state["reasonDetails"]["independentBackupConfigured"])
        self.artifact_path(record, "raw").write_bytes(b"SYNTHETIC_CHANGED_RAW")
        forged = copy.deepcopy(record)
        forged.update(integrityVerified=True, decodeVerified=True, playbackConfirmed=True)
        blocked = self.library.cleanup_state(forged)
        self.assertTrue(blocked["blocked"])
        self.assertIn("independent_backup_not_configured", blocked["reasons"])
        self.assertIn("raw_not_valid", blocked["reasons"])
        self.assertFalse(blocked["reasonDetails"]["rawValid"])
        self.assertFalse(blocked["reasonDetails"]["decodeVerified"])
        self.assertFalse(blocked["reasonDetails"]["playbackConfirmed"])

    def test_cleanup_snapshot_checks_serial_session_and_raw_size(self):
        record = self.imported(decode_verified=True, playback_confirmed=True)
        cases = [self.snapshot(session=self.session + 1),
                 self.snapshot(size=len(self.payloads["raw"]) + 1)]
        for index, snapshot in enumerate(cases):
            snapshot["observedAt"] = self.observed(index)
            self.library.record_device_snapshot(self.sn, snapshot)
            state = self.library.cleanup_state(record)
            self.assertTrue(state["blocked"])
            self.assertIn("independent_backup_not_configured", state["reasons"])
            self.assertIn("device_record_not_matched", state["reasons"])
            self.assertFalse(state["reasonDetails"]["deviceRecordMatched"])
        matching = self.snapshot(observed_at=self.observed(2))
        self.library.record_device_snapshot(self.sn, matching)
        self.library.record_device_snapshot("881TEST000000002", self.snapshot(
            size=999, observed_at=self.observed(3)))
        state = self.library.cleanup_state(record)
        self.assertTrue(state["reasonDetails"]["deviceRecordMatched"])
        self.assertEqual(state["reasonDetails"]["deviceSnapshotObservedAt"], matching["observedAt"])
        without_snapshot = self.library.import_recording("881TEST000000003", self.session,
                                                         self.files, title="没有该设备快照")
        missing = self.library.cleanup_state(without_snapshot)
        self.assertIn("device_snapshot_missing", missing["reasons"])
        self.assertFalse(missing["reasonDetails"]["deviceRecordMatched"])

    def test_invalid_inputs_have_safe_value_errors_and_no_partial_import(self):
        calls = [
            lambda: self.library.import_recording("../PRIVATE_ERROR_MARKER", self.session,
                                                   {"raw": self.files["raw"]}, title="x"),
            lambda: self.library.import_recording(self.sn, True, {"raw": self.files["raw"]}, title="x"),
            lambda: self.library.import_recording(self.sn, -1, {"raw": self.files["raw"]}, title="x"),
            lambda: self.imported(duration_seconds=float("nan")),
            lambda: self.imported(duration_seconds=float("inf")),
            lambda: self.library.import_recording(self.sn, self.session,
                                                   {"PRIVATE_ERROR_MARKER": self.files["raw"]}, title="x"),
            lambda: self.library.import_recording(self.sn, self.session,
                                                   {"raw": self.inputs / "PRIVATE_ERROR_MARKER_missing"}, title="x"),
        ]
        for call in calls:
            self.assert_safe_error(call)
            self.assertEqual(self.library.list_recordings(), [])
        record = self.imported()
        for call in (
            lambda: self.library.get_recording("../PRIVATE_ERROR_MARKER"),
            lambda: self.library.validate_recording("PRIVATE_ERROR_MARKER_missing"),
            lambda: self.library.save_text(record["id"], "PRIVATE_ERROR_MARKER_kind", "text"),
            lambda: self.library.save_text(record["id"], "transcript", "   \n"),
            lambda: self.update(record, tags="PRIVATE_ERROR_MARKER_not_a_list"),
            lambda: self.library.record_device_snapshot(self.sn, {**self.snapshot(), "observedAt": "PRIVATE_ERROR_MARKER"}),
        ):
            self.assert_safe_error(call)


if __name__ == "__main__":
    unittest.main()
