from __future__ import annotations

import asyncio
import base64
import json
from pathlib import Path
import stat
import struct
import sys
import tempfile
import types
import unittest
from unittest.mock import AsyncMock

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

MODULE = Path(__file__).resolve().parents[1] / "mac_adapter.py"
sys.path.insert(0, str(MODULE.parent))
import mac_adapter as adapter


class AdapterTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.owner = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        cls.material = {"version": 1, "sn": "881TESTONLY", "signature": adapter.b64(b"s" * 256),
                        "bindToken": "a" * 32,
                        "rsaPublicKey": cls.owner.public_key().public_bytes(
                            serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo).decode(),
                        "rsaPrivateKey": cls.owner.private_bytes(
                            serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                            serialization.NoEncryption()).decode()}

    def make_android_envelope(self, public):
        # Independent producer reproduces PcBootstrapExporter.kt's explicit OAEP settings.
        key, nonce = b"k" * 32, b"n" * 12
        return {"version": 1, "keyWrap": "RSA-OAEP-SHA256-MGF1-SHA256", "contentCipher": "AES-256-GCM",
                "wrappedKey": base64.b64encode(public.encrypt(key, padding.OAEP(
                    mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None))).decode(),
                "nonce": base64.b64encode(nonce).decode(), "ciphertext": base64.b64encode(
                    AESGCM(key).encrypt(nonce, json.dumps(self.material).encode(), b"plaud-pc-bootstrap-v1")).decode()}

    def test_android_roundtrip_and_private_file_permissions(self):
        with tempfile.TemporaryDirectory() as folder:
            root, password = Path(folder), "a sufficiently long local passphrase"
            public_file = adapter.initialize_recipient(root, password)
            public = serialization.load_pem_public_key(public_file.read_bytes())
            self.assertEqual(public.key_size, 3072)
            package = root / "package.json"
            package.write_text(json.dumps(self.make_android_envelope(public)))
            adapter.import_android(package, root, password, self.material["sn"])
            actual = adapter.load_identity(root, password, self.material["sn"])
            self.assertEqual(actual, self.material)
            for name in (adapter.RECIPIENT_FILE, adapter.IDENTITY_FILE, adapter.PUBLIC_FILE):
                self.assertEqual(stat.S_IMODE((root / name).stat().st_mode), 0o600)
            self.assertEqual(stat.S_IMODE(root.stat().st_mode), 0o700)
            on_disk = (root / adapter.IDENTITY_FILE).read_text()
            self.assertNotIn("PRIVATE KEY", on_disk)
            self.assertNotIn(self.material["sn"], on_disk)
            with self.assertRaises(InvalidTag):
                adapter.load_identity(root, "incorrect passphrase", self.material["sn"])
            with self.assertRaises(ValueError):
                adapter.initialize_recipient(root, password)

    def test_tamper_and_identity_mismatch_rejected(self):
        password = "a sufficiently long local passphrase"
        sealed = adapter.seal(self.material, password, "device-identity")
        cipher = bytearray(adapter.unb64(sealed["ciphertext"]))
        cipher[-1] ^= 1
        sealed["ciphertext"] = adapter.b64(bytes(cipher))
        with self.assertRaises(InvalidTag):
            adapter.unseal(sealed, password, "device-identity")
        with self.assertRaises(ValueError):
            adapter.validate_identity(self.material, "881OTHERDEVICE")
        broken = dict(self.material, rsaPublicKey=rsa.generate_private_key(
            public_exponent=65537, key_size=2048).public_key().public_bytes(
                serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo).decode())
        with self.assertRaises(ValueError):
            adapter.validate_identity(broken, self.material["sn"])

    def test_kdf_resource_abuse_rejected_before_derivation(self):
        envelope = {"version": 1, "purpose": "device-identity", "cipher": "AES-256-GCM", "kdf": "scrypt",
                    "scrypt": {"n": 2**28, "r": 8, "p": 1, "salt": adapter.b64(b"s" * 16)}}
        with self.assertRaises(ValueError):
            adapter.unseal(envelope, "password", "device-identity")


class UpstreamBoundaryTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        upstream = MODULE.parents[1] / "plaud-direct-pc-research"
        if not upstream.is_dir():
            raise unittest.SkipTest("Sibling upstream source checkout is required")
        adapter.attach_upstream(upstream)

    def test_matches_exact_advertised_serial_only(self):
        # Public parser shape: [version-size=4, type='V', three version bytes, SN length, SN].
        # Size 2 has a special project-code meaning and must not be used as a simple fixture.
        def ad(sn):
            encoded = sn.encode()
            return types.SimpleNamespace(manufacturer_data={123: b"\x04V\x00\x07\x01" + bytes([len(encoded)]) + encoded})
        self.assertTrue(adapter.advertisement_matches(ad("881TESTONLY"), "881TESTONLY"))
        self.assertFalse(adapter.advertisement_matches(ad("881OTHER"), "881TESTONLY"))
        self.assertFalse(adapter.advertisement_matches(types.SimpleNamespace(manufacturer_data={}), "881TESTONLY"))

    def test_stops_when_device_requests_new_identity_enrollment(self):
        from plaud_pc.protocol import CMD_PRE_SIGNATURE_CONFIRM, ProtocolError
        client = adapter.paired_client({"sn": "881TESTONLY", "signature": adapter.b64(b"s" * 256)})
        client._write = AsyncMock()
        client._wait_raw_command = AsyncMock(return_value=struct.pack("<H", CMD_PRE_SIGNATURE_CONFIRM))
        with self.assertRaises(ProtocolError):
            asyncio.run(client.authenticate(object()))
        # Only SN-signature frames were sent; no RSA enrollment or CMD 1 follows the refusal.
        self.assertGreater(client._write.await_count, 0)
        for call in client._write.await_args_list:
            self.assertEqual(struct.unpack_from("<H", call.args[1])[0], 65040)


if __name__ == "__main__":
    unittest.main()
