"""Loopback-only tests with synthetic public keys and deliberately fake ciphertext.

Passing structural checks here must never be reported as cryptographic verification.
The transfer service and these tests use only the Python standard library.
"""
from __future__ import annotations

import base64
import argparse
from contextlib import redirect_stderr
import http.client
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import socket
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import local_transfer as transfer


def tlv(tag: int, data: bytes) -> bytes:
    length = len(data)
    size = bytes([length]) if length < 128 else bytes([0x80 | ((length.bit_length() + 7) // 8)]) + length.to_bytes((length.bit_length() + 7) // 8, "big")
    return bytes([tag]) + size + data


def synthetic_public_pem() -> bytes:
    # A sized, odd integer is sufficient to test this structural DER parser.
    # This is not a mathematically validated RSA key and is not used to encrypt.
    modulus = b"\x00\x80" + b"\x55" * 383
    rsa = tlv(0x30, tlv(0x02, modulus) + tlv(0x02, b"\x01\x00\x01"))
    der = tlv(0x30, transfer.RSA_ALGORITHM + tlv(0x03, b"\x00" + rsa))
    return b"-----BEGIN PUBLIC KEY-----\n" + base64.b64encode(der) + b"\n-----END PUBLIC KEY-----\n"


def envelope() -> dict:
    return {"version": 1, "keyWrap": transfer.KEY_WRAP, "contentCipher": transfer.CONTENT_CIPHER,
            "wrappedKey": base64.b64encode(b"w" * 384).decode("ascii"),
            "nonce": base64.b64encode(b"n" * 12).decode("ascii"),
            "ciphertext": base64.b64encode(b"fake ciphertext and fake GCM tag").decode("ascii")}


class TransferTest(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.directory = Path(self.temporary.name)
        self.apk = self.directory / "selected.apk"
        self.apk.write_bytes(b"synthetic selected APK")
        self.public = self.directory / "public.pem"
        self.public.write_bytes(synthetic_public_pem())
        self.output = self.directory / "encrypted.json"
        self.server = transfer.create_server(self.apk, self.public, self.output, port=0)
        self.thread = threading.Thread(target=self.server.serve_forever,
                                       kwargs={"poll_interval": 0.01}, daemon=True)
        self.thread.start()
        self.session = self.server.session_path

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=2)
        self.temporary.cleanup()

    def request(self, method, path, body=None, headers=None):
        client = http.client.HTTPConnection("127.0.0.1", self.server.server_address[1], timeout=2)
        try:
            client.request(method, path, body=body, headers=headers or {})
            response = client.getresponse()
            return response.status, dict(response.getheaders()), response.read()
        finally:
            client.close()

    def post(self, payload, headers=None):
        return self.request("POST", self.session + "upload", payload,
                            headers or {"Content-Type": "application/json"})

    def test_only_explicit_page_apk_and_public_file_are_served(self):
        code, headers, page = self.request("GET", self.session)
        self.assertEqual(code, 200)
        self.assertIn("本地引导文件", page.decode())
        self.assertIn("frame-ancestors 'none'", headers["Content-Security-Policy"])
        self.assertIn("connect-src 'self'", headers["Content-Security-Policy"])
        self.assertNotIn(self.session.encode(), page)  # No token-bearing URL in page source.
        self.assertNotIn(str(self.directory).encode(), page)
        self.assertEqual(self.request("GET", self.session + "app.apk")[2], self.apk.read_bytes())
        self.assertEqual(self.request("GET", self.session + "recipient-public.pem")[2], self.public.read_bytes())
        self.assertEqual(self.request("HEAD", self.session + "app.apk")[2], b"")

    def test_page_fingerprint_uses_spki_der_not_pem_text(self):
        pem = self.public.read_bytes()
        der = base64.b64decode(b"".join(pem.splitlines()[1:-1]))
        expected = hashlib.sha256(der).hexdigest().encode("ascii")
        self.assertIn(b"SPKI DER SHA-256", self.server.page)
        self.assertIn(expected, self.server.page)
        self.assertNotIn(hashlib.sha256(pem).hexdigest().encode("ascii"), self.server.page)
        # The same key with CRLF and different PEM wrapping has the same fingerprint.
        encoded = base64.b64encode(der)
        alternate = self.directory / "rewrapped.pem"
        alternate.write_bytes(b"-----BEGIN PUBLIC KEY-----\r\n" + b"\r\n".join(
            encoded[index:index + 64] for index in range(0, len(encoded), 64)
        ) + b"\r\n-----END PUBLIC KEY-----\r\n")
        unserved = transfer.create_server(self.apk, alternate, self.directory / "other.json", port=0)
        try:
            self.assertIn(expected, unserved.page)
        finally:
            unserved.server_close()

    def test_wrong_session_and_path_traversal_never_serve_files(self):
        (self.directory / "secret.json").write_text("must not be served")
        for path in ("/", "/wrong/app.apk", self.session + "../secret.json",
                     self.session + "%2e%2e/secret.json", self.session + "app.apk/../secret.json",
                     self.session + "app.apk?path=../secret.json", self.session + "secret.json"):
            with self.subTest(path=path):
                code, _, body = self.request("GET", path)
                self.assertEqual(code, 404)
                self.assertNotIn(b"must not be served", body)
        self.assertEqual(self.request("POST", "/wrong/upload", b"{}",
                                      {"Content-Type": "application/json"})[0], 404)
        self.assertFalse(self.output.exists())

    def test_plaintext_identity_and_extra_plaintext_fields_are_rejected(self):
        plaintext = {"version": 1, "sn": "SYNTHETIC_ONLY", "signature": "data",
                     "bindToken": "data", "rsaPublicKey": "data", "rsaPrivateKey": "data"}
        for value in (plaintext, {**envelope(), "sn": "SYNTHETIC_ONLY"},
                      {**envelope(), "rsaPrivateKey": "plain"}, {**envelope(), "version": True}):
            with self.subTest(fields=list(value)):
                self.assertEqual(self.post(json.dumps(value).encode())[0], 400)
                self.assertFalse(self.output.exists())

    def test_oversized_body_is_rejected_before_reading_it(self):
        code, _, _ = self.post(b"", {"Content-Type": "application/json",
                                     "Content-Length": str(transfer.MAX_UPLOAD + 1)})
        self.assertEqual(code, 413)
        self.assertFalse(self.output.exists())

    def test_algorithm_base64_and_lengths_are_strict(self):
        for field, value in (("keyWrap", "RSA-OAEP-SHA256"), ("contentCipher", "AES-128-GCM"),
                             ("wrappedKey", base64.b64encode(b"w" * 383).decode()),
                             ("nonce", base64.b64encode(b"n" * 11).decode()),
                             ("nonce", envelope()["nonce"] + "\n"),
                             ("ciphertext", base64.b64encode(b"x" * 16).decode())):
            with self.subTest(field=field, changed=value):
                self.assertEqual(self.post(json.dumps({**envelope(), field: value}).encode())[0], 400)
        duplicate = json.dumps(envelope()).replace('"version": 1', '"version": 1, "version": 1')
        self.assertEqual(self.post(duplicate.encode())[0], 400)
        self.assertFalse(self.output.exists())

    def test_valid_sized_fake_envelope_accepted_once_without_crypto_claim(self):
        # Intentionally not real encryption: acceptance is explicitly structural.
        payload = json.dumps(envelope()).encode()
        code, _, body = self.post(payload)
        self.assertEqual(code, 201)
        self.assertEqual(json.loads(body), {"ok": True, "structuralCheckOnly": True, "uploadClosed": True})
        self.assertEqual(json.loads(self.output.read_bytes()), envelope())
        self.assertEqual(stat.S_IMODE(self.output.stat().st_mode), 0o600)
        first = self.output.read_bytes()
        self.assertEqual(self.post(payload)[0], 409)
        self.assertEqual(self.output.read_bytes(), first)
        self.assertEqual(self.request("GET", self.session + "app.apk")[0], 200)

    def test_destination_created_after_start_is_never_overwritten(self):
        self.output.write_bytes(b"existing file")
        self.assertEqual(self.post(json.dumps(envelope()).encode())[0], 409)
        self.assertEqual(self.output.read_bytes(), b"existing file")

    def test_host_origin_and_content_type_are_checked(self):
        payload = json.dumps(envelope()).encode()
        self.assertEqual(self.request("GET", self.session, headers={"Host": "attacker.invalid"})[0], 403)
        self.assertEqual(self.post(payload, {"Content-Type": "application/json",
                                            "Origin": "http://attacker.invalid"})[0], 403)
        self.assertEqual(self.post(payload, {"Content-Type": "text/plain"})[0], 415)
        self.assertEqual(self.post(payload, {"Content-Type": "application/json",
                                            "Transfer-Encoding": "chunked"})[0], 411)
        self.assertFalse(self.output.exists())

    def test_logs_do_not_record_session_path_or_body(self):
        stream = io.StringIO()
        with redirect_stderr(stream):
            self.request("GET", self.session + "missing")
            self.post(b'{"rsaPrivateKey":"SYNTHETIC_SECRET_MUST_NOT_LOG"}')
        self.assertEqual(stream.getvalue(), "")

    def test_create_server_rejects_wildcard_and_existing_or_symlink_outputs(self):
        for bind in ("0.0.0.0", "::", "example.invalid", "224.0.0.1"):
            with self.subTest(bind=bind), self.assertRaises(transfer.TransferError):
                transfer.create_server(self.apk, self.public, self.output, bind=bind, port=0)
        existing = self.directory / "existing"
        existing.write_text("keep")
        link = self.directory / "link"
        link.symlink_to(self.directory / "absent")
        for output in (existing, link):
            with self.subTest(output=output.name), self.assertRaises(transfer.TransferError):
                transfer.create_server(self.apk, self.public, output, port=0)
        self.assertEqual(existing.read_text(), "keep")

    def test_private_key_cannot_be_selected_as_public_download(self):
        with self.assertRaises(transfer.TransferError):
            transfer.recipient_key_bytes(b"-----BEGIN PRIVATE KEY-----\nAAAA\n-----END PRIVATE KEY-----\n")


class TtlTest(unittest.TestCase):
    def test_monotonic_deadline_closes_server_without_a_network_service(self):
        class FakeServer:
            ttl_expired = False
            elapsed = 100.0
            handled = 0
            closed = False
            active_closed = False

            def handle_request(self):
                self.handled += 1
                self.elapsed += 1

            def close_active_request(self):
                self.active_closed = True

            def server_close(self):
                self.closed = True

        server = FakeServer()
        with patch.object(transfer.time, "monotonic", side_effect=lambda: server.elapsed):
            transfer.serve_with_ttl(server, 2.5)
        self.assertEqual(server.handled, 3)
        self.assertTrue(server.closed)
        self.assertTrue(server.active_closed)
        self.assertTrue(server.ttl_expired)

    def test_cli_defaults_to_30_minutes_and_accepts_explicit_ttl(self):
        class FakeServer:
            session_url = "http://127.0.0.1:8765/synthetic/"
            def server_close(self):
                pass

        for extra, expected in (([], 1800), (["--ttl-seconds", "7.5"], 7.5)):
            with self.subTest(extra=extra), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary)
                argv = ["local_transfer.py", "--apk", "synthetic.apk", "--recipient-public-key", "synthetic.pem",
                        "--output", str(root / "envelope.json"), "--session-url-file", str(root / "url.txt"), *extra]
                server = FakeServer()
                with patch.object(sys, "argv", argv), patch.object(transfer, "create_server", return_value=server), \
                        patch.object(transfer, "serve_with_ttl") as serve, \
                        patch.object(transfer, "_write_new"), patch("sys.stdout", new=io.StringIO()):
                    transfer.main()
                    serve.assert_called_once_with(server, expected)

    def test_invalid_ttl_is_rejected(self):
        for value in ("0", "-1", "nan", "inf", "not-a-number"):
            with self.subTest(value=value), self.assertRaises(argparse.ArgumentTypeError):
                transfer._ttl_seconds(value)

    def test_expiry_interrupts_a_stalled_request_and_closes_listening_socket(self):
        # Loopback test only. A client that never sends headers must not extend TTL.
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            apk, public = root / "app.apk", root / "public.pem"
            apk.write_bytes(b"synthetic apk")
            public.write_bytes(synthetic_public_pem())
            server = transfer.create_server(apk, public, root / "encrypted.json", port=0)
            errors = []
            def run():
                try:
                    transfer.serve_with_ttl(server, 0.2)
                except Exception as error:
                    errors.append(type(error).__name__)
            worker = threading.Thread(target=run, daemon=True)
            client = socket.create_connection(server.server_address, timeout=2)
            try:
                worker.start()
                worker.join(timeout=2)
                self.assertFalse(worker.is_alive())
                self.assertEqual(errors, [])
                self.assertEqual(server.socket.fileno(), -1)
                self.assertEqual(client.recv(1), b"")
                self.assertTrue(server.apk_file.closed)
            finally:
                client.close()
                server.close_active_request()
                server.server_close()


if __name__ == "__main__":
    unittest.main()
