from __future__ import annotations

import http.client
from http.server import ThreadingHTTPServer
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest.mock import Mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from recording_manager import Handler, Manager


class ManagerBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.config = self.root / "config.json"
        self.config.write_text(json.dumps({"libraryRoot": str(self.root / "library"), "port": 8769}))
        self.manager = Manager(self.config)
        wav = self.root / "synthetic.wav"
        wav.write_bytes(b"SYNTHETIC-TEST-DATA-ONLY")
        self.record = self.manager.library.import_recording("8810000000000001", 123,
            {"wav": wav}, title="Boundary test", source="synthetic unit test")
        self.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.server.manager = self.manager
        self.manager.port = self.server.server_address[1]
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.addCleanup(self.stop_server)

    def stop_server(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(2)

    def request(self, route, method="GET", body=None, headers=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.manager.port, timeout=3)
        self.addCleanup(connection.close)
        connection.request(method, "/" + self.manager.token + "/" + route,
            body=json.dumps(body).encode() if body is not None else None,
            headers=headers or {})
        response = connection.getresponse()
        return response.status, dict(response.getheaders()), response.read()

    def post_headers(self):
        return {"Origin": f"http://127.0.0.1:{self.manager.port}", "Content-Type": "application/json"}

    def test_capability_host_origin_and_no_delete_boundary(self):
        status, _, _ = self.request("api/state", headers={"Host": "attacker.invalid"})
        self.assertEqual(status, 403)
        status, _, _ = self.request("api/update", "POST", {"id": self.record["id"]},
                                   {"Origin": "https://attacker.invalid", "Content-Type": "application/json"})
        self.assertEqual(status, 403)
        status, _, _ = self.request("api/delete", "POST", {"id": self.record["id"]}, self.post_headers())
        self.assertEqual(status, 404)
        status, headers, data = self.request("api/state")
        self.assertEqual(status, 200)
        self.assertFalse(json.loads(data)["automaticDeletion"])
        self.assertEqual(headers["Referrer-Policy"], "no-referrer")
        self.assertIn("script-src 'self'", headers["Content-Security-Policy"])
        connection = http.client.HTTPConnection("127.0.0.1", self.manager.port)
        self.addCleanup(connection.close)
        connection.request("GET", "/not-the-capability/api/state")
        response = connection.getresponse()
        self.assertEqual(response.status, 403)
        response.read()

    def test_audio_range_and_path_allowlist(self):
        route = f"file/{self.record['id']}/wav"
        status, headers, data = self.request(route, headers={"Range": "bytes=1-8"})
        self.assertEqual((status, data), (206, b"YNTHETIC"))
        self.assertEqual(headers["Content-Range"], "bytes 1-8/24")
        status, _, _ = self.request(route, headers={"Range": "bytes=99-100"})
        self.assertEqual(status, 416)
        status, _, _ = self.request(f"file/{self.record['id']}/../../config.json")
        self.assertEqual(status, 400)

    def test_metadata_and_export_do_not_invent_transcript(self):
        status, _, data = self.request("api/update", "POST", {"id": self.record["id"],
            "title": "<script>not executable</script>", "tags": ["术语"], "project": "项目", "notes": "待核对"},
            self.post_headers())
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(data)["title"], "<script>not executable</script>")
        result = self.manager.export(self.record["id"])
        exported = Path(result["path"])
        self.assertFalse((exported / "转写原文.md").exists())
        self.assertFalse((exported / "会议纪要.md").exists())
        self.assertIn("尚未转写", Path(result["indexPath"]).read_text())
        self.assertEqual(Path(result["indexPath"]).stat().st_mode & 0o777, 0o600)

    def test_filtered_library_does_not_hide_existing_device_copy(self):
        status, _, data = self.request("api/state?q=definitely-no-match")
        result = json.loads(data)
        self.assertEqual(status, 200)
        self.assertEqual(result["records"], [])
        self.assertEqual(result["recordIndex"], [{"id": self.record["id"],
            "sn": "8810000000000001", "sessionId": 123}])

    def test_manual_transcript_is_saved_and_returns_warning_when_auto_queue_fails(self):
        processing = Mock()
        processing.config = {"autoProcessNew": True}
        processing.enqueue.side_effect = RuntimeError("PRIVATE_SYNTHETIC_QUEUE_ERROR")
        self.manager.processing = processing
        text = "合成的手工修订转写；入队失败不能撤销这次保存。"
        status, _, data = self.request("api/text", "POST", {"id": self.record["id"],
            "kind": "transcript", "text": text}, self.post_headers())
        result = json.loads(data)
        self.assertEqual(status, 200)
        self.assertIn("processingWarning", result)
        self.assertTrue(result["processingWarning"])
        self.assertNotIn("PRIVATE_SYNTHETIC_QUEUE_ERROR", data.decode())
        self.assertEqual(result["transcript"], text)
        processing.enqueue.assert_called_once_with(self.record["id"], "minutes", followup=True)
        persisted = self.manager.library.get_recording(self.record["id"])
        self.assertEqual(persisted["transcript"], text)
        self.assertEqual(persisted["textStatus"]["transcript"]["source"], "user_or_external_import")
        saved = self.manager.root / persisted["textStatus"]["transcript"]["relativePath"]
        self.assertEqual(saved.read_text(), text)

    def test_damaged_audio_is_not_served_as_verified_content(self):
        relative = self.record["artifacts"]["wav"]["relativePath"]
        (self.manager.root / relative).write_bytes(b"ALTERED")
        status, _, _ = self.request(f"file/{self.record['id']}/wav")
        self.assertEqual(status, 400)
        status, _, data = self.request(f"api/record/{self.record['id']}")
        self.assertEqual(status, 200)
        self.assertFalse(json.loads(data)["record"]["integrityVerified"])

    def test_second_start_reuses_local_library_even_with_a_proxy_configured(self):
        config = json.loads(self.config.read_text())
        config["port"] = self.manager.port
        self.config.write_text(json.dumps(config))
        result = subprocess.run([sys.executable, str(Path(__file__).resolve().parents[1] / "recording_manager.py"),
            "--config", str(self.config)], capture_output=True, text=True, timeout=10,
            env={**os.environ, "http_proxy": "http://127.0.0.1:1", "HTTP_PROXY": "http://127.0.0.1:1",
                 "no_proxy": "", "NO_PROXY": ""})
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("已经运行", result.stdout)


if __name__ == "__main__":
    unittest.main()
