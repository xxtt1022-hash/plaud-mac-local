from __future__ import annotations

from contextlib import redirect_stderr, redirect_stdout
from io import StringIO
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import candidate_diagnostic
import mac_adapter
import receiver_state


class CandidateDiagnosticTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.owner = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        cls.recipient = rsa.generate_private_key(public_exponent=65537, key_size=3072)
        cls.recipient_pem = cls.recipient.private_bytes(serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8, serialization.NoEncryption()).decode()
        cls.legacy = {"version": 1, "sn": "881SYNTHETICONLY", "signature": mac_adapter.b64(b"s" * 256),
                      "bindToken": "synthetic-bind-token-never-real",
                      "rsaPublicKey": cls.owner.public_key().public_bytes(serialization.Encoding.PEM,
                          serialization.PublicFormat.SubjectPublicKeyInfo).decode(),
                      "rsaPrivateKey": cls.owner.private_bytes(serialization.Encoding.PEM,
                          serialization.PrivateFormat.PKCS8, serialization.NoEncryption()).decode()}
        cls.candidate = {**cls.legacy, "verification": "candidate"}

    def envelope(self, material):
        aes, nonce = b"k" * 32, b"n" * 12
        return {"version": 1, "keyWrap": "RSA-OAEP-SHA256-MGF1-SHA256", "contentCipher": "AES-256-GCM",
                "wrappedKey": mac_adapter.b64(self.recipient.public_key().encrypt(aes, padding.OAEP(
                    mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None))),
                "nonce": mac_adapter.b64(nonce), "ciphertext": mac_adapter.b64(AESGCM(aes).encrypt(
                    nonce, json.dumps(material).encode(), b"plaud-pc-bootstrap-v1"))}

    def state_files(self, folder, material):
        root, password = Path(folder), "synthetic-store-passphrase-never-real-000000000000000000000000000000"
        mac_adapter.private_write(root / mac_adapter.RECIPIENT_FILE, json.dumps(mac_adapter.seal(
            {"privatePem": self.recipient_pem}, password, "recipient-key")).encode())
        package = root / "encrypted-android.json"
        package.write_text(json.dumps(self.envelope(material)))
        return root, password, package

    def test_default_rejects_candidate_and_unknown_states_even_with_opt_in(self):
        with self.assertRaises(ValueError):
            mac_adapter.validate_identity(self.candidate, self.legacy["sn"])
        with self.assertRaises(ValueError):
            mac_adapter.decrypt_android_package(self.envelope(self.candidate), self.recipient_pem,
                                                 self.legacy["sn"])
        for unknown in (None, "", "pending", "CONFIRMED", True, 0):
            for allow in (False, True):
                with self.assertRaises(ValueError):
                    mac_adapter.validate_identity({**self.legacy, "verification": unknown},
                                                   self.legacy["sn"], allow_candidate=allow)

    def test_legacy_and_confirmed_regression_preserve_verification(self):
        for material in (self.legacy, {**self.legacy, "verification": "confirmed"}):
            self.assertEqual(mac_adapter.decrypt_android_package(self.envelope(material),
                             self.recipient_pem, self.legacy["sn"]), material)
            with tempfile.TemporaryDirectory() as folder:
                root, password, package = self.state_files(folder, material)
                mac_adapter.import_android(package, root, password, self.legacy["sn"])
                self.assertEqual(mac_adapter.load_identity(root, password, self.legacy["sn"]), material)
        self.assertEqual(mac_adapter.decrypt_android_package(self.envelope(self.candidate),
                         self.recipient_pem, self.legacy["sn"], allow_candidate=True), self.candidate)

    def test_normal_import_never_writes_candidate_and_normal_load_rejects_it(self):
        with tempfile.TemporaryDirectory() as folder:
            root, password, package = self.state_files(folder, self.candidate)
            with self.assertRaises(ValueError):
                mac_adapter.import_android(package, root, password, self.legacy["sn"])
            self.assertFalse((root / mac_adapter.IDENTITY_FILE).exists())
            # Even a candidate manually placed in a valid encrypted store is refused on load.
            mac_adapter.private_write(root / mac_adapter.IDENTITY_FILE, json.dumps(mac_adapter.seal(
                self.candidate, password, "device-identity")).encode())
            with self.assertRaises(ValueError):
                mac_adapter.load_identity(root, password, self.legacy["sn"])

    def test_isolated_diagnostic_load_is_in_memory_and_summary_omits_secrets(self):
        with tempfile.TemporaryDirectory() as folder:
            root, password, package = self.state_files(folder, self.candidate)
            before = {path.name: path.read_bytes() for path in root.iterdir()}
            with patch.object(receiver_state, "load_store_passphrase", return_value=password), \
                    patch.object(mac_adapter, "private_write", side_effect=AssertionError("No identity writes")):
                result = candidate_diagnostic.load_candidate_in_memory(package, root, self.legacy["sn"])
            self.assertEqual(result, self.candidate)
            self.assertEqual({path.name: path.read_bytes() for path in root.iterdir()}, before)
            summary = candidate_diagnostic.diagnostic_summary(result)
            text = json.dumps(summary)
            for secret in (self.legacy["sn"], self.legacy["signature"], self.legacy["bindToken"],
                           self.legacy["rsaPrivateKey"], password):
                self.assertNotIn(secret, text)
            self.assertFalse(summary["ownerStoreWritten"])
            self.assertFalse(summary["deviceAcceptanceVerified"])
            self.assertEqual(summary["verification"], "candidate")

    def test_cli_prints_only_allowlisted_summary_and_never_writes_owner_store(self):
        with tempfile.TemporaryDirectory() as folder:
            root, password, package = self.state_files(folder, self.candidate)
            out, err = StringIO(), StringIO()
            argv = ["candidate_diagnostic.py", "--package", str(package),
                    "--state-dir", str(root), "--sn", self.legacy["sn"]]
            with patch.object(receiver_state, "load_store_passphrase", return_value=password), \
                    patch.object(sys, "argv", argv), redirect_stdout(out), redirect_stderr(err):
                candidate_diagnostic.main()
            summary = json.loads(out.getvalue())
            self.assertEqual(summary["verification"], "candidate")
            self.assertEqual(err.getvalue(), "")
            self.assertFalse((root / mac_adapter.IDENTITY_FILE).exists())
            for secret in (self.legacy["sn"], self.legacy["signature"], self.legacy["bindToken"],
                           self.legacy["rsaPrivateKey"], password):
                self.assertNotIn(secret, out.getvalue())

    def test_diagnostic_rejects_legacy_confirmed_tamper_wrong_sn_and_wrong_rsa(self):
        other = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        wrong_public = other.public_key().public_bytes(serialization.Encoding.PEM,
                                                      serialization.PublicFormat.SubjectPublicKeyInfo).decode()
        for material in (self.legacy, {**self.legacy, "verification": "confirmed"},
                         {**self.candidate, "rsaPublicKey": wrong_public}):
            with tempfile.TemporaryDirectory() as folder:
                root, password, package = self.state_files(folder, material)
                with patch.object(receiver_state, "load_store_passphrase", return_value=password):
                    with self.assertRaises(candidate_diagnostic.CandidateDiagnosticError):
                        candidate_diagnostic.load_candidate_in_memory(package, root, self.legacy["sn"])
        with tempfile.TemporaryDirectory() as folder:
            root, password, package = self.state_files(folder, self.candidate)
            with patch.object(receiver_state, "load_store_passphrase", return_value=password):
                with self.assertRaises(candidate_diagnostic.CandidateDiagnosticError):
                    candidate_diagnostic.load_candidate_in_memory(package, root, "881WRONGDEVICE")
                envelope = json.loads(package.read_text())
                ciphertext = bytearray(mac_adapter.unb64(envelope["ciphertext"]))
                ciphertext[-1] ^= 1
                envelope["ciphertext"] = mac_adapter.b64(bytes(ciphertext))
                package.write_text(json.dumps(envelope))
                with self.assertRaises(candidate_diagnostic.CandidateDiagnosticError):
                    candidate_diagnostic.load_candidate_in_memory(package, root, self.legacy["sn"])


if __name__ == "__main__":
    unittest.main()
