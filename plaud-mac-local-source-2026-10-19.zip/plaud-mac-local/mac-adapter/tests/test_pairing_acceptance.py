import base64
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import mac_adapter
import pairing_acceptance as acceptance
from binding_registration import BindingRegistrationError


class PairingAcceptanceTest(unittest.IsolatedAsyncioTestCase):
    @classmethod
    def setUpClass(cls):
        private = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        cls.serial = "8811A2B3C4D5E6F7"
        cls.material = {"version": 1, "verification": "candidate", "sn": cls.serial,
            "bindToken": "0123456789abcdef0123456789abcdef",
            "signature": base64.b64encode(bytes(256)).decode(),
            "rsaPrivateKey": private.private_bytes(serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8, serialization.NoEncryption()).decode(),
            "rsaPublicKey": private.public_key().public_bytes(serialization.Encoding.PEM,
                serialization.PublicFormat.SubjectPublicKeyInfo).decode()}
        payload = base64.urlsafe_b64encode(json.dumps({"sub": "client_user_" + cls.material["bindToken"]}).encode()).rstrip(b"=").decode()
        cls.token = "synthetic." + payload + ".signature"
        cls.password = "synthetic-local-passphrase-32chars"

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.state = Path(self.temp.name)

    async def run_case(self, proof, *, cloud=None, material=None, token=None):
        async def run_pair(candidate):
            return dict(proof)
        return await acceptance.accept_candidate(material or self.material, self.state, self.password,
            self.serial, token or self.token, run_pair=run_pair,
            cloud_register=cloud or (lambda *args, **kwargs: {"cloudBindingRegistrationVerified": True}))

    async def test_failed_or_incomplete_device_proof_never_writes_or_registers(self):
        for proof in [{}, {"challengeVerified": False, "handshakeAccepted": True, "handshakeStatus": 0},
            {"challengeVerified": True, "handshakeAccepted": False, "handshakeStatus": 0},
            {"challengeVerified": True, "handshakeAccepted": True, "handshakeStatus": False},
            {"challengeVerified": True, "handshakeAccepted": True, "handshakeStatus": 1}]:
            def forbidden(*args, **kwargs):
                self.fail("Cloud registration before real acceptance")
            result = await self.run_case(proof, cloud=forbidden)
            self.assertFalse(result["confirmedOwnerStoreWritten"])
            self.assertFalse((self.state / mac_adapter.IDENTITY_FILE).exists())

    async def test_success_preserves_encrypted_owner_before_cloud_request(self):
        def cloud(*args, **kwargs):
            material = mac_adapter.load_identity(self.state, self.password, self.serial)
            self.assertEqual(material["verification"], "confirmed")
            self.assertEqual(material["rsaPrivateKey"], self.material["rsaPrivateKey"])
            return {"cloudBindingRegistrationVerified": True}
        result = await self.run_case({"challengeVerified": True, "handshakeAccepted": True, "handshakeStatus": 0}, cloud=cloud)
        self.assertTrue(result["confirmedOwnerStoreWritten"])
        raw = (self.state / mac_adapter.IDENTITY_FILE).read_text()
        self.assertNotIn("PRIVATE KEY", raw)
        self.assertNotIn(self.material["bindToken"], raw)
        self.assertEqual((self.state / mac_adapter.IDENTITY_FILE).stat().st_mode & 0o777, 0o600)
        self.assertEqual(self.material["verification"], "candidate")

    async def test_cloud_403_keeps_real_local_identity_and_does_not_retry(self):
        sent = []
        def cloud(*args, **kwargs):
            sent.append(1)
            raise BindingRegistrationError("synthetic rejection", 403)
        result = await self.run_case({"challengeVerified": True, "handshakeAccepted": True, "handshakeStatus": 0}, cloud=cloud)
        self.assertEqual(sent, [1])
        self.assertTrue(result["confirmedOwnerStoreWritten"])
        self.assertEqual(result["cloudHttpStatus"], 403)
        self.assertFalse(result["cloudBindingRegistrationVerified"])
        self.assertEqual(mac_adapter.load_identity(self.state, self.password, self.serial)["verification"], "confirmed")

    async def test_existing_owner_or_subject_mismatch_stops_before_pairing(self):
        async def forbidden(candidate):
            self.fail("Pairing must not start")
        with self.assertRaises(BindingRegistrationError):
            await acceptance.accept_candidate(self.material, self.state, self.password, self.serial,
                "synthetic.e30.signature", run_pair=forbidden)
        path = self.state / mac_adapter.IDENTITY_FILE
        path.write_bytes(b"EXISTING_OWNER_MARKER")
        with self.assertRaises(acceptance.PairingAcceptanceError):
            await acceptance.accept_candidate(self.material, self.state, self.password, self.serial,
                self.token, run_pair=forbidden)
        self.assertEqual(path.read_bytes(), b"EXISTING_OWNER_MARKER")

    async def test_disk_failure_preserves_device_proof_and_stops_before_cloud(self):
        def forbidden(*args, **kwargs):
            self.fail("Cloud registration before identity preservation")
        with patch.object(acceptance, "save_accepted_owner", side_effect=OSError("PRIVATE_MARKER")):
            result = await self.run_case({"challengeVerified": True, "handshakeAccepted": True,
                "handshakeStatus": 0}, cloud=forbidden)
        self.assertTrue(result["handshakeAccepted"])
        self.assertFalse(result["confirmedOwnerStoreWritten"])
        self.assertFalse(result["cloudBindAttempted"])
        self.assertEqual(result["ownerPreservationErrorType"], "OSError")
        self.assertNotIn("PRIVATE_MARKER", json.dumps(result))


if __name__ == "__main__":
    unittest.main()
