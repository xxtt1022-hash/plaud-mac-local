#!/usr/bin/env python3
"""Serve two explicit public files and receive one encrypted Android envelope.

Standard library only. This service does not decrypt or authenticate the upload.
The CLI writes its capability URL to a new 0600 file, never to request logs.
No service starts at import. Use a trusted local network for the HTTP transport.
"""
from __future__ import annotations

import argparse
import base64
import binascii
import hashlib
from http.server import BaseHTTPRequestHandler, HTTPServer
import ipaddress
import json
import math
import os
from pathlib import Path
import secrets
import shutil
import socket
import stat
import sys
import threading
import time
from typing import Any

MAX_UPLOAD = 256 * 1024
DEFAULT_TTL_SECONDS = 30 * 60
FIELDS = {"version", "keyWrap", "contentCipher", "wrappedKey", "nonce", "ciphertext"}
KEY_WRAP = "RSA-OAEP-SHA256-MGF1-SHA256"
CONTENT_CIPHER = "AES-256-GCM"
RSA_ALGORITHM = bytes.fromhex("300d06092a864886f70d0101010500")


class TransferError(ValueError):
    """Controlled error; messages contain no file contents or request paths."""


def _tlv(data: bytes, offset: int, tag: int) -> tuple[bytes, int]:
    if offset + 2 > len(data) or data[offset] != tag:
        raise TransferError("Invalid recipient public key")
    size = data[offset + 1]
    start = offset + 2
    if size & 0x80:
        count = size & 0x7F
        if not 1 <= count <= 4 or start + count > len(data) or data[start] == 0:
            raise TransferError("Invalid recipient public key")
        size = int.from_bytes(data[start:start + count], "big")
        if size < 128:
            raise TransferError("Invalid recipient public key")
        start += count
    end = start + size
    if end > len(data):
        raise TransferError("Invalid recipient public key")
    return data[start:end], end


def _positive_integer(data: bytes) -> int:
    if not data or data[0] & 0x80 or (len(data) > 1 and data[0] == 0 and not data[1] & 0x80):
        raise TransferError("Invalid recipient public key")
    return int.from_bytes(data, "big")


def _recipient_key(pem: bytes) -> tuple[int, bytes]:
    """Read an RSA SPKI PUBLIC KEY; return wrapped-key size and exact SPKI DER.

    This tiny DER reader checks structure and integer size; it is not a general
    certificate parser or a mathematical verification of an RSA public key.
    """
    if len(pem) > 4096:
        raise TransferError("Invalid recipient public key")
    try:
        lines = pem.decode("ascii").strip().splitlines()
        if lines[0] != "-----BEGIN PUBLIC KEY-----" or lines[-1] != "-----END PUBLIC KEY-----":
            raise ValueError()
        der = base64.b64decode("".join(lines[1:-1]), validate=True)
        spki, end = _tlv(der, 0, 0x30)
        if end != len(der) or not spki.startswith(RSA_ALGORITHM):
            raise ValueError()
        bits, end = _tlv(spki, len(RSA_ALGORITHM), 0x03)
        if end != len(spki) or not bits or bits[0] != 0:
            raise ValueError()
        key, end = _tlv(bits, 1, 0x30)
        if end != len(bits):
            raise ValueError()
        modulus, end = _tlv(key, 0, 0x02)
        exponent, final = _tlv(key, end, 0x02)
        n, e = _positive_integer(modulus), _positive_integer(exponent)
        if final != len(key) or not 3072 <= n.bit_length() <= 8192 or n % 2 != 1 or e < 3 or e % 2 != 1:
            raise ValueError()
        return (n.bit_length() + 7) // 8, der
    except (ValueError, IndexError, UnicodeError, binascii.Error):
        raise TransferError("Invalid recipient public key") from None


def recipient_key_bytes(pem: bytes) -> int:
    return _recipient_key(pem)[0]


def _unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise TransferError("Duplicate JSON field")
        result[key] = value
    return result


def _base64_field(value: Any, *, minimum: int, maximum: int) -> bytes:
    if not isinstance(value, str) or len(value) > 4 * ((maximum + 2) // 3):
        raise TransferError("Invalid envelope encoding")
    try:
        decoded = base64.b64decode(value, validate=True)
    except (ValueError, binascii.Error):
        raise TransferError("Invalid envelope encoding") from None
    if not minimum <= len(decoded) <= maximum or base64.b64encode(decoded).decode("ascii") != value:
        raise TransferError("Invalid envelope size or encoding")
    return decoded


def validate_envelope(raw: bytes, wrapped_key_size: int) -> bytes:
    """Return canonical envelope JSON after structural checks, without decryption.

    Exact fields prevent plaintext identity material or arbitrary extra metadata
    from being accepted. Random bytes of the correct sizes can still pass; only
    the separate Mac recipient import can authenticate/decrypt this envelope.
    """
    if not raw or len(raw) > MAX_UPLOAD:
        raise TransferError("Invalid upload size")
    try:
        envelope = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique_object)
    except (ValueError, UnicodeError, RecursionError):
        raise TransferError("Invalid encrypted envelope") from None
    if not isinstance(envelope, dict) or set(envelope) != FIELDS:
        raise TransferError("Only the defined encrypted envelope is accepted")
    if (type(envelope["version"]) is not int or envelope["version"] != 1
            or envelope["keyWrap"] != KEY_WRAP or envelope["contentCipher"] != CONTENT_CIPHER):
        raise TransferError("Unsupported envelope algorithm or version")
    _base64_field(envelope["wrappedKey"], minimum=wrapped_key_size, maximum=wrapped_key_size)
    _base64_field(envelope["nonce"], minimum=12, maximum=12)
    _base64_field(envelope["ciphertext"], minimum=17, maximum=MAX_UPLOAD)
    return json.dumps(envelope, ensure_ascii=True, separators=(",", ":")).encode("ascii")


def _new_path(path: Path) -> Path:
    parent = path.parent.resolve(strict=True)
    result = parent / path.name
    if not parent.is_dir() or not path.name or os.path.lexists(result):
        raise TransferError("Output path must be new; refusing replacement")
    return result


def _write_new(path: Path, payload: bytes) -> None:
    # O_EXCL also refuses a symlink or a file created after the initial check.
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
    try:
        with os.fdopen(fd, "wb") as output:
            os.fchmod(output.fileno(), 0o600)
            output.write(payload)
            output.flush()
            os.fsync(output.fileno())
    except BaseException:
        path.unlink(missing_ok=True)
        raise


def _open_public_file(path: Path):
    # Keep this exact opened inode, rather than resolving a request to a path.
    fd = os.open(path.resolve(strict=True), os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise TransferError("A selected public file is not a regular file")
        return os.fdopen(fd, "rb")
    except BaseException:
        os.close(fd)
        raise


class TransferServer(HTTPServer):
    """Single-request-at-a-time server; only one upload can be committed."""

    allow_reuse_address = False

    def get_request(self):
        request, address = super().get_request()
        self.active_request = request
        if getattr(self, "ttl_expired", False):
            self.close_active_request()
            raise OSError("Local transfer expired")
        return request, address

    def close_request(self, request) -> None:
        if getattr(self, "active_request", None) is request:
            self.active_request = None
        super().close_request(request)

    def close_active_request(self) -> None:
        request = getattr(self, "active_request", None)
        if request is not None:
            try:
                request.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            request.close()

    def handle_error(self, request, client_address) -> None:
        # The default traceback may include a capability path or request data.
        print("Local transfer request stopped; no request details logged", file=sys.stderr)

    def server_close(self) -> None:
        super().server_close()
        if hasattr(self, "apk_file"):
            self.apk_file.close()


class TransferHandler(BaseHTTPRequestHandler):
    server_version = "LocalTransfer"
    sys_version = ""
    protocol_version = "HTTP/1.0"

    def setup(self) -> None:
        super().setup()
        self.connection.settimeout(10)

    def log_message(self, format, *args) -> None:
        pass  # Never log URL capabilities, addresses, filenames or request data.

    def send_error(self, code, message=None, explain=None) -> None:
        self._reply(code, b'{"ok":false}', "application/json")

    def _reply(self, code: int, body: bytes, kind: str, *, head: bool = False,
               download: str | None = None) -> None:
        self.send_response(code)
        self.send_header("Content-Type", kind)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Connection", "close")
        self.send_header("Content-Security-Policy", self.server.csp)
        if download:
            self.send_header("Content-Disposition", f'attachment; filename="{download}"')
        self.end_headers()
        if not head:
            self.wfile.write(body)

    def _valid_host(self) -> bool:
        return self.headers.get_all("Host", []) == [self.server.expected_host]

    def do_HEAD(self) -> None:
        self.do_GET(head=True)

    def do_GET(self, head: bool = False) -> None:
        if not self._valid_host():
            self._reply(403, b'{"ok":false}', "application/json", head=head)
            return
        if self.path == self.server.session_path:
            self._reply(200, self.server.page, "text/html; charset=utf-8", head=head)
        elif self.path == self.server.session_path + "recipient-public.pem":
            self._reply(200, self.server.public_pem, "application/x-pem-file", head=head,
                        download="recipient-public.pem")
        elif self.path == self.server.session_path + "app.apk":
            apk = self.server.apk_file
            self.send_response(200)
            self.send_header("Content-Type", "application/vnd.android.package-archive")
            self.send_header("Content-Length", str(os.fstat(apk.fileno()).st_size))
            self.send_header("Content-Disposition", 'attachment; filename="plaud-local-bootstrap.apk"')
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Connection", "close")
            self.end_headers()
            if not head:
                apk.seek(0)
                shutil.copyfileobj(apk, self.wfile, length=64 * 1024)
        else:
            self._reply(404, b'{"ok":false}', "application/json", head=head)

    def do_POST(self) -> None:
        origins = self.headers.get_all("Origin", [])
        if not self._valid_host() or origins not in ([], [self.server.origin]):
            self._reply(403, b'{"ok":false}', "application/json")
            return
        if self.path != self.server.session_path + "upload":
            self._reply(404, b'{"ok":false}', "application/json")
            return
        if self.server.received:
            self._reply(409, b'{"ok":false,"error":"upload_closed"}', "application/json")
            return
        lengths = self.headers.get_all("Content-Length", [])
        if (self.headers.get_all("Transfer-Encoding") or len(lengths) != 1
                or not lengths[0].isascii() or not lengths[0].isdigit()):
            self._reply(411, b'{"ok":false}', "application/json")
            return
        # Bound digits before int() to avoid huge integer parsing.
        if len(lengths[0]) > 7 or int(lengths[0]) > MAX_UPLOAD:
            self._reply(413, b'{"ok":false}', "application/json")
            return
        length = int(lengths[0])
        if len(self.headers.get_all("Content-Type", [])) != 1 or self.headers.get_content_type() != "application/json":
            self._reply(415, b'{"ok":false}', "application/json")
            return
        try:
            raw = self.rfile.read(length)
            if len(raw) != length:
                raise TransferError("Truncated upload")
            canonical = validate_envelope(raw, self.server.wrapped_key_size)
        except (TransferError, TimeoutError):
            self._reply(400, b'{"ok":false,"error":"invalid_encrypted_envelope"}', "application/json")
            return
        try:
            _write_new(self.server.output_path, canonical)
        except FileExistsError:
            self._reply(409, b'{"ok":false,"error":"destination_exists"}', "application/json")
            return
        except OSError:
            self._reply(500, b'{"ok":false,"error":"save_failed"}', "application/json")
            return
        self.server.received = True
        self._reply(201, b'{"ok":true,"structuralCheckOnly":true,"uploadClosed":true}', "application/json")


def _page(script_nonce: str, public_sha256: str) -> bytes:
    return ("""<!doctype html><html lang="zh-CN"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>PLAUD 本地引导文件</title>
<h1>PLAUD 本地引导文件</h1>
<p>仅供本次手机与 Mac 传输使用。页面不会向外部服务发送数据。</p>
<ol><li><a href="app.apk" download>下载安卓引导 APK</a>，并由你在手机上确认安装。</li>
<li>Mac 接收公钥已内置本次 APK；仅在 App 提示未载入时，才
<a href="recipient-public.pem" download>下载此公钥</a>并导入。</li>
<li>App 导出加密身份包后，在下面选择该 JSON 文件并上传。</li></ol>
<p>接收公钥指纹（SPKI DER SHA-256，与安卓 App 口径一致）：<code>PUBLIC_HASH</code></p>
<p>只接受不超过 256 KiB 的加密 pc-bootstrap-v1.json。接收成功只表示结构检查通过，
还需 Mac 单独解密并核对设备。上传成功后，本页不再接受第二个文件。</p>
<input id="file" type="file" accept="application/json,.json"><button id="upload">上传加密身份包</button>
<p id="status" role="status"></p><script nonce="SCRIPT_NONCE">
const button=document.getElementById('upload'), status=document.getElementById('status');
button.addEventListener('click',async()=>{
 const file=document.getElementById('file').files[0];
 if(!file){status.textContent='请先选择 App 导出的加密 JSON。';return;}
 if(file.size>262144){status.textContent='文件超过 256 KiB，未上传。';return;}
 button.disabled=true;status.textContent='正在上传加密文件…';
 try{
  const response=await fetch('upload',{method:'POST',headers:{'Content-Type':'application/json'},body:file,cache:'no-store',credentials:'omit',redirect:'error'});
  const result=await response.json();
  if(response.status===201&&result.ok){status.textContent='加密文件已接收，结构检查通过。请返回 Mac 继续验真；本次上传入口已关闭。';return;}
  if(response.status===409){status.textContent='上传入口已关闭或目标文件已经存在，请返回 Mac 检查。';return;}
  status.textContent='文件未被接受。只选择引导 App 导出的加密身份包。';button.disabled=false;
 }catch(error){status.textContent='传输未确认，请在 Mac 检查后再处理。';button.disabled=false;}
});</script></html>""".replace("PUBLIC_HASH", public_sha256).replace("SCRIPT_NONCE", script_nonce)).encode("utf-8")


def create_server(apk: Path, recipient_public_key: Path, output: Path, *,
                  bind: str = "127.0.0.1", port: int = 8765) -> TransferServer:
    """Bind only the explicitly selected numeric IP. Port 0 is useful for tests."""
    try:
        address = ipaddress.ip_address(bind)
    except ValueError:
        raise TransferError("Bind address must be one explicit numeric IP") from None
    if address.is_unspecified or address.is_multicast or not 0 <= port <= 65535:
        raise TransferError("Invalid bind address or port")
    output_path = _new_path(output)
    with _open_public_file(recipient_public_key) as public_file:
        public_pem = public_file.read(4097)
    wrapped_key_size, public_der = _recipient_key(public_pem)
    apk_file = _open_public_file(apk)
    server_class = TransferServer
    if address.version == 6:
        class IPv6TransferServer(TransferServer):
            address_family = socket.AF_INET6
        server_class = IPv6TransferServer
    try:
        server = server_class((str(address), port), TransferHandler)
    except BaseException:
        apk_file.close()
        raise
    server.apk_file = apk_file
    server.public_pem = public_pem
    server.wrapped_key_size = wrapped_key_size
    server.output_path = output_path
    server.received = False
    server.session_path = "/" + secrets.token_urlsafe(32) + "/"
    host = f"[{address}]" if address.version == 6 else str(address)
    server.expected_host = f"{host}:{server.server_address[1]}"
    server.origin = "http://" + server.expected_host
    server.session_url = server.origin + server.session_path
    nonce = secrets.token_urlsafe(24)
    server.csp = ("default-src 'none'; script-src 'nonce-" + nonce
                  + "'; connect-src 'self'; form-action 'none'; base-uri 'none'; frame-ancestors 'none'")
    server.page = _page(nonce, hashlib.sha256(public_der).hexdigest())
    return server


def serve_with_ttl(server: TransferServer, ttl_seconds: float = DEFAULT_TTL_SECONDS) -> None:
    """Serve for a monotonic deadline, then close listening and active sockets.

    The watchdog also interrupts an in-progress request at expiry so a stalled
    client cannot keep the CLI alive beyond its session lifetime.
    """
    if not math.isfinite(ttl_seconds) or ttl_seconds <= 0:
        raise TransferError("TTL must be a positive finite number of seconds")
    deadline = time.monotonic() + ttl_seconds
    stopped = threading.Event()
    server.ttl_expired = False

    def expire_at_deadline() -> None:
        while not stopped.is_set():
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                server.ttl_expired = True
                server.close_active_request()
                server.server_close()
                return
            if stopped.wait(min(remaining, 0.25)):
                return

    watchdog = threading.Thread(target=expire_at_deadline, name="transfer-expiry", daemon=True)
    watchdog.start()
    try:
        while not server.ttl_expired:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            server.timeout = min(remaining, 0.25)
            try:
                server.handle_request()
            except (OSError, ValueError):
                if not server.ttl_expired:
                    raise
    finally:
        stopped.set()
        server.ttl_expired = True
        server.close_active_request()
        server.server_close()
        watchdog.join(timeout=1)


def _ttl_seconds(value: str) -> float:
    try:
        seconds = float(value)
        if not math.isfinite(seconds) or seconds <= 0:
            raise ValueError()
        return seconds
    except ValueError:
        raise argparse.ArgumentTypeError("TTL must be a positive finite number of seconds") from None


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apk", type=Path, required=True)
    parser.add_argument("--recipient-public-key", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--session-url-file", type=Path, required=True)
    parser.add_argument("--bind", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--ttl-seconds", type=_ttl_seconds, default=DEFAULT_TTL_SECONDS,
                        help="Session lifetime in seconds; default: 1800 (30 minutes)")
    args = parser.parse_args()
    server = None
    try:
        url_file = _new_path(args.session_url_file)
        if url_file == _new_path(args.output):
            raise TransferError("URL and upload output paths must differ")
        server = create_server(args.apk, args.recipient_public_key, args.output,
                               bind=args.bind, port=args.port)
        _write_new(url_file, (server.session_url + "\n").encode("ascii"))
        print("本地传输已就绪；会话地址已写入指定本地文件。按 Ctrl-C 停止。", flush=True)
        serve_with_ttl(server, args.ttl_seconds)
        print("本地传输会话已到期，连接已关闭。")
    except KeyboardInterrupt:
        print("本地传输已停止。")
    except Exception as error:
        # Controlled type only: file paths, capability URLs and bodies never appear.
        print(f"Local transfer stopped ({type(error).__name__}); no request details logged", file=sys.stderr)
        raise SystemExit(1) from None
    finally:
        if server is not None:
            server.server_close()


if __name__ == "__main__":
    main()
