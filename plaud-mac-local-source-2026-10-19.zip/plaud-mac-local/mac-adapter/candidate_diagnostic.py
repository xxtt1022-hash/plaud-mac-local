#!/usr/bin/env python3
"""Decrypt an explicitly candidate Android envelope in memory for isolated diagnostics.

This module never writes an owner identity, generates a key, contacts a network,
or starts BLE. Importing it does not read Keychain. The normal owner-store import
and load functions continue to reject candidate identities.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
from typing import Any

from cryptography.hazmat.primitives import serialization

import mac_adapter
import receiver_state


class CandidateDiagnosticError(RuntimeError):
    """Controlled diagnostic errors never include credential values."""


def load_candidate_in_memory(package: Path, state_dir: Path, expected_sn: str) -> dict[str, Any]:
    """Read encrypted files and return a validated candidate only in process memory.

    The return value contains owner secrets. Do not print, log or serialize it.
    It is not a claim that the device accepted this identity or that BLE bind succeeded.
    """
    try:
        passphrase = receiver_state.load_store_passphrase()
        recipient = mac_adapter.unseal(
            mac_adapter.read_json(state_dir / mac_adapter.RECIPIENT_FILE),
            passphrase, "recipient-key")
        candidate = mac_adapter.decrypt_android_package(
            mac_adapter.read_json(package), recipient["privatePem"], expected_sn,
            allow_candidate=True)
    except Exception as error:
        raise CandidateDiagnosticError(
            f"Candidate decryption or validation failed ({type(error).__name__})") from None
    if candidate.get("verification") != "candidate":
        raise CandidateDiagnosticError("Isolated diagnostics require an explicitly candidate envelope")
    return candidate


def diagnostic_summary(candidate: dict[str, Any]) -> dict[str, Any]:
    """Return allowlisted non-secret metadata; never include the serial or bind token."""
    if candidate.get("verification") != "candidate":
        raise CandidateDiagnosticError("Summary requires an explicitly candidate identity")
    public = serialization.load_pem_public_key(candidate["rsaPublicKey"].encode("ascii"))
    der = public.public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
    return {"verification": "candidate", "expectedSerialMatched": True,
            "rsaKeyPairMatched": True, "rsaKeyBits": public.key_size,
            "rsaPublicSpkiSha256": hashlib.sha256(der).hexdigest(),
            "signatureBytes": len(mac_adapter.unb64(candidate["signature"])),
            "ownerStoreWritten": False, "deviceAcceptanceVerified": False}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--state-dir", type=Path, required=True)
    parser.add_argument("--sn", required=True)
    args = parser.parse_args()
    try:
        candidate = load_candidate_in_memory(args.package, args.state_dir, args.sn)
        print(json.dumps(diagnostic_summary(candidate), sort_keys=True))
    except Exception as error:
        print(f"Candidate diagnostic stopped ({type(error).__name__}); credentials suppressed",
              file=sys.stderr)
        raise SystemExit(1) from None


if __name__ == "__main__":
    main()
