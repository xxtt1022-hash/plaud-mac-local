#!/usr/bin/env python3
"""Validate a complete Ogg mux and copy its unique Opus stream's original pages.

This does not decode, decrypt or re-encode audio. Supported Opus identification
headers are version 1, mapping family 0 (mono/stereo). Other profiles stop rather
than guessing a channel map. OpusTags comments are validated, never reported.
containerTimelineSeconds is (EOS granule - pre-skip) / 48000, not an independently
decoded duration: this tool does not parse audio TOCs or initial timeline offsets.

Every logical stream must have BOS, sequence numbers starting at zero, consistent
packet continuation, valid page CRCs, and EOS. Output is a byte-for-byte selection
of original pages, with no serial/sequence/granule/CRC rewrite or 80-byte slicing.
Only an explicitly supplied new output path is written, O_EXCL and mode 0600.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass, field
import hashlib
import json
import os
from pathlib import Path
import stat
import struct
import sys
from typing import Any

MAX_INPUT_BYTES = 128 * 1024 * 1024
MAX_PACKET_BYTES = 4 * 1024 * 1024
MAX_PAGES = 100_000
MAX_STREAMS = 32
NO_GRANULE = (1 << 64) - 1


class OggDemuxError(ValueError):
    pass


class OggChecksumError(OggDemuxError):
    pass


class OggSequenceError(OggDemuxError):
    pass


class OggContinuationError(OggDemuxError):
    pass


class UnsupportedOpusProfile(OggDemuxError):
    pass


class AmbiguousOpusStreams(OggDemuxError):
    pass


def _crc(page: bytes) -> int:
    """Ogg's non-reflected CRC-32, polynomial 0x04C11DB7, initial value zero."""
    value = 0
    for byte in page:
        value ^= byte << 24
        for _ in range(8):
            value = ((value << 1) ^ 0x04C11DB7) & 0xFFFFFFFF if value & 0x80000000 else (value << 1) & 0xFFFFFFFF
    return value


def _opus_head(packet: bytes) -> dict[str, int]:
    if len(packet) < 19 or packet[:8] != b"OpusHead":
        raise OggDemuxError("Invalid Opus identification header")
    if packet[8] != 1 or packet[18] != 0:
        raise UnsupportedOpusProfile("Only version 1, mapping family 0 is supported")
    if len(packet) != 19 or packet[9] not in (1, 2):
        raise OggDemuxError("Invalid mapping-family-0 header")
    return {"channels": packet[9], "preSkip": struct.unpack_from("<H", packet, 10)[0],
            "inputSampleRate": struct.unpack_from("<I", packet, 12)[0],
            "outputGainQ8": struct.unpack_from("<h", packet, 16)[0], "channelMappingFamily": 0}


def _opus_tags(packet: bytes) -> None:
    if len(packet) < 16 or packet[:8] != b"OpusTags":
        raise OggDemuxError("Invalid Opus comment header")
    vendor_size = struct.unpack_from("<I", packet, 8)[0]
    cursor = 12 + vendor_size
    if cursor + 4 > len(packet):
        raise OggDemuxError("Truncated vendor field")
    count = struct.unpack_from("<I", packet, cursor)[0]
    cursor += 4
    if count > (len(packet) - cursor) // 4:
        raise OggDemuxError("Invalid comment count")
    for _ in range(count):
        if cursor + 4 > len(packet):
            raise OggDemuxError("Truncated comment length")
        size = struct.unpack_from("<I", packet, cursor)[0]
        cursor += 4
        if size > len(packet) - cursor:
            raise OggDemuxError("Truncated comment field")
        cursor += size
    # OpusTags permits trailing padding/binary data; it is not metadata output.


@dataclass
class _Stream:
    next_sequence: int = 0
    pages: list[bytes] = field(default_factory=list, repr=False)
    pending: bytearray = field(default_factory=bytearray, repr=False)
    continuing: bool = False
    packet_start_sequence: int = 0
    packets: int = 0
    audio_packets: int = 0
    ended: bool = False
    opus: dict[str, int] | None = None
    tags_valid: bool = False
    last_audio_granule: int | None = None
    final_granule: int | None = None


@dataclass(frozen=True)
class DemuxResult:
    data: bytes = field(repr=False)
    metadata: dict[str, Any]


def inspect_ogg(data: bytes) -> DemuxResult:
    """Validate all pages/streams before returning only the unique Opus stream."""
    if not isinstance(data, bytes) or not 27 <= len(data) <= MAX_INPUT_BYTES:
        raise OggDemuxError("Input size outside supported bounds")
    streams: dict[int, _Stream] = {}
    offset = 0
    page_count = 0
    while offset < len(data):
        if len(data) - offset < 27 or data[offset:offset + 4] != b"OggS":
            raise OggDemuxError("Truncated or invalid page boundary")
        version, flags = data[offset + 4], data[offset + 5]
        if version != 0 or flags & ~7:
            raise OggDemuxError("Unsupported page version or flags")
        granule, serial, sequence, stored_crc = struct.unpack_from("<QIII", data, offset + 6)
        segments = data[offset + 26]
        body_start = offset + 27 + segments
        if body_start > len(data):
            raise OggDemuxError("Truncated lacing table")
        lacing = data[offset + 27:body_start]
        end = body_start + sum(lacing)
        if end > len(data):
            raise OggDemuxError("Truncated page body")
        page = data[offset:end]
        crc_input = page[:22] + bytes(4) + page[26:]
        if _crc(crc_input) != stored_crc:
            raise OggChecksumError("Page checksum mismatch")
        page_count += 1
        if page_count > MAX_PAGES:
            raise OggDemuxError("Page limit exceeded")
        stream = streams.get(serial)
        if stream is None:
            if len(streams) >= MAX_STREAMS or not flags & 2 or sequence != 0 or flags & 1:
                raise OggSequenceError("Invalid beginning of logical stream")
            stream = streams[serial] = _Stream()
        elif stream.ended or flags & 2:
            raise OggSequenceError("Unexpected page after BOS/EOS")
        if sequence != stream.next_sequence:
            raise OggSequenceError("Missing, repeated or reordered page")
        if bool(flags & 1) != stream.continuing:
            raise OggContinuationError("Continuation flag does not match packet boundary")
        stream.next_sequence = (sequence + 1) & 0xFFFFFFFF
        stream.pages.append(page)
        body_cursor = body_start
        completed_audio = 0
        completed_tags = False
        for segment_index, size in enumerate(lacing):
            if not stream.continuing:
                stream.packet_start_sequence = sequence
            if len(stream.pending) + size > MAX_PACKET_BYTES:
                raise OggDemuxError("Packet exceeds supported bounds")
            stream.pending.extend(data[body_cursor:body_cursor + size])
            body_cursor += size
            stream.continuing = size == 255
            if stream.continuing:
                continue
            packet = bytes(stream.pending)
            stream.pending.clear()
            if stream.packets == 0 and packet.startswith(b"OpusHead"):
                stream.opus = _opus_head(packet)
                if sequence != 0 or stream.packet_start_sequence != 0 or len(lacing) != 1 or granule != 0:
                    raise OggDemuxError("OpusHead must complete alone on its BOS page")
            elif stream.opus is not None and stream.packets == 1:
                if stream.packet_start_sequence != 1 or segment_index != len(lacing) - 1 or granule != 0:
                    raise OggDemuxError("Invalid OpusTags page placement")
                _opus_tags(packet)
                stream.tags_valid = completed_tags = True
            elif stream.opus is not None:
                if not packet or packet.startswith((b"OpusHead", b"OpusTags")):
                    raise OggDemuxError("Empty audio packet or repeated Opus header")
                stream.audio_packets += 1
                completed_audio += 1
            stream.packets += 1
        if stream.opus is not None:
            if sequence == 1 and stream.packets < 2 and not stream.continuing:
                raise OggDemuxError("Missing OpusTags on second page")
            if stream.continuing and completed_audio == 0 and not completed_tags and sequence != 0:
                if granule != NO_GRANULE:
                    raise OggDemuxError("Unfinished packet page must have unknown granule")
            if stream.tags_valid and not completed_tags:
                if completed_audio:
                    if granule == NO_GRANULE or granule >= 1 << 63:
                        raise OggDemuxError("Invalid Opus audio granule")
                    if stream.last_audio_granule is not None and granule < stream.last_audio_granule:
                        raise OggDemuxError("Opus audio granule moved backwards")
                    stream.last_audio_granule = granule
                elif granule != NO_GRANULE:
                    raise OggDemuxError("Page without completed audio has a granule")
        if flags & 4:
            if stream.continuing:
                raise OggContinuationError("EOS ends with an unfinished packet")
            stream.ended = True
            stream.final_granule = granule
        offset = end
    if not streams or any(not s.ended or s.continuing for s in streams.values()):
        raise OggDemuxError("Missing EOS or unfinished logical stream")
    opus = [s for s in streams.values() if s.opus is not None]
    if len(opus) != 1:
        raise AmbiguousOpusStreams("Require exactly one Opus logical stream")
    selected = opus[0]
    if (not selected.tags_valid or not selected.audio_packets or selected.final_granule is None
            or selected.final_granule == NO_GRANULE
            or selected.final_granule < selected.opus["preSkip"]):
        raise OggDemuxError("Incomplete Opus headers, audio or final granule")
    output = b"".join(selected.pages)
    metadata = {"logicalStreams": len(streams), "totalPages": page_count,
                "allPageCrcValid": True, "allStreamSequencesValid": True,
                "allStreamsEnded": True, "opusHeadValidated": True, "opusTagsValidated": True,
                "selectedStreamPages": len(selected.pages), "audioPackets": selected.audio_packets,
                "selectedBytes": len(output), "pagesVerbatim": True, "reencoded": False,
                "sourceModified": False, "decodedDurationVerified": False,
                **selected.opus, "lastGranule": selected.final_granule,
                "containerTimelineSeconds": (selected.final_granule - selected.opus["preSkip"]) / 48000,
                "inputSha256": hashlib.sha256(data).hexdigest(),
                "selectedSha256": hashlib.sha256(output).hexdigest()}
    return DemuxResult(output, metadata)


def demux_file(source: Path, target: Path) -> dict[str, Any]:
    """Read source only; validate completely before exclusive private target creation."""
    with source.open("rb") as input_file:
        info = os.fstat(input_file.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_INPUT_BYTES:
            raise OggDemuxError("Require a bounded regular source file")
        result = inspect_ogg(input_file.read(MAX_INPUT_BYTES + 1))
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(target, flags, 0o600)
    with os.fdopen(fd, "wb") as output_file:
        os.fchmod(output_file.fileno(), 0o600)
        output_file.write(result.data)
        output_file.flush()
        os.fsync(output_file.fileno())
    return result.metadata


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        print(json.dumps(demux_file(args.input, args.output), sort_keys=True))
    except Exception as error:
        print(f"Ogg selection stopped ({type(error).__name__}); content suppressed", file=sys.stderr)
        raise SystemExit(1) from None


if __name__ == "__main__":
    main()
