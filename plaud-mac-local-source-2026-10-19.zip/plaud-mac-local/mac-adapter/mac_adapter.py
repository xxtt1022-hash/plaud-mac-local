#!/usr/bin/env python3
"""Local, password-encrypted adapter for an already paired owner PLAUD identity.

No provisioning, cloud API, depair, reset, delete, or firmware update is exposed.
The upstream client is imported from a separately reviewed local source directory.
"""
from __future__ import annotations

import argparse
import asyncio
import base64
import getpass
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import sys
import tempfile
from typing import Any

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

ANDROID_AAD = b"plaud-pc-bootstrap-v1"
STORE_AAD = b"plaud-mac-adapter-v1"
RECIPIENT_FILE = "recipient-private.encrypted.json"
PUBLIC_FILE = "pc-bootstrap-public.pem"
IDENTITY_FILE = "device-identity.encrypted.json"
MAX_JSON_SIZE = 256 * 1024
SCRYPT = {"n": 2**15, "r": 8, "p": 1}


def b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def unb64(value: Any) -> bytes:
    if not isinstance(value, str):
        raise ValueError("Expected a base64 string")
    return base64.b64decode(value, validate=True)


def read_json(path: Path) -> dict[str, Any]:
    if path.stat().st_size > MAX_JSON_SIZE:
        raise ValueError("Credential JSON exceeds the local size limit")
    result = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(result, dict):
        raise ValueError("Expected a JSON object")
    return result


def private_dir(path: Path) -> None:
    if path.is_symlink():
        raise ValueError("State directory must not be a symlink")
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(path, 0o700)


def private_write(path: Path, data: bytes) -> None:
    """Write atomically, with private permissions from the first byte."""
    if path.is_symlink():
        raise ValueError("Output must not be a symlink")
    private_dir(path.parent)
    handle, name = tempfile.mkstemp(prefix=".adapter-", dir=path.parent)
    try:
        os.fchmod(handle, 0o600)
        with os.fdopen(handle, "wb") as output:
            output.write(data)
            output.flush()
            os.fsync(output.fileno())
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def seal(payload: dict[str, Any], password: str, purpose: str) -> dict[str, Any]:
    if len(password) < 20:
        raise ValueError("Use a passphrase of at least 20 characters")
    salt, nonce = os.urandom(16), os.urandom(12)
    key = Scrypt(salt=salt, length=32, **SCRYPT).derive(password.encode("utf-8"))
    aad = STORE_AAD + b":" + purpose.encode("ascii")
    ciphertext = AESGCM(key).encrypt(nonce, json.dumps(payload).encode("utf-8"), aad)
    return {"version": 1, "purpose": purpose, "cipher": "AES-256-GCM", "kdf": "scrypt",
            "scrypt": {**SCRYPT, "salt": b64(salt)}, "nonce": b64(nonce),
            "ciphertext": b64(ciphertext)}


def unseal(envelope: dict[str, Any], password: str, purpose: str) -> dict[str, Any]:
    if (envelope.get("version"), envelope.get("purpose"), envelope.get("cipher"), envelope.get("kdf")) != (
        1, purpose, "AES-256-GCM", "scrypt"
    ):
        raise ValueError("Unsupported encrypted store")
    params = envelope.get("scrypt") or {}
    if any(params.get(name) != value for name, value in SCRYPT.items()):
        raise ValueError("Unsupported scrypt parameters")
    salt, nonce = unb64(params.get("salt")), unb64(envelope.get("nonce"))
    if len(salt) != 16 or len(nonce) != 12:
        raise ValueError("Invalid store salt or nonce size")
    key = Scrypt(salt=salt, length=32, **SCRYPT).derive(password.encode("utf-8"))
    aad = STORE_AAD + b":" + purpose.encode("ascii")
    result = json.loads(AESGCM(key).decrypt(nonce, unb64(envelope.get("ciphertext")), aad))
    if not isinstance(result, dict):
        raise ValueError("Encrypted payload is not an object")
    return result


def initialize_recipient(state_dir: Path, password: str) -> Path:
    private_dir(state_dir)
    if any((state_dir / name).exists() for name in (RECIPIENT_FILE, PUBLIC_FILE, IDENTITY_FILE)):
        raise ValueError("State already exists; create a new empty state directory")
    key = rsa.generate_private_key(public_exponent=65537, key_size=3072)
    pem = key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                            serialization.NoEncryption()).decode("ascii")
    public = key.public_key().public_bytes(serialization.Encoding.PEM,
                                           serialization.PublicFormat.SubjectPublicKeyInfo)
    private_write(state_dir / RECIPIENT_FILE,
                  json.dumps(seal({"privatePem": pem}, password, "recipient-key")).encode("utf-8"))
    private_write(state_dir / PUBLIC_FILE, public)
    return state_dir / PUBLIC_FILE


def validate_identity(material: dict[str, Any], expected_sn: str, *,
                      allow_candidate: bool = False) -> dict[str, Any]:
    """Validate owner crypto; candidate identities require an explicit diagnostic opt-in."""
    if type(allow_candidate) is not bool:
        raise ValueError("Candidate permission must be an explicit boolean")
    if "verification" in material:
        verification = material["verification"]
        if verification not in ("candidate", "confirmed"):
            raise ValueError("Unknown identity verification state")
        if verification == "candidate" and not allow_candidate:
            raise ValueError("Candidate identity is not accepted by the confirmed owner store")
    required = ("sn", "signature", "bindToken", "rsaPublicKey", "rsaPrivateKey")
    if material.get("version") != 1 or any(
        not isinstance(material.get(name), str) or not material[name] for name in required
    ):
        raise ValueError("Incomplete owner identity")
    if material["sn"] != expected_sn:
        raise ValueError("Imported identity does not match the requested device")
    if len(unb64(material["signature"])) != 256:
        raise ValueError("Unexpected SN signature length")
    public = serialization.load_pem_public_key(material["rsaPublicKey"].encode("ascii"))
    private = serialization.load_pem_private_key(material["rsaPrivateKey"].encode("ascii"), None)
    if not isinstance(public, rsa.RSAPublicKey) or not isinstance(private, rsa.RSAPrivateKey):
        raise ValueError("Owner identity is not RSA")
    if private.key_size < 2048 or public.public_numbers() != private.public_key().public_numbers():
        raise ValueError("Owner RSA public/private identity does not match")
    # Persist only the defined fields; no access token or API credential is accepted.
    result = {"version": 1, **{name: material[name] for name in required}}
    if "verification" in material:
        result["verification"] = material["verification"]
    return result


def decrypt_android_package(envelope: dict[str, Any], recipient_pem: str,
                            expected_sn: str, *, allow_candidate: bool = False) -> dict[str, Any]:
    """Matches Android PcBootstrapExporter.kt, including MGF1 SHA-256 and AAD."""
    if (envelope.get("version"), envelope.get("keyWrap"), envelope.get("contentCipher")) != (
        1, "RSA-OAEP-SHA256-MGF1-SHA256", "AES-256-GCM"
    ):
        raise ValueError("Unsupported Android bootstrap envelope")
    recipient = serialization.load_pem_private_key(recipient_pem.encode("ascii"), None)
    if not isinstance(recipient, rsa.RSAPrivateKey) or recipient.key_size < 3072:
        raise ValueError("Recipient must be RSA-3072 or stronger")
    aes = recipient.decrypt(unb64(envelope.get("wrappedKey")), padding.OAEP(
        mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None))
    nonce = unb64(envelope.get("nonce"))
    if len(aes) != 32 or len(nonce) != 12:
        raise ValueError("Unexpected Android AES key or nonce size")
    material = json.loads(AESGCM(aes).decrypt(nonce, unb64(envelope.get("ciphertext")), ANDROID_AAD))
    if not isinstance(material, dict):
        raise ValueError("Bootstrap payload is not an object")
    return validate_identity(material, expected_sn, allow_candidate=allow_candidate)


def import_android(package: Path, state_dir: Path, password: str, sn: str) -> None:
    if (state_dir / IDENTITY_FILE).exists():
        raise ValueError("Refusing to replace an existing owner identity")
    key = unseal(read_json(state_dir / RECIPIENT_FILE), password, "recipient-key")
    material = decrypt_android_package(read_json(package), key["privatePem"], sn)
    private_write(state_dir / IDENTITY_FILE,
                  json.dumps(seal(material, password, "device-identity")).encode("utf-8"))


def load_identity(state_dir: Path, password: str, sn: str) -> dict[str, Any]:
    return validate_identity(unseal(read_json(state_dir / IDENTITY_FILE), password,
                                    "device-identity"), sn)


def attach_upstream(path: Path) -> None:
    source = path / "pc-bridge" / "src"
    if not (source / "plaud_pc" / "client.py").is_file():
        raise ValueError("Provide the local upstream repository root")
    sys.path.insert(0, str(source.resolve()))


def parse_notepro_advertisement(payload: bytes):
    """Parse legacy ASCII or the observed bounded Note Pro packed-serial layout.

    Packed layout: project marker 02 + LE881, 04/V/3-byte version, size08,
    8 raw serial bytes, one flag, LE portVersion20, seven trailing bytes (27 total).
    Unknown trailing flag semantics are not inferred. No localName fallback exists.
    """
    from plaud_pc.advertisement import PlaudAdvertisement, parse_manufacturer_data
    if not isinstance(payload, (bytes, bytearray)) or not 3 <= len(payload) <= 255:
        return None
    data = bytes(payload)
    index, header_project = 0, None
    if data[0] == 2:
        if len(data) < 4:
            return None
        header_project = int.from_bytes(data[1:3], "little")
        if header_project != 881:
            return None
        index = 3
    version_size = data[index]
    index += 1
    if not 2 <= version_size <= 5 or index + version_size >= len(data):
        return None
    if data[index] != ord("V"):
        return None
    version_code = int.from_bytes(data[index + 1:index + version_size], "little")
    index += version_size
    serial_size = data[index]
    index += 1
    if not 4 <= serial_size <= 64 or index + serial_size > len(data):
        return None
    raw_serial = data[index:index + serial_size]
    # Preserve the original ASCII path, but do not let errors='ignore' or sanitizing
    # manufacture a serial by dropping non-ASCII/control bytes from malformed input.
    try:
        ascii_serial = raw_serial.decode("ascii", errors="strict")
    except UnicodeDecodeError:
        ascii_serial = ""
    if re.fullmatch(r"881[A-Za-z0-9_-]{1,61}", ascii_serial):
        parsed = parse_manufacturer_data({0: data})
        if (parsed is not None and parsed.project_code == 881
                and parsed.serial_number == ascii_serial):
            return parsed
        return None
    # Binary serial support is deliberately limited to this model/protocol/layout.
    if header_project != 881 or version_size != 4 or serial_size != 8 or len(data) != 27:
        return None
    serial = raw_serial.hex().upper()
    if not serial.startswith("881"):
        return None
    port_version = int.from_bytes(data[18:20], "little")
    if port_version != 20:
        return None
    return PlaudAdvertisement(serial_number=serial, project_code=881,
                              version_name=f"V{version_code}", port_version=port_version)


def _serials_equal(left: str, right: str) -> bool:
    # Only hexadecimal 16-character serials have case-insensitive normalization.
    # Other legacy ASCII identifiers retain their complete original spelling.
    if re.fullmatch(r"[0-9A-Fa-f]{16}", left) and re.fullmatch(r"[0-9A-Fa-f]{16}", right):
        return left.upper() == right.upper()
    return left == right


def advertisement_matches(advertisement: Any, sn: str) -> bool:
    for company, value in advertisement.manufacturer_data.items():
        parsed = parse_notepro_advertisement(value)
        if parsed is not None and _serials_equal(parsed.serial_number, sn):
            return True
    return False


def paired_client(material: dict[str, Any]):
    """Only authenticate an identity already enrolled by an authorized SDK session."""
    from plaud_pc.client import PlaudBleClient
    from plaud_pc.protocol import (CMD_PRE_RSA, CMD_PRE_SIGNATURE_CONFIRM, ProtocolError,
                                    SessionCrypto, build_handshake_frame, signature_chunks)

    class PairedIdentityClient(PlaudBleClient):
        def _matches_device(self, candidate: Any, advertisement: Any) -> bool:
            return advertisement_matches(advertisement, str(self.material["sn"]))

        async def authenticate(self, client: Any) -> tuple[int, int]:
            for frame in signature_chunks(str(self.material["signature"])):
                await self._write(client, frame)
            acknowledgement = await self._wait_raw_command(
                {CMD_PRE_SIGNATURE_CONFIRM, CMD_PRE_RSA}, timeout=20.0)
            if struct.unpack_from("<H", acknowledgement)[0] == CMD_PRE_SIGNATURE_CONFIRM:
                raise ProtocolError("Device requests identity enrollment; stopped without registering a key")
            frames = await self._collect_rsa_response(acknowledgement)
            self._session = SessionCrypto.from_rsa_response(frames, str(self.material["rsaPrivateKey"]))
            handshake = build_handshake_frame(str(self.material["bindToken"]), port_version=20)
            await self._write(client, self._session.encrypt_body(handshake))
            command, payload = await self._wait_command(1, timeout=15.0)
            if not payload or payload[0] != 0:
                raise ProtocolError("Existing owner identity was rejected")
            return command, payload[1] if len(payload) > 1 else 0

    return PairedIdentityClient(material)


async def scan_target(sn: str, seconds: float) -> bool:
    from bleak import BleakScanner
    device = await BleakScanner.find_device_by_filter(
        lambda candidate, adv: advertisement_matches(adv, sn), timeout=seconds)
    # Do not print a device name/address/serial number.
    return device is not None


def main() -> None:
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init-recipient")
    init.add_argument("--state-dir", type=Path, required=True)
    imp = sub.add_parser("import-android")
    imp.add_argument("--state-dir", type=Path, required=True)
    imp.add_argument("--package", type=Path, required=True)
    imp.add_argument("--sn", required=True)
    for name in ("scan", "status", "download-latest", "decrypt"):
        item = sub.add_parser(name)
        item.add_argument("--upstream", type=Path, required=True)
        item.add_argument("--sn", required=True)
        item.add_argument("--scan-seconds", type=float, default=30.0)
        if name != "scan":
            item.add_argument("--state-dir", type=Path, required=True)
        if name == "download-latest":
            item.add_argument("--output-dir", type=Path, required=True)
        if name == "decrypt":
            item.add_argument("--input", type=Path, required=True)
            item.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        if args.command == "init-recipient":
            password = getpass.getpass("New local passphrase (20+ characters): ")
            if password != getpass.getpass("Repeat passphrase: "):
                raise ValueError("Passphrases do not match")
            public = initialize_recipient(args.state_dir, password)
            print(f"Recipient ready; public key only: {public.resolve()}")
            return
        if args.command == "import-android":
            password = getpass.getpass("Local passphrase: ")
            import_android(args.package, args.state_dir, password, args.sn)
            print("Owner identity imported into an encrypted local store")
            return
        attach_upstream(args.upstream)
        if args.command == "scan":
            print("Requested device found" if asyncio.run(scan_target(args.sn, args.scan_seconds))
                  else "Requested device not found")
            return
        material = load_identity(args.state_dir, getpass.getpass("Local passphrase: "), args.sn)
        if args.command == "decrypt":
            from plaud_pc.audio import decrypt_plaud_audio
            if args.output.exists():
                raise ValueError("Refusing to overwrite existing audio")
            private_dir(args.output.parent)
            header = decrypt_plaud_audio(args.input, args.output, material["rsaPrivateKey"])
            os.chmod(args.output, 0o600)
            print(json.dumps({"path": str(args.output.resolve()), "bytes": args.output.stat().st_size,
                              "headerVersion": header.version, "fileType": header.file_type,
                              "channels": header.channels, "duration": header.duration,
                              "encryptType": header.encrypt_type, "segment": header.segment,
                              "playbackVerified": False}))
            return
        client = paired_client(material)
        if args.command == "status":
            snapshot = asyncio.run(client.connect_read_only(args.scan_seconds))
            print(json.dumps({"batteryPercent": snapshot.battery_percent,
                              "freeBytes": snapshot.free_bytes, "totalBytes": snapshot.total_bytes,
                              "recordingCount": len(snapshot.files)}))
            return
        # A new destination avoids upstream's size-only acceptance of an already existing file.
        if args.output_dir.exists():
            raise ValueError("Use a new download directory for each acceptance attempt")
        private_dir(args.output_dir)
        snapshot, result = asyncio.run(client.connect_download_latest(args.output_dir, args.scan_seconds))
        os.chmod(result.path, 0o600)
        print(json.dumps({"path": str(result.path.resolve()), "bytes": result.path.stat().st_size,
                          "sha256": hashlib.sha256(result.path.read_bytes()).hexdigest(),
                          "recordingCountBefore": len(snapshot.files), "sourceDeleted": False,
                          "playbackVerified": False}))
    except Exception as error:
        # Cryptography and BLE exceptions can contain inputs. Keep credential payloads out of logs.
        print(f"Stopped safely ({type(error).__name__}); no credentials printed", file=sys.stderr)
        raise SystemExit(1) from None


if __name__ == "__main__":
    main()
