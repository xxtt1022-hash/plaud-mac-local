"""Observe an owned device's response to its official SN signature only.

Never requests RSA generation, sends a client public key, clears a device key,
performs CMD 1, or accesses recordings. Tokens and SN signatures stay in memory.
"""
from __future__ import annotations

import argparse
import asyncio
import base64
import json
import os
from pathlib import Path
import re
import ssl
import struct
import urllib.error
import urllib.request

from cloud_auth import OFFICIAL_BASE, _NoRedirect, authenticate_from_keychain
from mac_adapter import advertisement_matches
from plaud_pc.client import NOTIFY_UUID, WRITE_UUID
from plaud_pc.protocol import CMD_PRE_SIGNATURE, signature_chunks

SIGN_URL = OFFICIAL_BASE + "/open/partner/sdk/sn-sign"

class ProbeError(RuntimeError):
    pass

def official_signature(user_token: str, serial: str) -> str:
    request = urllib.request.Request(SIGN_URL, method="POST",
        data=json.dumps({"type": "notepro", "sn": serial}, separators=(",", ":")).encode(),
        headers={"Authorization": "Bearer " + user_token, "Content-Type": "application/json",
                 "Accept": "application/json", "User-Agent": "codex-plaud-local/0.1"})
    opener = urllib.request.build_opener(_NoRedirect(),
        urllib.request.HTTPSHandler(context=ssl.create_default_context()))
    try:
        with opener.open(request, timeout=30) as response:
            if response.geturl() != SIGN_URL:
                raise ProbeError("Unexpected signing response origin")
            raw = response.read(65537)
    except urllib.error.HTTPError as error:
        code = error.code
        error.close()
        raise ProbeError(f"Official SN signing returned HTTP {code}; stopped without fallback") from None
    except ProbeError:
        raise
    except Exception:
        raise ProbeError("Official SN signing transport failed") from None
    try:
        if len(raw) > 65536:
            raise ValueError()
        data = json.loads(raw)
        data = data.get("data", data)
        signature = data["signature"]
        if not isinstance(signature, str) or len(base64.b64decode(signature, validate=True)) != 256:
            raise ValueError()
        return signature
    except Exception:
        raise ProbeError("Unexpected official SN signing response") from None

async def observe_signature_only(client, signature: str, *, seconds: float = 12,
                                 verify_challenge=None) -> dict:
    queue = asyncio.Queue(maxsize=32)
    loop = asyncio.get_running_loop()
    first_write_at = None
    rsa_frames = {}
    rsa_count = None
    packets = signature_chunks(signature, force_clear=False)
    if len(packets) != 3 or any(struct.unpack_from("<H", frame)[0] != CMD_PRE_SIGNATURE for frame in packets):
        raise ProbeError("Unexpected signature packet sequence")
    result = {"sentCommand": 65040, "signatureFramesSent": 0, "responses": [],
              "clientPublicKeySent": False, "ownerHandshakeSent": False,
              "keyClearSent": False, "recordingCommandsSent": False}

    def notify(_, value):
        data = bytes(value)
        if 2 <= len(data) <= 2048 and not queue.full():
            queue.put_nowait((loop.time(), data))

    await client.start_notify(NOTIFY_UUID, notify)
    try:
        for frame in packets:
            # This is the only protocol write in this module.
            if first_write_at is None:
                first_write_at = loop.time()
            await client.write_gatt_char(WRITE_UUID, frame, response=True)
            result["signatureFramesSent"] += 1
            await asyncio.sleep(0.025)
        deadline = asyncio.get_running_loop().time() + seconds
        while len(result["responses"]) < 16:
            remaining = deadline - asyncio.get_running_loop().time()
            if remaining <= 0:
                break
            try:
                received_at, packet = await asyncio.wait_for(queue.get(), remaining)
            except asyncio.TimeoutError:
                break
            if received_at < first_write_at:
                continue
            command = struct.unpack_from("<H", packet)[0]
            if command not in {65041, 65042}:
                continue
            item = {"command": command, "bytes": len(packet),
                    "elapsedSinceFirstSignatureWriteMs": round((received_at - first_write_at) * 1000)}
            if command == 65042 and len(packet) >= 4:
                item.update({"chunkCount": packet[2], "chunkIndex": packet[3]})
                count, index = packet[2], packet[3]
                if not 1 <= count <= 16 or index >= count or (rsa_count is not None and count != rsa_count):
                    result["responseProtocolError"] = "invalid_or_changed_rsa_chunk_header"
                    break
                if index in rsa_frames and rsa_frames[index] != packet:
                    result["responseProtocolError"] = "inconsistent_duplicate_rsa_chunk"
                    break
                rsa_count = count
                rsa_frames[index] = packet
            elif command == 65041 and len(packet) == 3:
                item["confirmationByte"] = packet[2]
            result["responses"].append(item)
            if command == 65041:
                break  # Never answer a request for a client public key.
            if rsa_count is not None and len(rsa_frames) == rsa_count:
                result["completeRsaChallengeObserved"] = True
                if verify_challenge is not None:
                    try:
                        verified = verify_challenge([rsa_frames[i] for i in range(rsa_count)])
                        if type(verified) is not bool:
                            raise ProbeError("Challenge verifier must return a boolean")
                        result["candidateChallengeVerified"] = verified
                    except Exception as error:
                        result["candidateChallengeVerified"] = False
                        result["challengeVerificationErrorType"] = type(error).__name__
                break
        result["responseObserved"] = bool(result["responses"])
        return result
    finally:
        try:
            await client.stop_notify(NOTIFY_UUID)
        except Exception as error:
            result["notificationCleanupErrorType"] = type(error).__name__

async def probe(serial: str, signature: str, *, verify_challenge=None) -> dict:
    from bleak import BleakClient, BleakScanner
    device = await BleakScanner.find_device_by_filter(
        lambda candidate, adv: advertisement_matches(adv, serial), timeout=20)
    if device is None:
        return {"found": False, "deviceCommandsSent": False}
    async with BleakClient(device, timeout=15) as client:
        result = await observe_signature_only(client, signature, verify_challenge=verify_challenge)
    result.update({"found": True, "disconnectedAfterCheck": True})
    return result

def main():
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--config", type=Path)
    source.add_argument("--candidate-package", type=Path)
    parser.add_argument("--state-dir", type=Path)
    parser.add_argument("--sn", required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    if not re.fullmatch(r"881[0-9A-Fa-f]{13}", args.sn) or args.report.exists():
        raise SystemExit("Require a complete Note Pro serial and new report path")
    try:
        verify_challenge = None
        candidate_details = {}
        if args.candidate_package is not None:
            if args.state_dir is None:
                raise ProbeError("Candidate diagnostics require the existing receiver state")
            from candidate_diagnostic import load_candidate_in_memory
            from candidate_rsa_structure import rsa_pkcs1_structure_valid
            from plaud_pc.protocol import SessionCrypto
            material = load_candidate_in_memory(args.candidate_package, args.state_dir, args.sn.upper())
            signature = material["signature"]
            def verify_challenge(frames):
                # A boolean-only local check distinguishes invalid RSA structure from
                # OpenSSL's implicit-rejection output; it never replaces authentication.
                candidate_details["rsaPkcs1StructureValid"] = rsa_pkcs1_structure_valid(
                    frames, material["rsaPrivateKey"])
                session = SessionCrypto.from_rsa_response(frames, material["rsaPrivateKey"])
                del session
                return True
        else:
            config = json.loads(args.config.read_text())
            tokens = authenticate_from_keychain(config["clientId"], config["stableUserId"], base_url=config["baseUrl"])
            signature = official_signature(tokens.user_access_token, args.sn.upper())
            del tokens
        result = asyncio.run(probe(args.sn.upper(), signature, verify_challenge=verify_challenge))
        if args.candidate_package is not None:
            result.update({"sourceVerification": "candidate", "confirmedOwnerStoreWritten": False,
                           **candidate_details})
            del material
        del signature
        with args.report.open("x") as report:
            report.write(json.dumps(result, indent=2) + "\n")
        args.report.chmod(0o600)
        print(json.dumps(result))
    except Exception as error:
        # No raw HTTP body, headers, signature, token, or crypto bytes in diagnostics.
        message = str(error) if isinstance(error, ProbeError) else type(error).__name__
        print("Signature-only probe stopped: " + message)
        raise SystemExit(1) from None

if __name__ == "__main__":
    main()
