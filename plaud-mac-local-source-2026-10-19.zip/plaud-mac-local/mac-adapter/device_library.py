"""Explicit, local recording-library operations on one confirmed Note Pro.

Importing this module does not access Keychain, BLE or audio. There is no cloud,
enrollment, key generation, deletion, rebind, recovery, background download or player.
Errors returned to a UI contain a stage/type only; partial local artifacts remain.
"""
from __future__ import annotations

from contextlib import asynccontextmanager
import asyncio
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import secrets
import stat
import sys
import wave
from typing import Any

import mac_adapter
import receiver_state

DOWNLOAD_TIMEOUT_SECONDS = 120
DECODE_TIMEOUT_SECONDS = 120
MAX_DOWNLOAD_BYTES = 128 * 1024 * 1024
NOTIFY_UUID = "00002bb0-0000-1000-8000-00805f9b34fb"
# Give only the child a private umask; never change a UI server's process-wide umask.
_PRIVATE_EXEC = "import os,sys; os.umask(0o077); os.execv(sys.argv[1],sys.argv[1:])"


class DeviceLibraryError(RuntimeError):
    pass


class UnsupportedPlaudProfile(DeviceLibraryError):
    pass


class TargetRecordingChanged(DeviceLibraryError):
    pass


def _scan_timeout(value: float) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 < value <= 30:
        raise DeviceLibraryError("Invalid scan timeout")
    return float(value)


def _bounded_int(value: int, minimum: int, maximum: int) -> int:
    if type(value) is not int or not minimum <= value <= maximum:
        raise DeviceLibraryError("Invalid integer selection")
    return value


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _new_private_file(path: Path) -> int:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
    os.fchmod(fd, 0o600)
    return fd


def _reserve_private(path: Path) -> None:
    os.close(_new_private_file(path))


def _file_metadata(path: Path, role: str) -> dict[str, Any]:
    info = path.stat()
    if path.is_symlink() or not stat.S_ISREG(info.st_mode):
        raise DeviceLibraryError("Require a regular local artifact")
    digest = hashlib.sha256()
    with path.open("rb") as source:
        while chunk := source.read(1024 * 1024):
            digest.update(chunk)
    return {"role": role, "path": str(path.resolve()), "size": info.st_size, "sha256": digest.hexdigest()}


def _snapshot_dict(snapshot, sn: str) -> dict[str, Any]:
    return {"ok": True, "sn": sn, "observedAt": _utc_now(), "snapshotSource": "live",
            "batteryPercent": snapshot.battery_percent, "charging": snapshot.charging,
            "freeBytes": snapshot.free_bytes, "totalBytes": snapshot.total_bytes,
            "files": [{"sessionId": item.session_id, "size": item.size, "scene": item.scene,
                       "marked": item.marked} for item in snapshot.files]}


def _exact_recording(snapshot, session_id: int, size: int):
    matches = [item for item in snapshot.files if item.session_id == session_id]
    if len(matches) != 1 or matches[0].size != size:
        raise TargetRecordingChanged("Selected recording does not match the live snapshot")
    return matches[0]


def _validated_header(raw: Path):
    from plaud_pc.audio import PlaudAudioHeader
    with raw.open("rb") as source:
        header = PlaudAudioHeader.parse(source.read(512))
    # Only the profile accepted in this task is supported. No assertion uses user_id,
    # header duration, byte-size estimates or assumed 80-byte Opus framing.
    if (header.version != 1 or header.header_size != 512 or header.counter != 0 or header.segment != 0
            or header.channels != 1 or header.file_type != 1 or header.encrypt_type != 1):
        raise UnsupportedPlaudProfile("Unsupported encrypted recording profile")
    return header


def _decode_arguments(ffmpeg: str, audio: Path, wav: Path) -> list[str]:
    return [sys.executable, "-c", _PRIVATE_EXEC, ffmpeg, "-nostdin", "-n", "-v", "error",
            "-xerror", "-err_detect", "explode", "-protocol_whitelist", "file,pipe", "-i", str(audio),
            "-map", "0:a:0", "-map_metadata", "-1", "-c:a", "pcm_s16le", str(wav)]


async def _decode_wav(audio: Path, wav: Path) -> dict[str, Any]:
    import imageio_ffmpeg
    binary = Path(imageio_ffmpeg.get_ffmpeg_exe())
    if not binary.is_absolute() or not binary.is_file() or wav.exists() or wav.is_symlink():
        raise DeviceLibraryError("Require a local decoder and a new WAV path")
    process = await asyncio.create_subprocess_exec(*_decode_arguments(str(binary), audio, wav),
        stdin=asyncio.subprocess.DEVNULL, stdout=asyncio.subprocess.DEVNULL,
        stderr=asyncio.subprocess.DEVNULL)
    try:
        await asyncio.wait_for(process.wait(), DECODE_TIMEOUT_SECONDS)
    except BaseException:
        try:
            process.kill()
        except ProcessLookupError:
            pass
        try:
            await asyncio.wait_for(process.wait(), 5)
        except Exception:
            pass
        raise
    if process.returncode != 0:
        raise DeviceLibraryError("Full-file decoder failed")
    os.chmod(wav, 0o600)
    with wave.open(str(wav), "rb") as source:
        rate, channels, frames, width = source.getframerate(), source.getnchannels(), source.getnframes(), source.getsampwidth()
        if source.getcomptype() != "NONE" or channels != 1 or width != 2 or rate <= 0 or frames <= 0:
            raise DeviceLibraryError("Unsupported decoded WAV")
        actual_bytes = 0
        while chunk := source.readframes(65536):
            actual_bytes += len(chunk)
        if actual_bytes != frames * channels * width:
            raise DeviceLibraryError("Incomplete decoded WAV")
    return {"durationSeconds": frames / rate, "sampleRate": rate, "channels": channels,
            "sampleWidthBytes": width, "decodedFrames": frames, "decodeVerified": True}


class DeviceLibrary:
    def __init__(self, upstream: Path, state_dir: Path, sn: str, download_root: Path):
        if not isinstance(sn, str) or re.fullmatch(r"881[0-9A-Fa-f]{13}", sn) is None:
            raise DeviceLibraryError("Require the complete Note Pro serial")
        self.upstream, self.state_dir = Path(upstream), Path(state_dir)
        self.sn, self.download_root = sn.upper(), Path(download_root)
        self._lock = asyncio.Lock()

    def _confirmed_owner(self) -> dict[str, Any]:
        material = receiver_state.load_device_identity(self.state_dir, self.sn)
        if material.get("verification") != "confirmed":
            raise DeviceLibraryError("Only a confirmed owner identity is accepted")
        return mac_adapter.validate_identity(material, self.sn)

    @asynccontextmanager
    async def _connected(self, material: dict[str, Any], scan_seconds: float, transport: dict[str, Any]):
        from bleak import BleakClient, BleakScanner
        mac_adapter.attach_upstream(self.upstream)
        bridge = mac_adapter.paired_client(material)
        bridge._notifications = asyncio.Queue(maxsize=512)
        notification_fault = False
        loop = asyncio.get_running_loop()
        def push(packet):
            nonlocal notification_fault
            if notification_fault:
                return
            try:
                if packet is None or not 2 <= len(packet) <= 2048:
                    raise DeviceLibraryError()
                bridge._notifications.put_nowait(packet)
            except Exception:
                notification_fault = True
        def on_notification(_sender, value):
            try:
                packet = bytes(value)
            except Exception:
                packet = None
            try:
                loop.call_soon_threadsafe(push, packet)
            except RuntimeError:
                pass  # Transport cleanup can race the final late notification.
        def check_notifications():
            if notification_fault:
                raise DeviceLibraryError("Notification stream exceeded supported bounds")
        device = await asyncio.wait_for(BleakScanner.find_device_by_filter(
            lambda candidate, adv: mac_adapter.advertisement_matches(adv, self.sn), timeout=scan_seconds),
            scan_seconds + 1)
        if device is None:
            raise DeviceLibraryError("Selected device was not found")
        connection = BleakClient(device, timeout=15)
        transport["connectionAttempts"] = 1
        notifying = False
        try:
            await asyncio.wait_for(connection.connect(), 16)
            notifying = True
            await asyncio.wait_for(connection.start_notify(NOTIFY_UUID, on_notification), 5)
            _, port_version = await asyncio.wait_for(bridge.authenticate(connection), 30)
            check_notifications()
            if port_version != 20:
                raise DeviceLibraryError("Unsupported authenticated port version")
            yield bridge, connection, port_version, check_notifications
        finally:
            if notifying:
                try:
                    await asyncio.wait_for(connection.stop_notify(NOTIFY_UUID), 5)
                except Exception as error:
                    transport["notificationCleanupErrorType"] = type(error).__name__
            try:
                await asyncio.wait_for(connection.disconnect(), 10)
                transport["disconnectedAfterCheck"] = True
            except Exception as error:
                transport["disconnectErrorType"] = type(error).__name__

    async def refresh(self, scan_seconds: float = 15) -> dict[str, Any]:
        async with self._lock:
            stage, transport = "validate", {"connectionAttempts": 0, "disconnectedAfterCheck": False}
            try:
                scan_seconds = _scan_timeout(scan_seconds)
                stage = "load_confirmed_owner"
                material = self._confirmed_owner()
                stage = "connect_and_authenticate"
                async with self._connected(material, scan_seconds, transport) as (bridge, connection, _, check):
                    stage = "read_snapshot"
                    snapshot = await asyncio.wait_for(bridge.read_snapshot(connection, "Note Pro"), 25)
                    check()
                    result = _snapshot_dict(snapshot, self.sn)
                result["transport"] = transport
                return result
            except Exception as error:
                return {"ok": False, "snapshotSource": "unavailable", "stage": stage,
                        "errorType": type(error).__name__, "transport": transport}

    def _new_session_directory(self, session_id: int) -> Path:
        root = self.download_root
        if root.is_symlink():
            raise DeviceLibraryError("Download root must not be a symlink")
        root.mkdir(parents=True, exist_ok=True, mode=0o700)
        if not root.is_dir():
            raise DeviceLibraryError("Download root must be a directory")
        target = root / f"session-{session_id}-{secrets.token_hex(8)}"
        target.mkdir(mode=0o700)  # exclusive; never resume or reuse a previous attempt
        os.chmod(target, 0o700)
        return target

    async def download(self, session_id: int, expected_size: int, scan_seconds: float = 15) -> dict[str, Any]:
        async with self._lock:
            stage, directory, report_fd = "validate", None, None
            result: dict[str, Any] = {"ok": False, "decodeVerified": False, "sourceRetained": False,
                "files": [], "transport": {"connectionAttempts": 0, "disconnectedAfterCheck": False,
                    "tailCrcReceived": None, "tailCrcVerified": False,
                    "tailCrcVerification": "received_only_not_independently_recomputed"}}
            try:
                _bounded_int(session_id, 0, 0xFFFFFFFF)
                _bounded_int(expected_size, 1, MAX_DOWNLOAD_BYTES)
                scan_seconds = _scan_timeout(scan_seconds)
                result.update(sessionId=session_id, expectedSize=expected_size)
                stage = "load_confirmed_owner"
                material = self._confirmed_owner()
                stage = "create_private_destination"
                directory = self._new_session_directory(session_id)
                result["outputDirectory"] = str(directory.resolve())
                report_fd = _new_private_file(directory / "report.json")
                raw = directory / f"{session_id}.plaud"
                _reserve_private(raw.with_suffix(".plaud.part"))
                stage = "connect_and_authenticate"
                async with self._connected(material, scan_seconds, result["transport"]) as (bridge, connection, port, check):
                    stage = "verify_live_selection"
                    before = await asyncio.wait_for(bridge.read_snapshot(connection, "Note Pro"), 25)
                    check()
                    selected = _exact_recording(before, session_id, expected_size)
                    stage = "download"
                    received = await asyncio.wait_for(bridge.download_file(connection, selected, directory,
                        port_version=port), DOWNLOAD_TIMEOUT_SECONDS)
                    check()
                    if (Path(received.path).resolve() != raw.resolve() or received.file.session_id != session_id
                            or received.file.size != expected_size or raw.stat().st_size != expected_size):
                        raise TargetRecordingChanged("Downloaded file differs from selected recording")
                    os.chmod(raw, 0o600)
                    result["files"].append(_file_metadata(raw, "raw"))
                    _bounded_int(received.crc, 0, 0xFFFF)
                    result["transport"]["tailCrcReceived"] = received.crc
                    stage = "verify_source_retained"
                    after = await asyncio.wait_for(bridge.read_snapshot(connection, "Note Pro"), 25)
                    check()
                    _exact_recording(after, session_id, expected_size)
                    result["sourceRetained"] = True
                stage = "validate_audio_profile"
                header = _validated_header(raw)
                result["audioProfile"] = {"headerSize": header.header_size, "counter": header.counter,
                    "segment": header.segment, "channels": header.channels,
                    "fileType": header.file_type, "encryptType": header.encrypt_type}
                stage = "decrypt"
                from plaud_pc.audio import decrypt_plaud_audio
                decrypted = directory / "decrypted-mux.ogg"
                _reserve_private(decrypted.with_suffix(".ogg.part"))
                decrypt_plaud_audio(raw, decrypted, material["rsaPrivateKey"])
                os.chmod(decrypted, 0o600)
                stage = "validate_and_select_ogg"
                from ogg_demux import demux_file
                audio, wav = directory / "selected-opus.ogg", directory / "decoded.wav"
                result["ogg"] = demux_file(decrypted, audio)
                result["files"].append(_file_metadata(audio, "audio"))
                stage = "decode_complete_file"
                result.update(await _decode_wav(audio, wav))
                result["files"].append(_file_metadata(wav, "wav"))
                result.update(ok=True, stage="complete", completedAt=_utc_now())
            except Exception as error:
                result.update(ok=False, decodeVerified=False, stage=stage, errorType=type(error).__name__)
            finally:
                if directory is not None:
                    # Inventory names/sizes only, never encrypted owner material or audio bytes.
                    try:
                        result["retainedLocalArtifacts"] = [{"name": p.name, "size": p.stat().st_size}
                            for p in directory.iterdir() if p.name != "report.json" and p.is_file() and not p.is_symlink()]
                    except Exception as error:
                        result["artifactInventoryErrorType"] = type(error).__name__
                result.setdefault("stage", stage)
                if report_fd is not None:
                    try:
                        with os.fdopen(report_fd, "wb") as report:
                            report.write((json.dumps(result, sort_keys=True, indent=2) + "\n").encode())
                            report.flush()
                            os.fsync(report.fileno())
                    except Exception as error:
                        result.update(ok=False, stage="write_report", errorType=type(error).__name__)
            return result
