#!/usr/bin/env python3
"""Show a short-lived user token as an in-memory QR on loopback only.

No plaintext token, credential, or QR image is written to disk or stdout.
The URL file contains only a temporary loopback capability, not the token.
"""
from __future__ import annotations

import argparse
from http.server import BaseHTTPRequestHandler, HTTPServer
from io import BytesIO
import json
import os
from pathlib import Path
import secrets
import time

from cloud_auth import authenticate_from_keychain


class TokenView(HTTPServer):
    def __init__(self, png: bytes, ttl: int = 600):
        if type(ttl) is not int or not 1 <= ttl <= 600:
            raise ValueError("Token view TTL must be an integer from 1 to 600 seconds")
        self.png = png
        self.path = "/" + secrets.token_urlsafe(32)
        self.deadline = time.monotonic() + ttl
        super().__init__(("127.0.0.1", 0), TokenHandler)
        self.timeout = 1

    def get_request(self):
        connection, address = super().get_request()
        # Server.timeout covers accept only. Bound a client that sends incomplete headers,
        # so it cannot hold this temporary service open indefinitely past its deadline.
        connection.settimeout(2)
        return connection, address

    def server_close(self):
        self.png = b""
        super().server_close()


class TokenHandler(BaseHTTPRequestHandler):
    server: TokenView

    def log_message(self, *_):
        pass

    def do_GET(self):
        expected_host = f"127.0.0.1:{self.server.server_port}"
        if self.headers.get_all("Host", []) != [expected_host]:
            self.send_error(403)
            return
        if time.monotonic() >= self.server.deadline:
            self.send_error(410)
            return
        if self.path == self.server.path:
            body = ("<!doctype html><html lang=zh-CN><meta charset=utf-8>"
                    "<title>PLAUD 短期授权</title><body style='font:20px system-ui;text-align:center'>"
                    "<h1>PLAUD 引导 App 的短期令牌</h1>"
                    "<p>请用华为手机扫码，复制识别出的文字，再粘贴到引导 App 的令牌输入框。</p>"
                    "<p>二维码只在本机内存中生成。本页面十分钟后关闭，请勿截图或转发。</p>"
                    f"<img alt='短期授权二维码' width=640 height=640 src='{self.server.path}/qr.png'>"
                    "</body></html>").encode()
            kind = "text/html; charset=utf-8"
        elif self.path == self.server.path + "/qr.png":
            body, kind = self.server.png, "image/png"
        else:
            self.send_error(404)
            return
        self.send_response(200)
        self.send_header("Content-Type", kind)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'; frame-ancestors 'none'")
        self.end_headers()
        self.wfile.write(body)


def qr_png(token: str) -> bytes:
    import qrcode
    qr = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_L, box_size=10, border=4)
    qr.add_data(token)
    qr.make(fit=True)
    buffer = BytesIO()
    qr.make_image(fill_color="black", back_color="white").save(buffer, format="PNG")
    return buffer.getvalue()


def main():
    os.umask(0o077)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--url-file", type=Path, required=True)
    args = parser.parse_args()
    if args.url_file.exists():
        raise SystemExit("Refusing to overwrite a token-view URL file")
    try:
        config = json.loads(args.config.read_text())
        tokens = authenticate_from_keychain(config["clientId"], config["stableUserId"], base_url=config["baseUrl"])
        png = qr_png(tokens.user_access_token)
        del tokens
        with TokenView(png) as server:
            args.url_file.parent.mkdir(parents=True, exist_ok=True)
            with args.url_file.open("x") as out:
                out.write(f"http://127.0.0.1:{server.server_port}{server.path}\n")
            print("Local token QR is ready for ten minutes; token values suppressed", flush=True)
            while time.monotonic() < server.deadline:
                server.handle_request()
            server.png = b""
            print("Local token QR session expired", flush=True)
    except KeyboardInterrupt:
        print("Local token QR session closed")
    except Exception as error:
        print(f"Token view stopped ({type(error).__name__}); credentials suppressed")
        raise SystemExit(1) from None


if __name__ == "__main__":
    main()
