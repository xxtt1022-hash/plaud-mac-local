#!/usr/bin/env python3
"""Single-attempt Note Pro candidate handshake; observation is the default.

Only --enroll-if-requested permits sending the existing candidate public key or
CMD 1. This does not authorize clearing an existing key/binding. The supported
enrollment-request format is exactly [65041:u16 LE][0:u8]. The third byte is a
local restrictive format gate, NOT an officially established success status:
the pinned SDK checks only the opcode. Neither that request nor an RSA response
confirms binding. Only the exact authenticated PLAUD.AI challenge followed by an
authenticated CMD 1 status 0 sets handshakeAccepted.

No API, key generation, signature refresh, retry, recovery, reset, depair, audio
command, confirmed-store write or cloud bind is implemented here. The CLI reads
the existing encrypted candidate using load_candidate_in_memory (which accesses
the existing receiver passphrase); importing this module performs no such read.
"""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import math
import os
from pathlib import Path
import re
import struct
import sys
from typing import Any

from cryptography.hazmat.primitives import serialization

from candidate_diagnostic import load_candidate_in_memory
from mac_adapter import advertisement_matches, attach_upstream, unb64, validate_identity

# Reviewed upstream 4f52d432b2f4d838ef10c7674d6b49f9bafc7005, unmodified protocol.py.
PINNED_PROTOCOL_SHA256 = "5820540388778c8aed1150500410fae1a0d8825698c576e5e1529ec39bc19b56"
NOTIFY_UUID = "00002bb0-0000-1000-8000-00805f9b34fb"
WRITE_UUID = "00002bb1-0000-1000-8000-00805f9b34fb"
MAX_NOTIFICATIONS = 64
MAX_PACKET_BYTES = 512
MAX_RSA_CHUNKS = 3
RSA_BYTES = 256


class FirstPairError(RuntimeError):
    pass


class UnsupportedEnrollmentRequest(FirstPairError):
    pass


class InvalidFrame(FirstPairError):
    pass


class ConflictingChunk(InvalidFrame):
    pass


class NotificationOverflow(FirstPairError):
    pass


class UnexpectedResponse(FirstPairError):
    pass


class HandshakeRejected(FirstPairError):
    pass


def _protocol():
    # Check the actually imported file, not an unrelated checkout supplied by the caller.
    import plaud_pc.protocol as protocol
    if hashlib.sha256(Path(protocol.__file__).read_bytes()).hexdigest() != PINNED_PROTOCOL_SHA256:
        raise FirstPairError("Unreviewed upstream protocol")
    return protocol


def _new_report(enroll: bool) -> dict[str, Any]:
    return {"sourceVerification": "candidate", "enrollIfRequested": enroll,
            "outcome": "not_started", "phases": [], "responses": [],
            "signatureFramesSent": 0, "publicKeyFramesSent": 0,
            "supportedEnrollmentRequest": False, "confirmationByte": None,
            "clientPublicKeyWriteAttempted": False, "clientPublicKeySent": False,
            "challengeVerified": False, "ownerHandshakeWriteAttempted": False, "ownerHandshakeSent": False,
            "handshakeAccepted": False, "handshakeStatus": None, "portVersion": None,
            "keyClearSent": False, "recordingCommandsSent": False,
            "confirmedOwnerStoreWritten": False, "cloudBindAttempted": False}


def _phase(report: dict[str, Any], value: str) -> None:
    if len(report["phases"]) >= 12:
        raise FirstPairError("Phase limit")
    report["phases"].append(value)


def _bounded_seconds(value: float, maximum: float) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 < value <= maximum:
        raise FirstPairError("Invalid timeout")
    return float(value)


def _candidate(material: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(material, dict) or material.get("verification") != "candidate":
        raise FirstPairError("Explicit candidate required")
    value = validate_identity(material, material.get("sn"), allow_candidate=True)
    if not re.fullmatch(r"881[0-9A-Fa-f]{13}", value["sn"]):
        raise FirstPairError("Complete Note Pro serial required")
    if not re.fullmatch(r"[A-Za-z0-9]{32}", value["bindToken"]):
        raise FirstPairError("Exact handshake token required")
    private = serialization.load_pem_private_key(value["rsaPrivateKey"].encode("ascii"), None)
    # This tool is deliberately limited to the audited/observed RSA-2048 profile.
    if private.key_size != RSA_BYTES * 8:
        raise FirstPairError("Unsupported RSA profile")
    return value


def _outbound_chunks(frames: list[bytes], command: int, expected: bytes) -> list[bytes]:
    count = math.ceil(len(expected) / 100)
    if command not in (65040, 65042) or not 1 <= count <= 16 or len(frames) != count:
        raise InvalidFrame("Invalid outgoing frame set")
    for index, frame in enumerate(frames):
        wanted = struct.pack("<HBB", command, count, index) + expected[index * 100:(index + 1) * 100]
        if not isinstance(frame, bytes) or frame != wanted:
            raise InvalidFrame("Unexpected outgoing protocol frame")
    return frames


class _Receiver:
    def __init__(self) -> None:
        self.queue: asyncio.Queue[tuple[float, bytes] | None] = asyncio.Queue(maxsize=32)
        self.loop = asyncio.get_running_loop()
        self.fault: type[Exception] | None = None
        self.count = 0
        self.first_write_at: float | None = None

    def callback(self, _sender, value) -> None:
        received_at = self.loop.time()
        try:
            packet = bytes(value)
        except Exception:
            self.loop.call_soon_threadsafe(self.fail, InvalidFrame)
            return
        self.loop.call_soon_threadsafe(self.push, received_at, packet)

    def fail(self, kind: type[Exception]) -> None:
        self.fault = self.fault or kind
        if not self.queue.full():
            self.queue.put_nowait(None)

    def push(self, received_at: float, packet: bytes) -> None:
        self.count += 1
        if self.count > MAX_NOTIFICATIONS or self.queue.full():
            self.fail(NotificationOverflow)
        elif not 2 <= len(packet) <= MAX_PACKET_BYTES:
            self.fail(InvalidFrame)
        else:
            self.queue.put_nowait((received_at, packet))

    def check(self) -> None:
        if self.fault is not None:
            raise self.fault()

    async def get(self, deadline: float) -> bytes:
        while True:
            self.check()
            remaining = deadline - self.loop.time()
            if remaining <= 0:
                raise TimeoutError()
            item = await asyncio.wait_for(self.queue.get(), remaining)
            self.check()
            if item is not None and self.first_write_at is not None and item[0] >= self.first_write_at:
                return item[1]


class _RsaCollector:
    """Bounded RSA-2048 response: exactly 3 chunks of 100, 100 and 56 bytes."""
    def __init__(self) -> None:
        self.frames: dict[int, bytes] = {}

    def add(self, packet: bytes) -> None:
        if len(packet) < 4:
            raise InvalidFrame()
        command, count, index = struct.unpack_from("<HBB", packet)
        if command != 65042 or count != MAX_RSA_CHUNKS or index >= count:
            raise InvalidFrame()
        if len(packet) != 4 + min(100, RSA_BYTES - index * 100):
            raise InvalidFrame()
        if index in self.frames and self.frames[index] != packet:
            raise ConflictingChunk()
        self.frames[index] = packet

    @property
    def complete(self) -> bool:
        return len(self.frames) == MAX_RSA_CHUNKS

    def ordered(self) -> list[bytes]:
        if not self.complete:
            raise InvalidFrame()
        return [self.frames[i] for i in range(MAX_RSA_CHUNKS)]


async def first_pair(client, material: dict[str, Any], *, enroll_if_requested: bool = False,
                     response_seconds: float = 12.0, write_seconds: float = 5.0,
                     total_seconds: float = 45.0) -> dict[str, Any]:
    """One handshake on an already connected GATT client; never disconnects it.

    Exceptions become errorType only. Cancellation propagates after notify cleanup.
    The caller must disconnect normally. No store or cloud side effect occurs here.
    """
    report = _new_report(enroll_if_requested is True)
    receiver = _Receiver()
    notify_attempted = False
    try:
        if type(enroll_if_requested) is not bool:
            raise FirstPairError()
        response_seconds = _bounded_seconds(response_seconds, 30)
        write_seconds = _bounded_seconds(write_seconds, 10)
        total_seconds = _bounded_seconds(total_seconds, 120)
        value = _candidate(material)
        protocol = _protocol()
        signature = _outbound_chunks(protocol.signature_chunks(value["signature"], force_clear=False),
                                     65040, unb64(value["signature"]))

        async def write(packet: bytes) -> None:
            receiver.check()
            if receiver.first_write_at is None:
                receiver.first_write_at = receiver.loop.time()
            await asyncio.wait_for(client.write_gatt_char(WRITE_UUID, packet, response=True), write_seconds)
            await asyncio.sleep(0.025)
            receiver.check()

        def record(packet: bytes) -> None:
            if len(report["responses"]) >= MAX_NOTIFICATIONS:
                raise NotificationOverflow()
            command = struct.unpack_from("<H", packet)[0]
            item = {"command": command, "bytes": len(packet)}
            if command == 65042 and len(packet) >= 4:
                item.update(chunkCount=packet[2], chunkIndex=packet[3])
            report["responses"].append(item)

        async def flow() -> None:
            nonlocal notify_attempted
            notify_attempted = True
            await asyncio.wait_for(client.start_notify(NOTIFY_UUID, receiver.callback), write_seconds)
            _phase(report, "sending_signature")
            for packet in signature:
                await write(packet)
                report["signatureFramesSent"] += 1
            _phase(report, "awaiting_prehandshake_response")
            deadline = receiver.loop.time() + response_seconds
            packet = await receiver.get(deadline)
            record(packet)
            command = struct.unpack_from("<H", packet)[0]
            if command == 65041:
                _phase(report, "enrollment_request_observed")
                if len(packet) >= 3:
                    report["confirmationByte"] = packet[2]
                # Supported local format, not a claim that byte 0 is an official success code.
                report["supportedEnrollmentRequest"] = packet == struct.pack("<HB", 65041, 0)
                if not report["supportedEnrollmentRequest"]:
                    raise UnsupportedEnrollmentRequest()
                if not enroll_if_requested:
                    report["outcome"] = "enrollment_request_observed_only"
                    return
                public = _outbound_chunks(protocol.rsa_public_key_chunks(value["rsaPublicKey"]),
                                          65042, value["rsaPublicKey"].encode("ascii"))
                _phase(report, "sending_candidate_public_key")
                report["clientPublicKeyWriteAttempted"] = True
                for part in public:
                    await write(part)
                    report["publicKeyFramesSent"] += 1
                report["clientPublicKeySent"] = True
                deadline = receiver.loop.time() + response_seconds
                packet = await receiver.get(deadline)
                record(packet)
            elif command != 65042:
                raise UnexpectedResponse()

            collector = _RsaCollector()
            _phase(report, "collecting_rsa_challenge")
            while True:
                collector.add(packet)
                if collector.complete:
                    break
                packet = await receiver.get(deadline)
                record(packet)
            frames = collector.ordered()
            session = protocol.SessionCrypto.from_rsa_response(frames, value["rsaPrivateKey"])
            report["challengeVerified"] = True
            _phase(report, "challenge_verified")
            if not enroll_if_requested:
                report["outcome"] = "challenge_verified_observe_only"
                return
            body = protocol.build_handshake_frame(value["bindToken"], port_version=20)
            # A hard final boundary prevents an upstream helper from producing an audio/clear command.
            if body != struct.pack("<BHBBB", 1, 1, 2, 1, 0) + value["bindToken"].encode("ascii"):
                raise InvalidFrame()
            _phase(report, "sending_owner_handshake")
            report["ownerHandshakeWriteAttempted"] = True
            await write(session.encrypt_body(body))
            report["ownerHandshakeSent"] = True
            deadline = receiver.loop.time() + response_seconds
            while True:
                packet = await receiver.get(deadline)
                # The SDK can retransmit final raw RSA chunks. Only byte-identical already
                # validated chunks are tolerated, within the same packet/time bounds.
                if packet in frames:
                    record(packet)
                    continue
                _, response_command, payload = session.decrypt_command(packet)
                if response_command != 1 or not 1 <= len(payload) <= 64:
                    raise UnexpectedResponse()
                report["handshakeStatus"] = payload[0]
                if len(payload) >= 2:
                    report["portVersion"] = payload[1]
                if payload[0] != 0:
                    raise HandshakeRejected()
                report["handshakeAccepted"] = True
                report["outcome"] = "handshake_accepted"
                _phase(report, "handshake_accepted")
                return

        await asyncio.wait_for(flow(), total_seconds)
    except Exception as error:
        report["outcome"] = "stopped"
        report["errorType"] = type(error).__name__
    finally:
        if notify_attempted:
            try:
                await asyncio.wait_for(client.stop_notify(NOTIFY_UUID), 5.0)
            except Exception as error:
                report["notificationCleanupErrorType"] = type(error).__name__
        report["notificationsReceived"] = receiver.count
    return report


async def pair_candidate(serial: str, material: dict[str, Any], *, enroll_if_requested: bool = False,
                         scan_seconds: float = 20.0, response_seconds: float = 12.0,
                         write_seconds: float = 5.0, total_seconds: float = 45.0) -> dict[str, Any]:
    """Exact full-SN advertisement match, one connection, bounded normal disconnect."""
    report = _new_report(enroll_if_requested is True)
    report.update(found=False, disconnectedAfterCheck=False)
    try:
        if type(enroll_if_requested) is not bool:
            raise FirstPairError()
        scan_seconds = _bounded_seconds(scan_seconds, 30)
        response_seconds = _bounded_seconds(response_seconds, 30)
        write_seconds = _bounded_seconds(write_seconds, 10)
        total_seconds = _bounded_seconds(total_seconds, 120)
        value = _candidate(material)
        if serial != value["sn"]:
            raise FirstPairError()
        _protocol()  # Reject an unreviewed protocol before scanning/connecting.
        from bleak import BleakClient, BleakScanner
        device = await asyncio.wait_for(BleakScanner.find_device_by_filter(
            lambda candidate, adv: advertisement_matches(adv, serial), timeout=scan_seconds), scan_seconds + 1)
        if device is None:
            report["outcome"] = "target_not_found"
            return report
        report["found"] = True
        client = BleakClient(device, timeout=15)
        try:
            await asyncio.wait_for(client.connect(), 16)
            result = await first_pair(client, value, enroll_if_requested=enroll_if_requested,
                                      response_seconds=response_seconds, write_seconds=write_seconds,
                                      total_seconds=total_seconds)
            report.update(result)
        finally:
            # This is ordinary transport cleanup, never a depair or key-clear command.
            await asyncio.wait_for(client.disconnect(), 10)
            report["disconnectedAfterCheck"] = True
    except Exception as error:
        report["outcome"] = "stopped"
        report["errorType"] = type(error).__name__
    return report


def write_report(path: Path, report: dict[str, Any]) -> None:
    """Reserve a new 0600 report; never overwrite a candidate, identity or prior report."""
    data = (json.dumps(report, sort_keys=True, indent=2) + "\n").encode("utf-8")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as output:
        os.fchmod(output.fileno(), 0o600)
        output.write(data)
        output.flush()
        os.fsync(output.fileno())


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-package", type=Path, required=True)
    parser.add_argument("--state-dir", type=Path, required=True)
    parser.add_argument("--upstream", type=Path, required=True)
    parser.add_argument("--sn", required=True)
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--scan-seconds", type=float, default=20)
    parser.add_argument("--response-seconds", type=float, default=12)
    parser.add_argument("--enroll-if-requested", action="store_true")
    args = parser.parse_args()
    try:
        if args.report.exists() or args.report.is_symlink():
            raise FileExistsError()
        attach_upstream(args.upstream)
        material = load_candidate_in_memory(args.candidate_package, args.state_dir, args.sn)
        report = asyncio.run(pair_candidate(args.sn, material, enroll_if_requested=args.enroll_if_requested,
                                             scan_seconds=args.scan_seconds,
                                             response_seconds=args.response_seconds))
        write_report(args.report, report)
        print(json.dumps(report, sort_keys=True))
        if report["outcome"] == "stopped":
            raise SystemExit(1)
    except Exception as error:
        print(f"First pairing stopped ({type(error).__name__}); credentials suppressed", file=sys.stderr)
        raise SystemExit(1) from None


if __name__ == "__main__":
    main()
