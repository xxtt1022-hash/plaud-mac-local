"""Normal cloud registration after a verified local BLE bind; no device operations.

This module has no CLI and reads neither Keychain nor files at import. Tokens must
come from the existing official TLS authentication helper, never an arbitrary JWT.
It never requests key generation, clears a key, unbinds or recovers a device.
"""
from __future__ import annotations

import base64
import json
import re
import ssl
import urllib.error
import urllib.request

from cloud_auth import OFFICIAL_BASE, _NoRedirect

BIND_URL = OFFICIAL_BASE + "/open/partner/sdk/bind"
MAX_RESPONSE = 65536


class BindingRegistrationError(RuntimeError):
    """Messages contain controlled constants and HTTP codes only."""

    def __init__(self, message: str, http_status: int | None = None):
        super().__init__(message)
        self.http_status = http_status


def validate_candidate_user(candidate: dict, official_user_token: str) -> None:
    """Match a candidate to an already authenticated official token's subject.

    cloud_auth must first validate the token's origin, client_id, user_id and expiry.
    Decoding the payload here is identity consistency checking, not JWT verification.
    Neither identity is truncated, padded, case-folded or substituted with user_id.
    """
    try:
        parts = official_user_token.split(".")
        if len(parts) != 3:
            raise ValueError()
        claims = json.loads(base64.urlsafe_b64decode(parts[1] + "=" * (-len(parts[1]) % 4)))
        subject = claims["sub"]
        saved = candidate["bindToken"]
        if not isinstance(subject, str) or not isinstance(saved, str):
            raise ValueError()
        def normalize(value):
            if value.startswith("client_user_"):
                value = value[len("client_user_"):]
            value = value.replace("-", "")
            if re.fullmatch(r"[A-Za-z0-9]{32}", value) is None:
                raise ValueError()
            return value
        if normalize(subject) != normalize(saved):
            raise ValueError()
    except Exception:
        raise BindingRegistrationError("Candidate does not match the authenticated application user") from None


def _transport(request: urllib.request.Request) -> tuple[int, bytes]:
    opener = urllib.request.build_opener(
        _NoRedirect(), urllib.request.HTTPSHandler(context=ssl.create_default_context()))
    try:
        with opener.open(request, timeout=30) as response:
            if response.geturl() != BIND_URL:
                raise BindingRegistrationError("Unexpected registration response origin")
            raw = response.read(MAX_RESPONSE + 1)
            status = response.status
    except urllib.error.HTTPError as error:
        code = error.code
        error.close()
        raise BindingRegistrationError(f"Official registration returned HTTP {code}; stopped", code) from None
    except BindingRegistrationError:
        raise
    except Exception:
        raise BindingRegistrationError("Official registration transport failed") from None
    return status, raw


def register_cloud_binding(official_user_token: str, serial: str, *,
                           ble_bind_accepted: bool, _send=None) -> dict:
    """POST only after CMD 1 status zero; do not retry or undo a failed registration.

    A local BLE bind may already exist when this request fails. The caller must
    preserve its encrypted identity and report that cloud registration is pending.
    """
    if ble_bind_accepted is not True:
        raise BindingRegistrationError("Verified local BLE binding is required before cloud registration")
    if re.fullmatch(r"881[0-9A-F]{13}", serial or "") is None:
        raise BindingRegistrationError("Require the complete expected Note Pro serial")
    if (not isinstance(official_user_token, str) or not 16 <= len(official_user_token) <= 32768
            or any(char.isspace() for char in official_user_token)):
        raise BindingRegistrationError("Invalid official user token")
    request = urllib.request.Request(BIND_URL, method="POST",
        data=json.dumps({"type": "notepro", "sn": serial}, separators=(",", ":")).encode(),
        headers={"Authorization": "Bearer " + official_user_token,
                 "Content-Type": "application/json", "Accept": "application/json",
                 "User-Agent": "codex-plaud-local/0.1"})
    try:
        status, raw = (_send or _transport)(request)
        if not 200 <= status <= 299:
            raise BindingRegistrationError(f"Official registration returned HTTP {status}; stopped", status)
        if len(raw) > MAX_RESPONSE:
            raise BindingRegistrationError("Registration response exceeded size limit")
        body = json.loads(raw)
        if (not isinstance(body, dict) or body.get("is_bind") is not True
                or ("sn" in body and body["sn"] != serial)
                or ("type" in body and body["type"] != "notepro")):
            raise ValueError()
    except BindingRegistrationError:
        raise
    except Exception:
        raise BindingRegistrationError("Cloud registration could not be verified") from None
    return {"cloudBindingRegistrationVerified": True, "httpStatus": status, "isBind": True}
