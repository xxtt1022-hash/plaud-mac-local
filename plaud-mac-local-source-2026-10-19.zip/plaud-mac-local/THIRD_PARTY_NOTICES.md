# Third-party code and external components

This is an independent experimental integration, not an official PLAUD product or a grant of access to PLAUD services. Vendor names describe interoperability and retain their owners' rights.

## Research protocol bridge and Android examples

- Repository: https://github.com/Shawn-TKD/plaud-direct-pc-research
- Required revision: `4f52d432b2f4d838ef10c7674d6b49f9bafc7005`
- Local implementation reuses this revision's public protocol/session APIs without modifying its checkout. The install script fetches it separately; it is not vendored here.
- Its Apache-2.0 license text is retained in `LICENSE`, including its explicit vendor-SDK exclusion. Its attribution notice is retained in `licenses/upstream-research-NOTICE.txt`.
- Public PLAUD Android example origin: https://github.com/Plaud-AI/plaud-sdk-public, inspected revision `d532d5a4ddff3714bc153f51467589cfd6b12f4c`. Android example attribution and changes remain in the Android source distribution.

## Proprietary PLAUD SDK and assets

The upstream license explicitly states that `plaud-sdk.aar` and iOS SDK binaries are proprietary and use a separate license. This repository does not include AAR/JAR SDK contents, JNI libraries, APKs, vendor firmware, decompiled vendor source, proprietary protocol documentation copies, or credentials. Obtain the official SDK independently under its applicable terms and verify the fixed hash documented by the Android setup. Apache-2.0 coverage of example source must not be treated as a redistribution grant for vendor binaries.

## Python/runtime dependencies

Python dependency versions from the acceptance environment are listed in `requirements-macos.lock.txt`. They are installed from their own distributions and retain their own licenses; no wheels or installed environment are included. Notable dependencies include Bleak, cryptography, CFFI/pycparser, PyObjC frameworks, qrcode/Pillow and imageio-ffmpeg. Review each distribution's included license/notice files if redistributing a built application or dependency bundle.

`imageio-ffmpeg` distributions can include ffmpeg executables. FFmpeg's exact license obligations depend on that executable's build configuration; this source repository does not bundle that binary or promise that a future packaged build has one uniform license. Likewise, whisper.cpp CLI, model weights and official Codex CLI are separately obtained components and are not relicensed here.

## Models, cloud services and user data

The model revision and integrity hash identify the tested model; they do not change its license. Obtain model weights from their stated publisher and keep the applicable model license. PLAUD developer services and Codex/ChatGPT require the user's own eligible account and current service terms. The local source does not include subscriptions or a service access grant.

Device private keys, public recipient keys, owner/candidate envelopes, binding material, tokens, recordings, transcripts, minutes, screenshots, databases, runtime configuration, generated launch bundles, logs and compiled artifacts are intentionally absent. Synthetic test fixture strings and generated test RSA keys are not real device identity material.
